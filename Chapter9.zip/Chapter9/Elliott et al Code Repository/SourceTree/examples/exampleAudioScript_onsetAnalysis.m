% This script demonstrates the extraction of onsets from two Wav files (or csv
% data file), from which timing information is measured and modelled.
% If using Wav files, figures are plotted to show the onset extraction of each
% source.

% set to true for CSV and false for wav file (both in 'data' folder)
useCSV = false;

% Get the onset data
if useCSV
    % specify the filename, delimiter, number of rows to skip, and whether the file has a header or not
    [onsets, labels] = readOnsetsFromTextFile('../data/text/onsetsExample.csv', ',', 0, true);
else 
    % Signal specific parameters
    config = {struct('minimumIOI', 0.3, 'thresholdOffset', 0.2),
              struct('minimumIOI', 0.3, 'thresholdOffset', 0.1)};
             
    [onsets, labels] = extractOnsetsFromWavFile(...
                       {'../data/audio/Metronome_100BPM.wav',...
                       '../data/audio/ViolinSingleNoteBowing_100BPM.wav'},...
                       config);
end;

% Use core functions to extract timing information:
onsets = createStructureByWarpingCellOnsets(onsets, labels, 1);

intervals = calculateIntervals(onsets);

asynchronies = calculateAsynchronies(onsets);

% Estimate timing paramters using the phase model
modelOutput = phaseModelWrapper(onsets);
