%An example of extracting raw data and performing analysis and modelling
%Use APDM convertor

f_name = '../data/movement/APDMExampleData.csv'; %filename
Fs = 120; %known sampling rate
labels_to_find = {'Acceleration X (m/s^2)'}; %find x-axis accelerations


[apdm, pathstr, tableFName] = readAPDMTxt(f_name, Fs, labels_to_find); %generates a table

raw = readRawDataFromTextFile([f_name(1:end-4) '_Table.csv'], ',', true); %


eventMode = ones(size(raw.data, 2),1); %Peak picking (alternatives: 0 Threshold, 1 troughs)
visualOn = true; %shows GUI for manual checking of onsets. 
is_ms = false; %time column is in seconds not ms
%Following values are not optimally set, requires trial and error!
targetPeaks = 30; %this should be the expected number of target peaks
startSens = .001; %start range of sensitivity
endSens = 10; %end range of sensitivity
%Algorithm will iterate through sensitivities to find closest match to
%expected number of peaks 

[onsets, labels] = eventDetectMovement(raw, eventMode, visualOn, is_ms, targetPeaks, startSens, endSens); %Get the onsets

onsets = createStructureByWarpingCellOnsets(onsets, labels, 1);

intervals = calculateIntervals(onsets); %calc intervals

asynchronies = calculateAsynchronies(onsets); %calc_asyncs

modelOutput = phaseModelWrapper(onsets); %run bGLS model
