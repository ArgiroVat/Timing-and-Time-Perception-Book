import os
import pymatlab

# Configure MATLAB
session = pymatlab.session_factory()
pathToSrc = os.path.split(os.path.dirname(os.path.realpath(__file__)))[0]
pathToSrc += '/src'
script = "addpath(genpath('%s'))" % pathToSrc
session.putvalue('script', script)
session.run('eval(script)')

def phaseModelWrapper(onsetMatrix, shuffleAsyncs=False):

    session.run('clear')
    session.putvalue('onsetMatrix', onsetMatrix)
    session.putvalue('shuffleAsyncs', shuffleAsyncs)

    # Core script for extracting parameter estimates
    script = """onsets = createStructureFromMatrix(onsetMatrix);
    phaseModel = phaseModelWrapper(onsets, shuffleAsyncs);
    alphas = phaseModel.alphas;
    timeKeeper = phaseModel.timeKeeper;
    motor = phaseModel.motor;
    predictedIntervals = phaseModel.predictedIntervals.series
    residuals = phaseModel.residuals.series
    """
    session.putvalue('script', script)
    session.run('eval(script)')

    # Get values
    output = {}
    output['alphas'] = session.getvalue('alphas');
    output['timeKeeper'] = session.getvalue('timeKeeper');
    output['motor'] = session.getvalue('motor');
    output['predictedIntervals'] = session.getvalue('predictedIntervals');
    output['residuals'] = session.getvalue('residuals');

    return output
