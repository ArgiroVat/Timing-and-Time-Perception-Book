function [indices] = peakDetection(signal, threshold, minPeakIntervalInSamples)
% This is a Matlab adaptation of the peakDetection function from SMS-tools

% Criteria for peak:
% signal(index) > threshold
% signal(index) > signal(index - 1)
% signal(index) > signal(index + 1)
% signal(peakIndex) - signal(peakIndex - 1) > minPeakIntervalInSamples
% For peaks within minPeakIntervalInSamples of one another, the largest peak is
% selected.

signal = signal(:);
threshold = threshold(:);

if length(threshold) ~= length(signal)
    disp('Warning, length of threshold does not match length of signal, using first value instead.');
    threshold = ones(length(signal), 1);
end;

indices = find((signal(2:end-1) > threshold(2:end-1)) & ...
               (signal(2:end-1) > signal(3:end)) & ...
               (signal(2:end-1) > signal(1:end-2)));

% Compensation
indices = indices + 1;
indices = indices(:);

% Search for largest peaks within minPeakIntervalInSamples of one another
newIndices = [indices(1)]';
prevIdx = indices(1);
for i = 2:length(indices)
    dur = indices(i) - prevIdx;

    peak = signal(indices(i));

   if dur > minPeakIntervalInSamples
       newIndices = [newIndices; indices(i)];
       prevIdx = indices(i);
   elseif peak > signal(newIndices(end))
       newIndices(end) = indices(i);
       prevIdx = indices(i);
   end;
end;
indices = newIndices';
