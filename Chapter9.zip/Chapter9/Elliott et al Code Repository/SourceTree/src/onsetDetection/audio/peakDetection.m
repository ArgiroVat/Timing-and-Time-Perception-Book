function [indices] = peakDetection(signal, threshold, minPeakIntervalInSamples)
% This is a Matlab adaptation of the peakDetection function from SMS-tools

% Criteria for peak:
% signal(index) > threshold
% signal(index) > signal(index - 1)
% signal(index) > signal(index + 1)
% signal(peakIndex) - signal(peakIndex - 1) > minPeakIntervalInSamples

signal = signal(:);
threshold = threshold(:);

if length(threshold) ~= length(signal)
    disp('Warning, length of threshold does not match length of signal, using first value instead.');
    threshold = ones(length(signal), 1);
end;

indices = find((signal(2:end-1) > threshold(2:end-1)) & ...
               (signal(2:end-1) > signal(3:end)) & ...
               (signal(2:end-1) > signal(1:end-2)));

% Compensation
indices = indices + 1;
indices = indices(:);

if length(indices) > 1
    locs = find((indices(2:end) - indices(1:end-1)) > minPeakIntervalInSamples);
    indices = indices([1; locs + 1])';
end;
