function [onsets, labels] = extractOnsetsFromWavFile(filename, configIn)
% This function is a wrapper around extractOnsetsFromSignal
% It can be used to perform onset detection on multiple wav files.

if nargin < 2
    configIn = struct();
end;

numFiles = length(filename);
if (length(configIn) ~= numFiles)
    for file = 1:numFiles
        config{file} = configIn;
    end;
else
    config = configIn;
end;

if ~iscell(filename)
    filename = {filename};
end;


for file = 1:numFiles
    [~, name, ~] = fileparts(filename{file});
    % [signal, fs, numBits] = wavread(filename{file}); % Uncomment if you don't have audioread
    [signal, fs] = audioread(filename{file});
    onsets{file} = extractOnsetsFromSignal(signal, fs, config{file})';
    labels{file} = name;
end;
