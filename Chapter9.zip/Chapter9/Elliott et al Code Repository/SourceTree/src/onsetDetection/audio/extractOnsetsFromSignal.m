function [onsets] = extractOnsetsFromSignal(signal, fs, config, doPlot)

% Default configuration options
options = struct('shouldBandPassFilter', false,...
                 'cutOffLo', 20.0,...
                 'cutOffHi', 10000.0,...
                 'filterOrder', 3,...
                 'zeroPhaseEnvelope', true,...
                 'envelopeTimeConstant', 0.002,...
                 'logEnvelope', true,...
                 'downsampleFactor', fs / 500.0,...
                 'thresholdWindowSize', 10,...
                 'thresholdFactor', 0.8,...
                 'thresholdOffset', 0.05,...
                 'minimumIOI', 0.1);

optionNames = fieldnames(options);

% Overwrite defaults with user config (must match exactly!)
if nargin > 2
    inputNames = fieldnames(config);
    for i = 1:length(inputNames)
        if any(strcmp(inputNames{i}, optionNames))
            options.(inputNames{i}) = config.(inputNames{i});
        end
    end
    doPlot = true;
end;

% Signal shape
[numSamples, numChannels] = size(signal);

% Peak normalise signal
signal = signal ./ max(abs(signal));

% Zero-phase bandpass filter
signalFilt = signal;
if options.shouldBandPassFilter
    [bCoefs, aCoefs] = butter(options.filterOrder, ...
                              [options.cutOffLo, options.cutOffHi] ...
                              / (fs * 0.5), ...
                              'bandpass');
    signalFilt = filtfilt(bCoefs, aCoefs, signal);
end;

% Envelope in decibels
envelopeMain = calculateEnvelope(signalFilt, fs,...
                                 options.envelopeTimeConstant,...
                                 options.zeroPhaseEnvelope,...
                                 options.logEnvelope);

% Downsample
envelope = envelopeMain(1:options.downsampleFactor:end);

% Take first-order difference of log envelope = onset detection function
% add zero so if sample n is a peak in the original ODF we get a timestamp at n
onsetDetectionFunction = diff(envelope);
onsetDetectionFunction = [0.0; onsetDetectionFunction(:)];

% Half-wave rectify
onsetDetectionFunction(onsetDetectionFunction < 0.0) = 0.0;

% Peak-normalise
onsetDetectionFunction = onsetDetectionFunction / max(onsetDetectionFunction);

% Generate a threshold
threshold = simpleMovingAverage(onsetDetectionFunction,...
                                options.thresholdWindowSize);
threshold = threshold .* options.thresholdFactor + options.thresholdOffset;

minimumIOIInSamples = round(options.minimumIOI * fs) /...
                      options.downsampleFactor;

onsetIndices = peakDetection2(onsetDetectionFunction, ...
                              threshold, ...
                              minimumIOIInSamples);
timeStep = options.downsampleFactor / fs;

% Convert to timestamps, minus 1 for time zero at first sample
onsets = (onsetIndices - 1.0) * timeStep;

if doPlot
    time = [0:length(signal)-1] / fs;
    time2 = [0:length(envelope)-1] * timeStep;
    time3 = [0:length(onsetDetectionFunction)-1] * timeStep;

    ax1 = subplot(3,1,1);
    plot(time, signal); hold on;
    plot(time3(onsetIndices), signal(onsetIndices), 'or', 'MarkerSize', 10);
    title('Waveform'); ylabel('Amplitude');

    ax2 = subplot(3,1,2);
    plot(time2, envelope, '--r');
    title('Envelope'); ylabel('Level, dB');

    ax3 = subplot(3,1,3);
    plot(time3, onsetDetectionFunction); hold on;
    plot(time3, threshold, '--g');
    plot(time3(onsetIndices),...
         onsetDetectionFunction(onsetIndices),...
         'or',...
         'MarkerSize',...
         10); 
    hold off;
    title('Detection function and threshold'); xlabel('Time, s'); ylabel('Amplitude');
    linkaxes([ax1, ax2, ax3], 'x');
    hold off;
    waitfor(ax1);
end;
