function envelope = calculateEnvelope(x, fs, tau, zeroPhase, inDecibels)
%Extract the envelope of a signal
% x: input signal to be filtered
% fs: sampling frequency in Hz
% tau: filter time-constant in seconds
% zeroPhase: uses zero-phase filter if true
% contactdominicward@gmail.com

if nargin < 5
    inDecibels = true;
end

if nargin < 4
    zeroPhase = true;
end

if nargin < 3
    tau = 0.01;
end

alpha = exp(-1.0 ./ (fs * tau));

if zeroPhase
    envelope = filtfilt([1.0 - alpha], [1.0, -alpha], abs(x));
else
    envelope = filter([1.0 - alpha], [1.0, -alpha], abs(x));
end

envelope(envelope < 0.0) = 0.0;

if inDecibels
    envelope = 20.0 * log10(envelope + 1e-5);
end;
