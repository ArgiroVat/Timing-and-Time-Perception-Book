function [sma] = simpleMovingAverage(x, windowSize)
% Window must be off so centred on each input sample

% Force odd
windowSize = windowSize + (1 - mod(windowSize, 2));

b = ones(1, windowSize) / windowSize;

numSamplesToRemove = (windowSize - 1) / 2;
numSamplesToPadEnd = numSamplesToRemove;
x = [x(:); zeros(numSamplesToPadEnd, 1)];
sma = filter(b, 1.0, x);
sma = sma(numSamplesToRemove+1:end);
