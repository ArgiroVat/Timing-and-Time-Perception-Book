function [t_mins, t_maxs, n_pks, used_sens] = pkDetAutoSense(t, mdata, target_pks, start_sens, end_sens, use_minp)

% t = time vector
% mdata - the original movement data
% target_pks - expected number of peaks
% start_sens - start range of sensitivity of peak detection.
% end_sens - end range of sensitivity of peak detection.
% use_minp - 1 = uses minimum peaks, 0 = uses maximum peaks

 pk_sens = start_sens;
 cnt = 1; 
while pk_sens < end_sens
    %change step size as we progress
    if pk_sens < 100 && pk_sens >= 1
        sens_step = 1;
    elseif pk_sens < 1 && pk_sens >= .1
        sens_step = .1;
    elseif pk_sens < .1 && pk_sens >= .01
        sens_step = .01;
    elseif pk_sens < .01 && pk_sens >= .001
        sens_step = .001;
    else
        sens_step = .0001; 
    end
    
    nfound = [];
    [maxp{cnt}, minp{cnt}] = peakdet(mdata, pk_sens); %find peaks above baseline (returns pos&neg peaks;uses peak detect. mat)
    if use_minp
        nfound(cnt, :) = [length(minp{cnt}), pk_sens];
    else
        nfound(cnt, :) = [length(maxp{cnt}), pk_sens];
    end
    cnt = cnt + 1;
    pk_sens = pk_sens + sens_step; 
end

diff_from_target = abs(nfound(:,1) - target_pks); %find shortest distance
[~, best_match] = min(diff_from_target);
n_pks = nfound(best_match, 1); 
used_sens = nfound(best_match, 2);

if ~isempty(minp{best_match})
    t_mins = [minp{best_match}(:,1), t(minp{best_match}(:,1)), minp{best_match}(:,2)]; %times of the neg peaks.
else
    t_mins = NaN; %nothing found
end

if ~isempty(maxp{best_match})
    t_maxs = [maxp{best_match}(:,1), t(maxp{best_match}(:,1)), maxp{best_match}(:,2)];
else
    t_maxs = NaN;
end
