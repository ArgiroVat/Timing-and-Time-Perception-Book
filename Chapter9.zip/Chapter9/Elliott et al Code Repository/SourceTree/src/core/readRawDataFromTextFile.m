function raw = readRawDataFromTextFile(filenm, delim, hasHeader)
%Reads a delimited file of raw sampled data - Column 1 is time vector, each subsequent column is different
%stimulus/response.
%Inputs:
%filenm: full path and filename
%delim: delimiting character, e.g. ',' or '\t'
%offsR: offset start row to skip over any junk; zero means no offset
%hasHeader: set true if the first row read contains header labels. Note
%this is after offsR have been taken into account.
%
%Outputs:
%ons: structure containing:
% .data: cell array of each column of data
% .label: corresponding label extracted from header in file. If hasHeader
% is false, this will be an empty array.
%
%Copyright Mark Elliott, Institute of Digital Healthcare, University of Warwick
%October 2015

rowskip = 0; %skip any stated rows

if hasHeader
    fid = fopen(filenm, 'r');
    if fid < 0
        disp('Could not open file!!');
        return;
    end
    
    label = {};
    buffer = '';
    
    for skip = 1:rowskip
        buffer = fgetl(fid);   %get next line but discard
    end
    
    buffer = fgetl(fid);   %get next line as a string
    rowskip = rowskip + 1; %data on the next row
    
    [next,buffer] = strtok(buffer, delim); %get the first label
    label{1} = next;
    
    n=1; %current label index
    while ~isempty(buffer)
        [next,buffer] = strtok(buffer, delim); %parse next column label
        if ~isempty(next)
            n=n+1; %next label index
            label{n} = next; %Get next label
        end
    end
    fclose(fid); %close file
else
    label = {};
end
try
    dat  = dlmread(filenm, delim, rowskip, 0); %read in data (avoiding header)
catch
    dat = NaN;
    disp('ERROR reading delimited data, check for strings, headers etc in the file');
end
time = dat(:,1); %first column is time.
dat = dat(:,2:end); %rest is data

raw.labels = label(2:end); %don't include Time label
raw.time = time;
raw.data = dat;




