function [structure] = createStructureFromMatrix(matrix, labels)

[structure.numEvents, structure.numChannels] = size(matrix);

structure.series = matrix;
structure.mean = nanmean(matrix);
structure.sd = nanstd(matrix);

if nargin == 1
    structure.labels = cell(1, structure.numChannels);
else
    structure.labels = labels;
end;
