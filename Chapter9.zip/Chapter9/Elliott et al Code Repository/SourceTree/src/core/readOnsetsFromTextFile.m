function [onsets, label] = readOnsetsFromTextFile(filename, delimiter, numRowsToSkip, hasHeader)
%Reads a delimiterited file of onsets - each column is different
%stimulus/response.
%Inputs:
%filename: full path and filename
%delimiter: delimiteriting character, e.g. ',' or '\t'
%numRowsToSkip: offset start row to skip over any junk; zero means no offset
%hasHeader: set true if the first row read contains header labels. Note
%this is after numRowsToSkip have been taken into account.
%
%Outputs:
%onsets: structure containing:
% .data: cell array of each column of data
% .label: corresponding label extracted from header in file. If hasHeader
% is false, this will be an empty array.
%
%Copyright Mark Elliott, Institute of Digital Healthcare, University of Warwick
%October 2015

if hasHeader
    fid = fopen(filename, 'r');
    if fid < 0
        disp('Could not open file!!');
        return;
    end
    
    label = {};
    buffer = '';
    
    for skip = 1:numRowsToSkip
        buffer = fgetl(fid);   %get next line but discard
    end
    
    buffer = fgetl(fid);   %get next line as a string
    numRowsToSkip = numRowsToSkip + 1; %data on the next row
    
    [next,buffer] = strtok(buffer, delimiter); %get the first label
    label{1} = next;
    
    n=1; %current label index
    while ~isempty(buffer)
        [next,buffer] = strtok(buffer, delimiter); %parse next column label
        if ~isempty(next)
            n=n+1; %next label index
            label{n} = next; %Get next label
        end
    end
    fclose(fid); %close file
else
    label = {};
end
try
    dat  = dlmread(filename, delimiter, numRowsToSkip, 0); %read in data (avoiding header)
catch
    dat = NaN;
    disp('ERROR reading delimiterited data, check for strings, headers etc in the file');
end
dat(dat==0) = NaN; %replace what should be empty cells, with nan instead of zero

% Leave as matrix
%onsets = createStructureFromMatrix(dat, label);

onsets = mat2cell(dat, size(dat, 1), ones(1,size(dat,2)));
onsets = cellfun(@delNaN, onsets,  'UniformOutput', false)';

end

function x=delNaN(x)
x(isnan(x))=[];
end
