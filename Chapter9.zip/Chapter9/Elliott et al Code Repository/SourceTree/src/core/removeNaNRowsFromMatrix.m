function [output] = removeNaNRowsFromMatrix(input)

output = input(~any(isnan(input),2), :);
