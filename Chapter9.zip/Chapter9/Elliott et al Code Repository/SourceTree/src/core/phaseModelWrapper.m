function [output] = phaseModelWrapper(onsets, shuffleAsynchs)

if nargin == 1
    shuffleAsynchs = false;
end;

% Onset intervals
intervals = calculateIntervals(onsets);

% Asynchronies
asynchs = calculateAsynchronies(onsets);

% Remove NaNs if any
intervals.series = replaceNaNsWithColMean(intervals.series);
asynchs.series = replaceNaNsWithColMean(asynchs.series);

if shuffleAsynchs
    asynchs.series = asynchs.series(randperm(asynchs.numEvents), :);
end;

numPlayers = onsets.numChannels;
numPartners = numPlayers - 1;

output.alphas = zeros(numPlayers, numPlayers);
output.timeKeeper = zeros(numPlayers, 1);
output.motor = zeros(numPlayers, 1);
output.labels = onsets.labels;
output.predictedIntervals = intervals;
output.residuals = intervals;

for player = 1:numPlayers

    % Prepend intervals with single zero because bGLS second index (line 52) as the
    %first observation and first index of partner asyns as predictors. 
    %Thus player response interval R(t) - R(t-1) is modelled by async(t-1,:)
    % Can use mean instead (as per Nori example) but doesn't matter since we use
    % intervals.mean
    playerIntervals = [0; intervals.series(:, player)];

    asynchIndices = numPartners * (player - 1) + [1:numPartners];

    %run bGLS
    [alphas, st, sm] = bGLS_phase_model_single_and_multiperson(...
                                                playerIntervals,...
                                                asynchs.series(:, asynchIndices),...
                                                asynchs.mean(asynchIndices),...
                                                intervals.mean(player));

    partnerIndices = setdiff(1:numPlayers, player);
    output.alphas(player, partnerIndices) = alphas;
    output.timeKeeper(player) = st;
    output.motor(player) = sm;
    
    predictedIntervals = asynchs.series(1:end - 1, asynchIndices) * -alphas' +...
                         intervals.mean(player);
    output.predictedIntervals.series(:, player) = predictedIntervals;
    output.residuals.series(:, player) = intervals.series(:, player) - predictedIntervals;
end;
