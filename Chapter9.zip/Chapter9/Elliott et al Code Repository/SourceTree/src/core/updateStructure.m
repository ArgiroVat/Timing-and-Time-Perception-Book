function [structure] = updateStructure(structure)

[structure.numEvents, structure.numChannels] = size(structure.series);

structure.mean = nanmean(structure.series);
structure.sd = nanstd(structure.series);

if nargin == 1
    structure.labels = cell(1, structure.numChannels);
else
    structure.labels = structure.labels;
end;
