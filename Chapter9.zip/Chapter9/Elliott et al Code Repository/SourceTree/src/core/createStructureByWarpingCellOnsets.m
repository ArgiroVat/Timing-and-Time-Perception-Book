function [structure] = createStructureByWarpingCellOnsets(onsets,...
                                                          labels,...
                                                          refIndex,...
                                                          minIOIFactor)

numPlayers = length(onsets);
if numPlayers == 1
    structure = createStructureFromMatrix(onsets{1}, labels);

else
    if nargin == 2
        minIOIFactor = 0.5;
    end;
    % Align to the reference cell if given
    if nargin == 3
        for i = 1:numPlayers
            z = warpAlignOnsets(onsets{refIndex}, onsets{i});
            warpedOnsets(:, i) = z(:, 2);
        end;
    % Otherwise estimate a reference signal
    else 
        total = []';
        for i = (1:length(onsets))
            vals = onsets{i}(~any(isnan(onsets{i}),2));
            minIOI(i) = min(diff(vals));
            total = [total, vals'];
        end;

        total = sort(total);
        disp(total');
        minIOI = min(minIOI) * minIOIFactor;
        idx = 1;
        while any(idx)
            idx = [diff(total) < minIOI, 0];
            total = total(~idx);
        end;

        for i = 1:numPlayers
            z = warpAlignOnsets(total', onsets{i});
            warpedOnsets(:, i) = z(:, 2);
        end;
    end;

    structure = createStructureFromMatrix(warpedOnsets, labels);
end;
