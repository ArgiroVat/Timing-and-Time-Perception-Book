function [asynchronies] = calculateAsynchronies(onsets)
%Calculate asynchronies from an onset data structure
% Asynchrony: Pairwise asynchronies between each channel
%   - series: time series calculated from paired onsets difference (after
%   alignment.
%   - mn: Mean asynchrony
%   - sd: SD asynchrony
%
% Copyright Mark Elliott, Institute of Digital Healthcare, University of Warwick
% October 2015

numCombos = onsets.numChannels * (onsets.numChannels - 1);
series = zeros(onsets.numEvents, numCombos);
numPartners = onsets.numChannels - 1;

for player = 1:onsets.numChannels
    partnerIndices = setdiff(1:onsets.numChannels, player);

    for partner = 1:numPartners
        idx = numPartners * (player - 1) + partner;
        asynchs = onsets.series(:, player) - onsets.series(:, partnerIndices(partner));
        series(:, idx) = asynchs;
        labels{idx} = strcat(onsets.labels{player}, '-',...
                             onsets.labels{partnerIndices(partner)});
    end;
end;

asynchronies = createStructureFromMatrix(series, labels);
