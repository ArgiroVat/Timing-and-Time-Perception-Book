function [input] = replaceNaNsWithColMean(input)

nm = nanmean(input);
for col = 1:size(input, 2)
    loc = isnan(input(:, col));
    input(loc, col) = nm(col);
end;
