function [rt, rt_EM ] = opponent_Poisson( plus_rate, gamma, threshold )

% opponent_Poisson( plus_rate, gamma, threshold)
%
% A simple opponent Poisson simulation for comparison to an
% Euler-Maruyama simulation of an equivalent drift-diffusion model.
%
% Enter different excitatory spike rates (plus_rate), different proportions
% of inhibition to excitation (gamma) from greater than 0 to 1, and
% different thresholds (threshold) for responding.
%
% Example:
%   [rt, rt_EM] = opponent_Poisson( 100, 0.5, 100 )
%
% Copyright 2016, Patrick A. Simen
% Freely reuseable under the GNU General Public License 2.0 or greater

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARAMETER VALUES:

if nargin < 3
    threshold = 100;
end
if nargin < 2
    gamma = 0.5;            % Proportion of inhibition to excitation
end
if nargin < 1
    plus_rate = 100;          % Excitatory spike rate
end

minus_rate = gamma * plus_rate;     % Inhibitory spike rate


% How many excitatory spikes to simulate:
num_plus_spikes = round(1000 * threshold/(plus_rate-minus_rate));

% Number of trials in each condition:
num_trials = 500;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



rt = NaN*ones(1,num_trials);        % Initialize a record of response times



figure
hold on



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIRST, SIMULATE THE OPPONENT POISSON MODEL:
for i = 1:num_trials
    % Generate a sequence of excitatory spikes:
    plus_spikes = exprnd(1/plus_rate, 1, num_plus_spikes);
    plus_spike_time = cumsum(plus_spikes);
    
    minus_spikes = exprnd(1/minus_rate, 1, num_plus_spikes);
    minus_spike_time = cumsum(minus_spikes);
    
    [spike_times,spike_idx] = sort( [plus_spike_time, minus_spike_time] );
    spike_values = [ones(1,length(plus_spike_time)), ...
        -1*ones(1,length(minus_spike_time))];
    spike_values = spike_values(spike_idx);
    
    
    rand_walk = cumsum(spike_values);
    
    
    % Plot the spike-count evolution:
    subplot(2,2,1)
    hold on
    
    rt_idx = find(rand_walk>threshold,1);
    if ~isempty(rt_idx)
        rt(i) = spike_times(rt_idx);
    end
    
    %     plot(spike_times(1:rt_idx),rand_walk(1:rt_idx),'b');
    
    % Now create a spike count plot (need to double the number of time
    % steps and spike count values, and shift spike count back one step in
    % time):
    st_plot = zeros(1,2*rt_idx);
    st_plot(1:2:end) = spike_times(1:rt_idx);
    st_plot(2:2:end) = spike_times(1:rt_idx);
    rw_plot = zeros(1,2*rt_idx);
    rw_plot(1:2:end) = rand_walk(1:rt_idx);
    rw_plot(2:2:end) = [rand_walk(2:rt_idx),rand_walk(rt_idx)];
    plot(st_plot,rw_plot,'r');
    
    % Plot out the threshold:
    plot([0 3*max(st_plot)],threshold*[1 1],'k--');
    
end
xlabel('Time')
title('Opponent Poisson Model')

% Plot RT histogram:
subplot(2,2,3)
hist(rt)
title(sprintf('CV = %.2f, Skew = %.2f, Ratio = %.2f',...
    nanstd(rt)/nanmean(rt), skewness(rt), skewness(rt)/nanstd(rt)*nanmean(rt)));
xlabel('Response times')

fprintf('# failures to cross, OP model: %d\n', length(find(isnan(rt))));

% Find a maximum response time for setting horizontal graph limits:
xlim_max = max(rt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOW, THE EULER-MARUYAMA METHOD FOR SIMULATING THE EQUIVALENT DDM:
%
% The equivalent DDM equation is:
% dx = (1-gamma)lambda dt + sqrt(1+gamma)lambda dW,
%
% with
%
% lambda = excitatory spike rate ("plus_rate")
% threshold = threshold

num_steps = 100000;
dt = 0.01;
rt_EM = NaN*ones(1,num_trials);

for i = 1:num_trials
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% THIS FOR-LOOP VERSION IS MORE INTUITIVE TO READ, BUT
    % IT COULD BE VECTORIZED FOR SPEED OF OPERATION:
    %
    x = zeros(1,num_steps);
    
    for j = 2:num_steps
        x(j) = x(j-1) + (1-gamma)*plus_rate*dt + ...
            sqrt((1+gamma)*plus_rate)*sqrt(dt)*normrnd(0,1);
        if x(j) > threshold
            rt_idx = j;
            rt_EM(i) = j*dt;
            break
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    subplot(2,2,2)
    hold on
    
    plot(dt*[1 3*rt_idx],threshold*[1 1],'k--');  % Plot out the threshold
    
    % Plot out the random walk out:
    plot(dt*(1:rt_idx),x(1:rt_idx),'m');
    
end
xlabel('Time')
title('Euler-Maruyama DDM')

subplot(2,2,4)
hist(rt_EM)
title(sprintf('CV = %.2f, Skew = %.2f, Ratio = %.2f',...
    nanstd(rt_EM)/nanmean(rt_EM), skewness(rt_EM), skewness(rt_EM)/nanstd(rt_EM)*nanmean(rt_EM)));
xlabel('Response times')

fprintf('# failures to cross, EM DDM: %d\n', length(find(isnan(rt_EM))));

xlim_max = max( xlim_max, max(rt_EM) );

% Now set horizontal graph limits:
for i = 1:4
    subplot(2,2,i);
    xlim([0 xlim_max]);
end

