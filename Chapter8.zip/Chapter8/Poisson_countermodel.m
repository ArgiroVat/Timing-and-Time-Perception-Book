function rt = Poisson_countermodel( pulse_rate, threshold )

% Poisson_countermodel( pulse_rate, threshold)
%
% A simple  Poisson pacemaker accumulator simulation. This can be used to
% implement either Creelman's (1962) model, which sets the threshold equal
% to T/pulse_rate for duration T, or Killeen & Fetterman's (1988) BeT
% model, which keeps the threshold fixed and sets the pulse-rate to
% threshold/T. 
%
% Enter different excitatory spike rates (pulse_rate), and
% different thresholds (threshold) for responding.
%
% Example: 
%   rt = Poisson_countermodel( 2, 5 );
%
% References: 
% Creelman, C. D. (1962). Human discrimination of auditory duration. The 
%   Journal of the Acoustical Society of America, 34, 582?593.
% Killeen, P. R., & Fetterman, J. G. (1988). A behavioral theory of timing.
%   Psychological Review, 95(2), 274?295.
%
% Copyright 2016, Patrick A. Simen
% Freely reuseable under the GNU General Public License 2.0 or greater






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARAMETER VALUES:
if nargin < 2
    threshold = 100;
end
if nargin < 1
    pulse_rate = 100;        % Excitatory spike rate
end


       

% How many excitatory spikes to simulate:
num_plus_spikes = round(1000 * threshold/(pulse_rate));

% Number of trials in each condition:
num_trials = 500;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



rt = NaN*ones(1,num_trials);        % Initialize a record of response times



figure
% hold on



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIRST, SIMULATE THE OPPONENT POISSON MODEL:
for i = 1:num_trials
    % Generate a sequence of excitatory spikes:
    spike_intervals = exprnd(1/pulse_rate, 1, num_plus_spikes);
    spike_times = cumsum( spike_intervals);
    spike_values = ones(1,length(spike_times));
    randwalk = cumsum(spike_values);

    
    
    % Plot the spike-count evolution:
    subplot(2,1,1)
    hold on    
        
    rt_idx = find(randwalk>threshold,1);
    if ~isempty(rt_idx)
        rt(i) = spike_times(rt_idx);
    end
        
    stairs(spike_times,randwalk);
        
end

% Plot out the threshold:
plot([0 max(rt)],threshold*[1 1],'k--');


xlabel('Time')
title('Opponent Poisson Model')

% Plot RT histogram:
subplot(2,1,2)
hold on
hist(rt)
title(sprintf('CV = %.2f, Skew = %.2f, Ratio = %.2f',...
    nanstd(rt)/nanmean(rt), skewness(rt), skewness(rt)/nanstd(rt)*nanmean(rt)));
xlabel('Response times')

fprintf('# failures to cross, OP model: %d\n', length(find(isnan(rt))));

% Find a maximum response time for setting horizontal graph limits:
xlim_max = max(rt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%








