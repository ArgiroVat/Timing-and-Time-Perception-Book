function [rt, y] = Treisman63(varargin)

% Invoke as:
%
% [rt, y] = Treisman63( [ ,duration], [ ,tick_rate], [ ,interpulse_std], [ ,correlation], [ ,num_trials], [ ,exponential] )
%
% This function simulates M. Triesman's timing model. It can be used to 
% test the claim that Treisman's model is consistent with Weber's Law for 
% Timing, even with very low interpulse-time variability within individual 
% timing trials. 
%
% y is the returned set of inter-pulse durations as a matrix, with each
% column corresponding to a single timing trial. 
%
% Optional arguments (insert an empty matrix, [], to select default
% values):
%
%   duration:       desired duration in, e.g., seconds -- default is 200
%   tick_rate:      how many ticks per time unit, on average -- default is
%                   0.5
%   interpulse_std: variability (standard deviation) of inter-pulse 
%                   durations around mean (i.e., mean = 1/tick_rate) -- 
%                   default value is 0.2
%   correlation:    correlation coefficient between any two interpulse 
%                   durations in a single timing trial -- default is high 
%                   value of 0.9
%   num_trials:     number of trials -- defaults to 100
%   exponential:    flags whether the interpulse durations are 
%                   exponentiallydistributed (1 or 0) -- default is 0 
%                   (specifying normal rather than exponential)
%
% Example:
%   Treisman63( [], [], [], [], [], [] )
%       This invocation of the model sets all adjustable inputs to 
%       their default values. Returns inter-pulse duration matrix y.
%
%   Treisman63( 200, [], 0.2, 0.9, 50, [] );
%       This invocation of the model sets specific values for some
%       parameters. All values here are the same as the default values, 
%       except the number of trials, which is set to 50 instead of 100.
%       Semi-colon suppresses y-matrix printout.
%
% Reference:
% Treisman, M. (1963). Temporal discrimination and the indifference 
%   interval: implications for a model of the `internal clock?. 
%   Psychological Monographs, 77, 1?31.
%
% Copyright 2016, Patrick A. Simen
% Freely reuseable under the GNU General Public License 2.0 or greater





% NOTES ON ALGORITHM:
%
% Each column of matrix y below represents the sequential inter-pulse 
% durations in a trial. The ith row contains all the samples of the 
% random variable that is the i-th inter-pulse duration across trials. The 
% correlation structure of the pulses is such that once you select the 
% duration of the first pulse (or the ith pulse more generally), that value 
% becomes highly predictive of the rest of the inter-pulse durations in 
% that trial (for very high correlation values). This is true for any pair 
% i and j. 
%
% If it is the case that across trials, the first tick duration is highly 
% predictive of second tick durations, then low values in any given column 
% of the first row are predictive of low values in the same column of the 
% second row. To determine whether this is truly the case for any matrix we 
% create, we can use Matlab's corr function. This function computes such 
% correlation values, but it does this for columns instead of rows. So we 
% must first transpose the matrix, then use corr to get the correlation 
% coefficient between columns. 
%
% To create y matrices with this sort of correlation, we can use the
% Cholesky decomposition of a desired correlation matrix, then take one of
% the elements of that decomposition, multiply it by a matrix of random
% numbers (mean 0, var 1), and we'll get our desired y-matrix of 
% appropriately correlated random numbers. In our case, the correlation 
% matrix will be quite simple, with 1s along the diagonal, and some other 
% number between 0 and 1 repeated at all other positions in the matrix. See
% wikipedia article on Cholesky decomposition:
% https://en.wikipedia.org/wiki/Cholesky_decomposition#Monte_Carlo_simulation


for i = 1:6
    if nargin < i
        param(i) = NaN;
    else
        if isempty( varargin{i} )
            param(i) = NaN;
        else
            param(i) = varargin{i};
        end
    end
end


if isnan( param(1) )
    duration = 200;
else
    duration = param(1);
end
if isnan( param(2) )
    tick_rate = 1/2;
else
    tick_rate = param(2);
end
if isnan( param(3) )
    interpulse_std = 0.2;
else
    interpulse_std = param(3);
end
if isnan( param(4) )
    correlation = 0.9;
else
    correlation = param(4);
end
if isnan( param(5) )
    num_trials = 100;
else
    num_trials = param(5);
end
if isnan( param(6) )
    exp_flag = 0;
else
    exp_flag = param(6);
end
    


% if nargin < 1
%     num_ticks = 25;
% end
% x = rand(25);

num_ticks = duration * tick_rate;
% num_ticks = 50;   % NOTE: To simulate BeT/TopDDM, set num_ticks to a
% fixed level for different intervals, set the correlation level to near 0,
% set tick_rate to duration/num_ticks, and inter-pulse std to 1/tick_rate.
if mod(num_ticks,1) ~= 0
    fprintf('\n\n*******************\nnum_ticks = %.4f.\nTo avoid problems, select durations \nand tick rates that yield integer valued number of pulses for the duration.\n*******************\n\n',num_ticks);
    y = [];
    return
end

% Below, x is the set of variations of the inter-pulse interval around its
% mean (standard normal, or exponential with mean 1):
if ~exp_flag
    x = normrnd(0,1,num_ticks,num_trials);  % num_ticks rows, num_trials columns
else
    % % If you want to get a skewed distribution of RTs:
    x = exprnd(1,num_ticks,num_trials) - 1;
end

% Correlation coefficient of tick-i vs. tick-j duration values:
% cc = 0.8;
cc = correlation;

C = cc*ones(num_ticks); % Set C to a num_ticks by num_ticks matrix, with 
                        % all elements equal to cc

C = C+(1-cc)*eye(num_ticks);    % Set the diagonal to 1

L = chol(C);    % Cholesky factorization of C generates L and L' such that 
                % L * L' = C






% Each trial is a column of x values:
for i = 1:num_ticks
    v(i) = var(x(i,:));
end
fprintf(sprintf('\n\n\nSum over ticks of across-trial x-value variances: %0.3f\n', sum(v)));

% For each trial, I want to know the sum of all the ticks durations in a
% trial (i.e., the total time):
for j = 1:num_trials
    s(j) = sum(x(:,j)); 
end
fprintf(sprintf('Variance across trials of within-trial x-value sums: %0.3f\n', var(s)));



%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE properly correlated inter-pulse duration matrix y, adding
% correlated variability values x and the mean inter-pulse duration: 
y = interpulse_std*L'*x + 1/tick_rate;

figure
imagesc(L');
colorbar
title('Correlation-inducing transformation matrix L from Cholesky decomposition')

% Not sure if multiplying by interpulse_std is actually correct for getting
% the desired std of interpulse durations. Seems to work though.
%%%%%%%%%%%%%%%%%%%%%%%%%%



for j = 1:num_trials
    vy(j) = var(y(:,j));
end

for j = 1:num_trials 
    sy(j) = sum(y(:,j)); 
end

for i = 1:num_ticks
    var_tick(i) = var(y(i,:));
end

figure
set(gcf,'Position',[109 53 650 753]);
subplot(3,1,1)
hold on
mycolor = rand(num_trials,3);

for i = 1:num_trials 
    plot(x(:,i),y(:,i),'o','Color',mycolor(i,:));  
end
fprintf(sprintf('Sum across trials of within-trial y-value variances: %0.3f\n', sum(vy)))

fprintf(sprintf('Variance across trials of within-trial y-value sums: %0.3f\n', var(sy)));

fprintf(sprintf('Num-ticks squared times average variance of tick durations across trials \n \t(expected to equal var of sums for highly correlated tick durations): %0.3f\n', num_ticks^2*mean(var_tick)));

fprintf(sprintf('Sum over ticks of across-trial y-value variances \n \t (expected to equal var of sums for independence): %0.3f\n\n\n', sum(var_tick)))

ylabel('Inter-pulse durations','FontSize',18);
if ~exp_flag
    title(sprintf('Independent normal random variables \n used to generate correlated outputs \n Each trial has a unique color'),'FontSize',18)
    xlabel('Independent normal inputs')
else
    title(sprintf('Independent exponential random variables \n used to generate correlated outputs \n Each trial has a unique color'),'FontSize',18)
    xlabel('Independent exponential inputs')
end

subplot(3,1,2)
ysize = size(y);
ylist = reshape(y,1,ysize(1)*ysize(2));
hist(ylist,30);
title(sprintf('Inter-pulse duration distribution\tSTD = %0.3f',std(ylist)),'FontSize',18)
xlabel('Inter-pulse duration (e.g., in seconds)')

subplot(3,1,3)
CY = corr(y');  % Determine the actual correlations that were generated
% CY = triu(CY);
% imagesc(corr(y'))
imagesc(CY);
xlabel('pulse j', 'FontSize', 18);
ylabel('pulse i', 'FontSize', 18);
title('Correlation matrix of inter-pulse durations','FontSize',18)
colorbar


% Now plot out the trajectories, and gather response time and interpulse
% duration stats:

figure
set(gcf,'Position',[765    54   579   752])
for i = 1:num_trials
    pulse_times(:,i) = cumsum(y(:,i));
    pt_plot = zeros(1,2*num_ticks);
    pt_plot(1:2:end) = pulse_times(:,i);
    pt_plot(2:2:end) = pulse_times(:,i);
    
    pulse_count = zeros(1,2*num_ticks);
    pulse_count(2:2:end) = 1;
    
    subplot(3,1,1)
    hold on
    plot(pt_plot, cumsum(pulse_count),'Color',mycolor(i,:));
    
    rt(i) = pulse_times(end,i);
    drift(i) = 1/mean(y(:,i));

end
parameter_string = sprintf('Duration: %0.3f, Pulse rate: %0.3f, \nStd(inter-pulse dur): %0.3f, Correlation: %0.3f, # trials: %d\n',...
    duration, tick_rate, interpulse_std, correlation, num_trials );
title([ parameter_string, 'Pulse count trajectories' ],'FontSize',18)
xlabel('Time (e.g., seconds)')
ylabel('Pulse count')
xlimits = get(gca,'XLim');
plot(xlimits,num_ticks*[1 1], 'k--')

% Plot out response time histogram:
subplot(3,1,2)
hist(rt,30)
xlabel('Response time')
ylabel('Trial counts')
title(sprintf('RT histogram--- CV=%0.3f, skew=%0.3f', std(rt)/mean(rt), skewness(rt)),'FontSize',18)

% Plot out inter[ulse duration histogram:
subplot(3,1,3)
hist(drift,30)
title('Drift (1/inter-pulse duration) histogram','FontSize',18)
xlabel('1 / inter-pulse duration')
ylabel('Trial counts')

% Taking corr(y') gives correlation of tick 1 values with tick 2 values,
% and i with j more generally.
% keyboard



% Now plot out some densities of inter-pulse durations within trials,
% overall, and then across trials
figure
subplot(2,1,1)
hold on
for i = 1:num_trials
    [f,xi] = ksdensity( y(:,i) );
    plot(xi,f,'Color',mycolor(i,:))
end
[f,xi] = ksdensity( ylist );
plot(xi,f,'k','LineWidth',2);
title(sprintf('Within-trial inter-pulse durations \n(each density corresponds to one trial; thick plot is average over all trials)'))

subplot(2,1,2)
hold on
for i=1:num_ticks
    [f,xi] = ksdensity( y(i,:) );
    if i==1
        plot(xi,f,'r');
        % NOTE: Strangely, the first pulse seems noticeably different in
        % its distribution across trials than all subsequent pulses, and
        % the difference seems bigger the lower the correlation between
        % inter-pulse durations. And the L matrix values seem to indicate
        % why (the element at position (1,1) is always highest).
    else
        plot(xi,f);
    end
end
title(sprintf('Across-trial inter-pulse durations, pulse by pulse \n(each density corresponds to a given pulse number)'))

    
fprintf(sprintf('Coefficient of variation of response times: %0.3f\n\n\n', std(rt)/mean(rt) ))

    
    