function D = fit_models( rt )

% D = fit_models( rt )
%
% RT data is assumed to be an N-rows x 1-column vector of RT data
% The function fits three predicted RT distributions to the data, and
% returns negative log likelihood results for each. These models all
% contain the same number of parameters, so no AIC or BIC test for model
% complexity is needed. The return arguments of the fitdist command can be
% examined more closely to get fitted parameter values, etc., than we have
% done here.
%
% Example (here, the example generates fake data first, then fits it):
%   rt = opponent_Poisson_Appendix3;
%   D = fit_models( rt' );  % Note transpose of rt
% We then select the model with the lowest negative log likelihood value.
% These values can be found by entering the command:
%   D.nll
% This command displays three values:
%   D.nll.nll_IG2 (if this is lowest, the inverse Gaussian distribution and
%       TopDDM is favored)
%   D.nll.G2 (if this is lowest, the gamma distribution/BeT is favored)
%   D.nll.N2 (if this is lowest, the normal distribution/SET is favored)
%
% Copyright 2016, Patrick Simen
% Freely reuseable under the GNU General Public License 2.0 or greater

figure
hold on

rtsorted = sort(rt);

pdIG2fit = fitdist(rt, 'InverseGaussian');
pdG2fit = fitdist(rt, 'Gamma');
pdN2fit = fitdist(rt, 'Normal');

cdf_IG2fit = cdf(pdIG2fit, rtsorted);
cdf_Gam2fit = cdf(pdG2fit, rtsorted);
cdf_Norm2fit = cdf(pdN2fit, rtsorted);

plot(rtsorted, cdf_IG2fit,'b')
plot(rtsorted, cdf_Gam2fit, 'g')
plot(rtsorted, cdf_Norm2fit, 'r')

plot(rtsorted, 1/length(rt)*cumsum(ones(1,length(rt))), 'k');
title('InvGau = blue, Gamma = green, Normal = red');

D.nll.nll_IG2 = pdIG2fit.NLogL;
D.nll.nll_G2 = pdG2fit.NLogL;
D.nll.nll_N2 = pdN2fit.NLogL;
