# Script for generic condition plot 
# Script accomodates 4 conditions

# Set working directory (Folder where data are)
workDir = "/Plotting_Scripts"
setwd(workDir)

# Figure Directory
figDir <- paste(workDir, "/Figures", sep = "")
dir.create(file.path(figDir), showWarnings = FALSE)

# Enter name of plot to save it as
plot_filename <- 'Bisection_Condition_Plot.png'

# Enter values on y and x-axis
y_values <- c(2.4, 5.6, 4.3, 3)                 # Data for the different conditions
cond_name_1 <- "Condition 1"                    # Name for condition 1
cond_name_2 <- "Condition 2"                    # Name for condition 2
cond_name_3 <- "Condition 3"                    # Name for condition 3
cond_name_4 <- "Condition 4"                    # Name for condition 4

# Axis parameters
x_axis_name <- "Conditions"                     # name of x axis
y_axis_name <- "p('long')"                      # name of y axis
ylim <- c(0, 6)                                 # limits for y-axis
y_spacing <- seq(from = 0, to = 6, by = 2)      # Specify spacing for the y-axis, upper limit, lower limit and step size

# Additional parameters
line_width <- 1                                 # Line width
point_shape <- 1                                # Shape of the datapoints
point_thickness <- 1.5                          # Line thickness of points
point_size <- 4                                 # Size of the point
line_color <- "black"                           # Colour of line
point_colour <- "black"                         # Colour of points

base_text_size <- 25                            # Increasing/decreasing this will change the size of all text in graph proportionally

###############################################################################################
# Load library
library(ggplot2)

# Source SE computation functions, might not be needed
# source("calculate_SEwithin_functions.R")

n_cond <- NROW(y_values)

# Combine data
if (n_cond == 4) {
  data_plot <- data.frame(Condition = c(cond_name_1, cond_name_2, cond_name_3, cond_name_4),
                          yval = y_values)
} else if (n_cond == 3) {
  data_plot <- data.frame(Condition = c(cond_name_1, cond_name_2, cond_name_3),
                          yval = y_values)
} else if (n_cond == 2) {
  data_plot <- data.frame(Condition = c(cond_name_1, cond_name_2),
                          yval = y_values)
} else if (n_cond == 1) {
  data_plot <- data.frame(Condition = c(cond_name_1),
                          yval = y_values)
}

# Plot data
cond_plot <- ggplot(data = data_plot, aes(x = Condition, y = yval, group = 1)) +
  geom_line(colour = line_color, size = line_width) + 
  geom_point(colour = point_colour, shape = point_shape, stroke = point_thickness, size = point_size) +
  scale_x_discrete(name = x_axis_name) +  
  scale_y_continuous(name = y_axis_name, limits = ylim, breaks = y_spacing) + 
  theme_bw(base_size = base_text_size) %+replace%
  theme(plot.title = element_text(hjust = 0.5), 
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

# Save plots
ggsave(filename = plot_filename, plot = cond_plot, device = "png", path = figDir,
       width = 300, height = 300, units = "mm", dpi = 300)

print(cond_plot)



