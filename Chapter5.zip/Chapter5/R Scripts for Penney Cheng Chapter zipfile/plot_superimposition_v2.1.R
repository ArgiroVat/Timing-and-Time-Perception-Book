# For superimposition plots
# To fit 3 plots

# Set working directory (Folder where data are)
workDir = "/Plotting_Scripts"
setwd(workDir)

# Figure Directory
figDir <- paste(workDir, "/Figures", sep = "")
dir.create(file.path(figDir), showWarnings = FALSE)

# Plot filename
plot_filename = "bisection_superimposition_Fig.png"

# Load library
library(ggplot2)
library(pracma)

# Source the functions needed for the PLM fitting 
source("fitting_functions.R")

####################### ENTER DATA TO PLOT #######################

# First set of anchor durations and proportion data
prop_data1 <- c(0, 0, 0, 0.4, 0.8, 1.0, 1.0)       # Proportion data
anchor_dur1 <- c(0.8, 3.2)                         # Enter anchor durations to use
n_dur1 <- 7                                        # No of durations needed, script will create logarithmically spaced durations based on this and anchor

# Second set of anchor durations and proportion data
prop_data2 <- c(0, 0, 0, 0.3, 0.7, 0.9, 1.0)       # Proportion data
anchor_dur2 <- c(1.2, 3.6)                         # Enter anchor durations to use
n_dur2 <- 7                                        # No of durations needed, script will create logarithmically spaced durations based on this and anchor

# Third set of anchor durations and proportion data
prop_data3 <- c(0, 0, 0, 0.4, 0.6, 0.7, 1.0)       # Proportion data
anchor_dur3 <- c(1.5, 3.0)                         # Enter anchor durations to use
n_dur3 <- 7                                        # No of durations needed, script will create logarithmically spaced durations based on this and anchor

n_ancdur_cond <- 3                                 # No of sets of anchor durations

####################### PLOT PARAMETERS FOR ADJUSTMENT #######################

# Graph parameters to adjust
x_axis_name <- "Normalised Duration(s)"         # name of x axis
y_axis_name <- "p('long')"                      # name of y axis
ylim <- c(0, 1)                                 # limits for y-axis
y_spacing <- seq(from = 0, to = 1, by = 0.25)   # Specify spacing for the y-axis, upper limit, lower limit and step size
xlim <- c(0.4, 1.6)                             # limits for x-axis
x_spacing <- seq(0.4, 1.6, 0.2)                 # Spacify spacing for the x-axis
base_text_size <- 25                            # Increasing/decreasing this will change the size of all text in graph proportionally
point_thickness <- 1.5                          # Thickness of the data points
point_size <- 6                                 # Size of the data points
line_width <- 1                                 # Line thickness for raw data connecting line
fitted_line_width <- 1.5                        # Line thickness for fitted line

# Additional parameters for superimposition plots
anchor_name_1 <- "Anchors: 0.8, 3.2"            # Legend name/label for first group in fit model plots
anchor_name_2 <- "Anchors: 1.2, 3.6"            # Legend name/label for second group in fit model plots
anchor_name_3 <- "Anchors: 1.5, 3.0"            # Legend name/label for third group in fit model plots
anchor_shape_1 <- 1                             # Shape for subject data points (first group)
anchor_shape_2 <- 3                             # Shape for subject data points (second group)
anchor_shape_3 <- 5                             # Shape for subject data points (third group)
anchor_col_1 <- "blue"                          # Colour for first anchor group
anchor_col_2 <- "orange"                        # Colour for first anchor group
anchor_col_3 <- "green"                         # Colour for first anchor group

legend_title_sess <- "Anchor Durations"         # Legend title for session plots

# Plotting options
plot_rawdata_point <- 1                         # Show proportion points
plot_rawdata_line <- 1                          # Draw a line between the points
plot_fitted_line <- 1                           # Plot fitted line

# Fiting method
fit_select <- 4                                 # Fitting method, 1 = PLM, 2 = Sigmoid, 3 = Weibull, 4 = linear

####################### COMPUTE DURATION ARRAY #######################

dur_array1 <- round(logspace(log10(anchor_dur1[1]), log10(anchor_dur1[2]), n = n_dur1), digits = 2)

dur_array2 <- round(logspace(log10(anchor_dur2[1]), log10(anchor_dur2[2]), n = n_dur2), digits = 2)

dur_array3 <- round(logspace(log10(anchor_dur3[1]), log10(anchor_dur3[2]), n = n_dur3), digits = 2)

####################### FIT DATA #######################

# Fit data based on selected model
fit_param1 <- bisection_optim_resp_function(anchor_dur = anchor_dur1, 
                                            xdata = dur_array1, 
                                            ydata = prop_data1, 
                                            fit_method = fit_select)
fit_param2 <- bisection_optim_resp_function(anchor_dur = anchor_dur2, 
                                            xdata = dur_array2, 
                                            ydata = prop_data2, 
                                            fit_method = fit_select)
fit_param3 <- bisection_optim_resp_function(anchor_dur = anchor_dur3, 
                                            xdata = dur_array3, 
                                            ydata = prop_data3, 
                                            fit_method = fit_select)

fit_param_all <- data.frame(DurCond = seq(1,n_ancdur_cond,1),
                            rbind(fit_param1$par, fit_param2$par, fit_param3$par))

# Compute DL, WF and PSE
timing_param_temp1 <- compute_DL_WF(fit_param1$par, fit_select)
timing_param_temp2 <- compute_DL_WF(fit_param2$par, fit_select)
timing_param_temp3 <- compute_DL_WF(fit_param3$par, fit_select)

# Normalise durations
norm_dur_array1 <- dur_array1/timing_param_temp1$PSE
norm_dur_array2 <- dur_array2/timing_param_temp2$PSE
norm_dur_array3 <- dur_array3/timing_param_temp3$PSE
norm_anchor_dur1 <- anchor_dur1/timing_param_temp1$PSE
norm_anchor_dur2 <- anchor_dur2/timing_param_temp2$PSE
norm_anchor_dur3 <- anchor_dur3/timing_param_temp3$PSE

timing_param <- data.frame(short_anchor = c(anchor_dur1[1], anchor_dur2[1], anchor_dur3[1]),
                           long_anchor = c(anchor_dur1[2], anchor_dur2[2], anchor_dur3[2]),
                           DL = c(timing_param_temp1$DL, timing_param_temp2$DL, timing_param_temp3$DL),
                           WF = c(timing_param_temp1$WF, timing_param_temp2$WF, timing_param_temp3$WF),
                           PSE = c(timing_param_temp1$PSE, timing_param_temp2$PSE, timing_param_temp3$PSE))

norm_anchor_dur_all <- rbind(norm_anchor_dur1, norm_anchor_dur2, norm_anchor_dur3)
min_anchor <- min(norm_anchor_dur_all)
max_anchor <- max(norm_anchor_dur_all)

dur_array_finegrain1 <- seq(min_anchor, max_anchor, length.out = 1000)
dur_array_finegrain2 <- seq(min_anchor, max_anchor, length.out = 1000)
dur_array_finegrain3 <- seq(min_anchor, max_anchor, length.out = 1000)

# Compute the parameters after the normalisation
fit_norm_param1 <- bisection_optim_resp_function(anchor_dur = norm_anchor_dur1, 
                                                 xdata = norm_dur_array1, 
                                                 ydata = prop_data1, 
                                                 fit_method = fit_select)
fit_norm_param2 <- bisection_optim_resp_function(anchor_dur = norm_anchor_dur2, 
                                                 xdata = norm_dur_array2, 
                                                 ydata = prop_data2, 
                                                 fit_method = fit_select)
fit_norm_param3 <- bisection_optim_resp_function(anchor_dur = norm_anchor_dur3, 
                                                 xdata = norm_dur_array3, 
                                                 ydata = prop_data3, 
                                                 fit_method = fit_select)
fit_norm_param_all <- data.frame(DurCond = seq(1,n_ancdur_cond,1),
                                 rbind(fit_norm_param1$par, fit_norm_param2$par, fit_norm_param3$par))

if (fit_select == 1) {
  
  pLong_pred1 <- PLM_fit(dur_array_finegrain1, fit_norm_param1$par)
  pLong_pred2 <- PLM_fit(dur_array_finegrain2, fit_norm_param2$par)
  pLong_pred3 <- PLM_fit(dur_array_finegrain3, fit_norm_param3$par)
  
} else if (fit_select == 2) {
  
  pLong_pred1 <- Sigmoid_fit(dur_array_finegrain1, fit_norm_param1$par)
  pLong_pred2 <- Sigmoid_fit(dur_array_finegrain2, fit_norm_param2$par)
  pLong_pred3 <- Sigmoid_fit(dur_array_finegrain3, fit_norm_param3$par)
  
} else if (fit_select == 3) {
  
  pLong_pred1 <- Weibull_fit(dur_array_finegrain1, fit_norm_param1$par)
  pLong_pred2 <- Weibull_fit(dur_array_finegrain2, fit_norm_param2$par)
  pLong_pred3 <- Weibull_fit(dur_array_finegrain3, fit_norm_param3$par)

} else if (fit_select == 4) {
  
  pLong_pred1 <- Linear_regress_fit(dur_array_finegrain1, fit_norm_param1$par)
  pLong_pred2 <- Linear_regress_fit(dur_array_finegrain2, fit_norm_param2$par)
  pLong_pred3 <- Linear_regress_fit(dur_array_finegrain3, fit_norm_param3$par)
  
}

####################### COMBINE DATA FOR PLOTTING #######################

# Raw data
dur_cond_list <- list(matrix(1, nrow = n_dur1, ncol = 1),
                      matrix(2, nrow = n_dur2, ncol = 1),
                      matrix(3, nrow = n_dur3, ncol = 1))
dur_cond_mat <- do.call(rbind,dur_cond_list)

duration_list <- list(matrix(norm_dur_array1, nrow = n_dur1, ncol = 1),
                      matrix(norm_dur_array2, nrow = n_dur2, ncol = 1),
                      matrix(norm_dur_array3, nrow = n_dur3, ncol = 1))
duration_mat <- do.call(rbind, duration_list)

prop_list <- list(matrix(prop_data1, nrow = n_dur1, ncol = 1),
                  matrix(prop_data2, nrow = n_dur2, ncol = 1),
                  matrix(prop_data3, nrow = n_dur3, ncol = 1))
prop_mat <- do.call(rbind, prop_list)

data_prop_raw <- data.frame(plottype = rep(1, times = n_dur1 + n_dur2 + n_dur3), 
                            DurCond = dur_cond_mat,
                            Duration = duration_mat,
                            pLong = prop_mat)

# Predicted data
dur_cond_pred_list <- list(matrix(1, nrow = 1000, ncol = 1),
                           matrix(2, nrow = 1000, ncol = 1),
                           matrix(3, nrow = 1000, ncol = 1))
dur_cond_pred_mat <- do.call(rbind,dur_cond_pred_list)

duration_fg_list <- list(matrix(dur_array_finegrain1, nrow = 1000, ncol = 1),
                         matrix(dur_array_finegrain2, nrow = 1000, ncol = 1),
                         matrix(dur_array_finegrain3, nrow = 1000, ncol = 1))
duration_fg_mat <- do.call(rbind, duration_fg_list)

prop_pred_list <- list(matrix(pLong_pred1, nrow = 1000, ncol = 1),
                  matrix(pLong_pred2, nrow = 1000, ncol = 1),
                  matrix(pLong_pred3, nrow = 1000, ncol = 1))
prop_pred_mat <- do.call(rbind, prop_pred_list)

data_prop_pred <- data.frame(plottype = rep(2, times = 1000*3), 
                            DurCond = dur_cond_pred_mat,
                            Duration = duration_fg_mat,
                            pLong = prop_pred_mat)

# Combine data
data_plot_all <- rbind(data_prop_raw, data_prop_pred)

####################### PLOT DATA #######################

superimpose_plot <- ggplot(data = data_plot_all)

if (plot_rawdata_point == 1) {
  
  superimpose_plot <- superimpose_plot + 
    geom_point(data = subset(data_plot_all, plottype == 1 & DurCond == 1), 
               aes(x = Duration, y = pLong, colour = "DurSet_1", shape = "DurSet_1"), 
               stroke = point_thickness, size = point_size) + 
    geom_point(data = subset(data_plot_all, plottype == 1 & DurCond == 2), 
               aes(x = Duration, y = pLong, colour = "DurSet_2", shape = "DurSet_2"), 
               stroke = point_thickness, size = point_size) + 
    geom_point(data = subset(data_plot_all, plottype == 1 & DurCond == 3), 
               aes(x = Duration, y = pLong, colour = "DurSet_3", shape = "DurSet_3"), 
               stroke = point_thickness, size = point_size) +
    scale_shape_manual(name = legend_title_sess, 
                       values = c("DurSet_1" = anchor_shape_1, 
                                  "DurSet_2" = anchor_shape_2,
                                  "DurSet_3" = anchor_shape_3), 
                       labels = c(anchor_name_1, anchor_name_2, anchor_name_3)) 
  
}

if (plot_rawdata_line == 1) {
  
  superimpose_plot <- superimpose_plot + 
    geom_line(data = subset(data_plot_all, plottype == 1 & DurCond == 1),
              aes(x = Duration, y = pLong, colour = "DurSet_1"), size = line_width) + 
    geom_line(data = subset(data_plot_all, plottype == 1 & DurCond == 2),
              aes(x = Duration, y = pLong, colour = "DurSet_2"), size = line_width) + 
    geom_line(data = subset(data_plot_all, plottype == 1 & DurCond == 3),
              aes(x = Duration, y = pLong, colour = "DurSet_3"), size = line_width)
}

if (plot_fitted_line == 1) {
  
  superimpose_plot <- superimpose_plot +
    geom_line(data = subset(data_plot_all, plottype == 2 & DurCond == 1),
              aes(x = Duration, y = pLong, colour = "DurSet_1"), 
              linetype = "dashed", size = fitted_line_width) +
    geom_line(data = subset(data_plot_all, plottype == 2 & DurCond == 2),
              aes(x = Duration, y = pLong, colour = "DurSet_2"), 
              linetype = "dashed", size = fitted_line_width) + 
    geom_line(data = subset(data_plot_all, plottype == 2 & DurCond == 3),
              aes(x = Duration, y = pLong, colour = "DurSet_3"), 
              linetype = "dashed", size = fitted_line_width)
}

# Add in colour of lines and points
superimpose_plot <- superimpose_plot +
  scale_colour_manual(name = legend_title_sess,
                      values = c("DurSet_1" = anchor_col_1, 
                                 "DurSet_2" = anchor_col_2, 
                                 "DurSet_3" = anchor_col_3),
                      labels = c(anchor_name_1, anchor_name_2, anchor_name_3))


# Change aesthetics of graph
superimpose_plot <- superimpose_plot + 
  scale_x_continuous(name = x_axis_name, limits = xlim, breaks = x_spacing) +  
  scale_y_continuous(name = y_axis_name, limits = ylim, breaks = y_spacing) + 
  theme_bw(base_size = base_text_size) %+replace%
  theme(plot.title = element_text(hjust = 0.5), 
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        axis.line = element_line(colour = "black"))

# Save plots
ggsave(filename = plot_filename, plot = superimpose_plot, device = "png", path = figDir,
       width = 300, height = 300, units = "mm", dpi = 300)

print(superimpose_plot)






