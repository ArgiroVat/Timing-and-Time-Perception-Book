##########################################################################
##################### THE RESPONSE FUNCTIONS TO FIT  #####################
##########################################################################

PLM_fit <- function(used_dur, est_pars) #Pseudo Logistic Model - PLM
{
  PSE_est <- est_pars[1]
  g_est <- est_pars[2]
  
  # Can be changed to other response functions for fitting
  y_pred <- 1/(1+exp((PSE_est-used_dur)/((sqrt(3)/pi)*g_est*used_dur)))
  y_pred
}

Sigmoid_fit <- function(used_dur, est_pars)
{
  alpha_est <- est_pars[1]
  beta_est <- est_pars[2]
  lambda_est <- est_pars[3]
  
  y_pred <- lambda_est/(1+exp((-used_dur+alpha_est)/beta_est))
  y_pred
  
}

Weibull_fit <- function(used_dur, est_pars)
{
  alpha_est <- est_pars[1]
  beta_est <- est_pars[2]
  lambda_est <- est_pars[3]
  gamma_est <- est_pars[4]
  
  y_pred <- gamma_est + ((1-gamma_est-lambda_est)*(1-exp(-((used_dur/alpha_est)^beta_est))))
  y_pred
}

Linear_regress_fit <- function(used_dur, est_pars)
{
  beta_est <- est_pars[1]
  lambda_est <- est_pars[2]
  
  y_pred <- beta_est*(used_dur) + lambda_est
  y_pred
  
}

err_function <- function(est_pars)
{
  if (fit_choice == 1) {
    
    y_pred <- PLM_fit(used_dur, est_pars)
    SSE <- sum((y_pred - prop_data)^2)  
    
  } else if (fit_choice == 2) {
    
    y_pred <- Sigmoid_fit(used_dur, est_pars)
    SSE <- sum((y_pred - prop_data)^2)  
    
  } else if (fit_choice == 3) {
    
    y_pred <- Weibull_fit(used_dur, est_pars)
    SSE <- sum((y_pred - prop_data)^2)  
    
  } else if (fit_choice == 4) {
    
    y_pred <- Linear_regress_fit(used_dur, est_pars)
    SSE <- sum((y_pred - prop_data)^2)  
    
  }
}

bisection_optim_resp_function <- function(anchor_dur, xdata, ydata, fit_method)
{
  
  # Create global x values for durations used, for linear fit, only take midpoints values
  if (fit_method == 4) {
    
    N_datapt <- NROW(xdata)
    xdata_trimmed <- xdata[3:(N_datapt-2)]
    ydata_trimmed <- ydata[3:(N_datapt-2)]
    used_dur <<- xdata_trimmed
    prop_data <<- ydata_trimmed
    fit_choice <<- fit_method
    
  } else if (fit_method != 4) {
    used_dur <<- xdata
    prop_data <<- ydata
    fit_choice <<- fit_method
  }

  if (fit_choice == 1) { # PLM
    
    # Establish starting values
    PSE_start <- sum(anchor_dur)/2
    g_start <- 0.1
    start_par <- c(PSE_start, g_start)
    
  } else if (fit_choice == 2) { # sigmoid function
    
    # Establish starting values
    alpha_start <- 0.3
    beta_start <- 0.5
    lambda_start <- 0.2
    start_par <- c(alpha_start, beta_start, lambda_start)
    
  } else if (fit_choice == 3) { # Weibull function
    
    # Establish starting values
    alpha_start <- 1
    beta_start <- 1
    lambda_start <- 1
    gamma_start <- 0.5
    start_par <- c(alpha_start, beta_start, lambda_start, gamma_start)
    
  } else if (fit_choice == 4) {
    
    # Establish starting values
    beta_start <- 0.5
    lambda_start <- 0.7
    start_par <- c(beta_start, lambda_start)
    
  }
  
  fit_pars <- optim(par = start_par, fn = err_function, 
                    gr = NULL, method = "Nelder-Mead",
                    control = list(maxit = 10000))
  fit_pars
}

##########################################################################
######################## FOR COMPUTING DL AND WF  ########################
##########################################################################

pred_duration_PLM <- function(y_prop, est_pars) 
{
  
  PSE_est <- est_pars[1]
  g_est <- est_pars[2]
  
  pred_dur <- PSE_est/((sqrt(3)/pi)*g_est*log((1-y_prop)/y_prop)+1)
  pred_dur
  
}

pred_duration_sig <- function(y_prop, est_pars)
{
  alpha_est <- est_pars[1]
  beta_est <- est_pars[2]
  lambda_est <- est_pars[3]
  
  pred_dur <- ((-beta_est)*(log((lambda_est-y_prop)/y_prop))) + alpha_est
  pred_dur
  
}

pred_duration_weibull <- function(y_prop, est_pars)
{
  alpha_est <- est_pars[1]
  beta_est <- est_pars[2]
  lambda_est <- est_pars[3]
  gamma_est <- est_pars[4]
  
  c <- (1-((y_prop-gamma_est)/(1-gamma_est-lambda_est)))
  
  pred_dur <- alpha_est*(-log(c))^(1/beta_est)
  pred_dur
  
}

pred_duration_linear <- function(y_prop, est_pars)
{
  beta_est <- est_pars[1]
  lambda_est <- est_pars[2]
  
  pred_dur <- (y_prop-lambda_est)/beta_est
  pred_dur
  
}

compute_DL_WF <- function(est_pars, fit_method) 
{
  if (fit_method == 1) {
    
    pLong_025 <- pred_duration_PLM(0.25, est_pars)
    pLong_075 <- pred_duration_PLM(0.75, est_pars)
    PSE <- pred_duration_PLM(0.50, est_pars)
    
    diff_limen <- (pLong_075-pLong_025)/2
    weber_frac <- diff_limen/PSE
    
  } else if (fit_method == 2) {
    
    pLong_025 <- pred_duration_sig(0.25, est_pars)
    pLong_075 <- pred_duration_sig(0.75, est_pars)
    PSE <- pred_duration_sig(0.50, est_pars)
    
    diff_limen <- (pLong_075-pLong_025)/2
    weber_frac <- diff_limen/PSE
    
  } else if (fit_method == 3) {
    
    pLong_025 <- pred_duration_weibull(0.25, est_pars)
    pLong_075 <- pred_duration_weibull(0.75, est_pars)
    PSE <- pred_duration_weibull(0.50, est_pars)
    
    diff_limen <- (pLong_075-pLong_025)/2
    weber_frac <- diff_limen/PSE

  } else if (fit_method == 4) {
    
    pLong_025 <- pred_duration_linear(0.25, est_pars)
    pLong_075 <- pred_duration_linear(0.75, est_pars)
    PSE <- pred_duration_linear(0.50, est_pars)
    
    diff_limen <- (pLong_075-pLong_025)/2
    weber_frac <- diff_limen/PSE
    
  }
  
  timing_param <- list(DL = diff_limen, 
                       WF = weber_frac,
                       PSE = PSE)
  timing_param
  
}
























