function DoVisualLearning(window, param, training_stim)

fps = param.fps;
ifi = param.ifi;

ListenChar(2)
HideCursor;

%% Start Learning Trials

vbl = Screen('Flip', window);

for i_learning_trial = 1:param.nlearning_trials
    
    learning_dur = training_stim.learning_dur_arr(i_learning_trial);
    learning_ITI = training_stim.learning_ITI_arr(i_learning_trial);
    learning_fix_cross_dur = training_stim.learning_fix_cross_arr(i_learning_trial);
        
    %%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS: TO RUN JUST BEFORE FIRST LEARNING TRIAL %%%%%%%%%%%%%%%%%%
    if i_learning_trial == 1
        
        % Wait for input from scanner to trigger trial
        Screen('TextSize', window, param.text_size);
        
        learning_text = sprintf(['Remember the duration that the black square \nstays on the screen.\n\n' ...
            'Two durations, one long and one short, \nwill be presented.\n\n' ...
            'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
            'Press <SPACE> to continue.']);
        DrawFormattedText(window, learning_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi);
        while 1
            [keyIsDown, secs, keyCode, deltaSecs] = KbCheck(param.kbID);
            if keycode(param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            elseif keycode(param.key_space)
                break
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('\nLearning Trial %d: Anchor duration presented is %1.2f s.\n\n', i_learning_trial, learning_dur);

    CheckForEscape(param.key_escape, param.kbID)
    
    % Fixation Cross
    Screen('FillRect', window, param.backgrd_col);
    Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(learning_fix_cross_dur);
    
    % Timing Stimulus
    nframes_learn = fps*learning_dur;
    
    for i_frame = 1:nframes_learn
        Screen('FillRect', window, param.stim_col, param.centered_sq)
        Screen('DrawTexture', window, param.fix_cross_timestim_bg, [], param.rect_cross);
        vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    end
    
    % Feedback Text
    Screen('TextSize', window, param.fb_resp_text_size);
    
    if learning_dur == param.short_anchor
        feedback_text = sprintf('That was the SHORT duration.');
    elseif learning_dur == param.long_anchor
        feedback_text = sprintf('That was the LONG duration.');
    end
    
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, feedback_text, 'center', 'center', param.stim_col);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(param.fb_dur);
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % ITI
    Screen('FillRect', window, param.backgrd_col);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(learning_ITI);
    
    CheckForEscape(param.key_escape, param.kbID)
    
end

ListenChar(1)
ShowCursor;

