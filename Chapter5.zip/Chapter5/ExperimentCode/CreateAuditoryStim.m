% Change Log:
% 07.12.2016   xq   Written
% 23.02.2017   xq   Disabled option to overwrite audio files, instead,
%                   script will check for existence of specified .wav file
%                   and only create the .wav file if it does not exist. If
%                   file exist, creation of .wav file skipped


function CreateAuditoryStim(param)

% if exist(param.sndDir, 'dir')
%     fprintf('Sound directory %s exist.\n', param.sndDir)
%     ow_audio = input('Overwrite all audio files in sound directory (y = yes, n = no)?', 's');
%     
%     if strcmp(ow_audio, 'y')
%         fprintf('\nOverwriting audio files... \n\n')
%     elseif strcmp(ow_audio, 'n')
%         fprintf('\nAudio files will not be overwritten. \nContinuing on to the training phase... \n\n')
%         return
%     end
% elseif (~exist(param.sndDir, 'dir'))
%     mkdir(param.sndDir)
% end

% Make output directory
if (~exist(param.sndDir, 'dir'))
    mkdir(param.sndDir)
end

%% Define sound output settings

samp_period = 1/param.samp_freq;
omega = 2*pi*param.snd_freq; % angular frequency



for i_dur = 1:param.ndur
    
    duration = param.dur_all(i_dur);
    snd_fn = ['freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(duration*1000) 'ms.wav'];    
    snd_outpath = [param.sndDir filesep snd_fn];
    
    % Check if sound file is there
    if exist(snd_outpath, 'file')
        continue
    end
    
    time_vector = 0:samp_period:duration;
    rise = (0:param.samp_freq*param.rise_fall_time)/(param.samp_freq*param.rise_fall_time); % multiplication factor for rise
    snd_env = [rise ones(1, size(time_vector,2) - 2*length(rise)) fliplr(rise)]; % factor envelope
    snd = sin(omega*time_vector).*snd_env;
    % snd = snd./max(abs(snd(:)))*(1-(2^-(16-1))); % normalise wav within limit of -1 <= w < 1 to prevent data clipping, uncomment if using wavwrite
    stereo_snd = [snd; snd]';
    audiowrite(snd_outpath, stereo_snd, param.samp_freq)

end
    















