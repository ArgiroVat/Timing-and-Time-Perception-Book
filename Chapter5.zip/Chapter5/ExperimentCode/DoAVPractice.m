function [training_res] = DoAVPractice(window, pahandle, param, training_stim, training_res)

fps = param.fps;
ifi = param.ifi;

ListenChar(2)
HideCursor;

%% Start Practice Trials

vbl = Screen('Flip', window);
nmodality = length(param.exp_code);

for i_prac_trial = 1:param.nprac_trials*nmodality
    
    prac_modality = training_stim.prac_modality_arr{param.prac_count}{i_prac_trial,1};
    prac_dur = training_stim.prac_dur_arr{param.prac_count}(i_prac_trial,1);
    prac_ITI = training_stim.prac_ITI_arr{param.prac_count}(i_prac_trial,1);
    prac_fix_cross_dur = training_stim.prac_fix_cross_arr{param.prac_count}(i_prac_trial,1);
    
    % Fill buffer with audio file needed
    if prac_dur == param.short_anchor
        PsychPortAudio('FillBuffer', pahandle, param.short_anc_wav);
    elseif prac_dur == param.long_anchor
        PsychPortAudio('FillBuffer', pahandle, param.long_anc_wav);
    end
    
    % Correct response
    if param.resp_config == 1 && prac_dur == param.short_anchor
        corr_resp_key = param.key_left;
    elseif param.resp_config == 1 && prac_dur == param.long_anchor
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && prac_dur == param.short_anchor
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && prac_dur == param.long_anchor
        corr_resp_key = param.key_left;
    end
    
    %%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS: TO RUN JUST BEFORE FIRST PRACTICE TRIAL %%%%%%%%%%%%%%%%%%
    if i_prac_trial == 1
        
        % Wait for input from scanner to trigger trial
        Screen('TextSize', window, param.text_size);
        
        if param.resp_config == 1
            prac_text = sprintf(['Classify the presented durations as SHORT or LONG\nbased on previously learned durations.\n\n' ...
                'Press <z> to indicate that presented duration is SHORT.\n' ...
                'Press <m> to indicate that presented duration is LONG.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        elseif param.resp_config == 2
            prac_text = sprintf(['Classify the presented durations as SHORT or LONG\nbased on previously learned durations.\n\n' ...
                'Press <z> to indicate that presented duration is LONG.\n' ...
                'Press <m> to indicate that presented duration is SHORT.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        end
        DrawFormattedText(window, prac_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi);
        while 1
            [keyIsDown, secs, keyCode, deltaSecs] = KbCheck(param.kbID);
            if keyCode(param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            elseif keyCode(param.key_space)
                break
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('\nPractice Trial %d: Anchor duration presented is %1.2f s.\n\n', i_prac_trial, prac_dur);
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % Fixation Cross
    Screen('FillRect', window, param.backgrd_col);
    Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(prac_fix_cross_dur);
    
    % Calculate the length of the sound in frames
    nframes_prac = round(fps*prac_dur);
    
    % Present timing stimuli
    switch prac_modality
        case 'A'
            % Start sound playback
            PsychPortAudio('Start', pahandle, param.repetitions, param.snd_startcue, param.snd_waitfordevice);
            
            % Fixation cross will be presented during sound playback
            for i_frame = 1:nframes_prac
                Screen('FillRect', window, param.backgrd_col);
                Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
                vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
            end
            
            % Stop sound playback
            [actualStartTime, endPositionSecs, xruns, estStopTime] = PsychPortAudio('Stop', pahandle, 1, 1);
        case 'V'
            % Balck square
            for i_prac_frame = 1:nframes_prac
                Screen('FillRect', window, param.stim_col, param.centered_sq)
                Screen('DrawTexture', window, param.fix_cross_timestim_bg, [], param.rect_cross);
                vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
            end
    end
    
    % Capture Response
    Screen('TextSize', window, param.fb_resp_text_size);
    
    if param.resp_config == 1
        resp_text = sprintf('SHORT                      LONG');
    elseif param.resp_config == 2
        resp_text = sprintf('LONG                       SHORT');
    end
    
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, resp_text, 'center', 'center', param.stim_col);
    [vbl, resp_starttime] = Screen('Flip', window, vbl+0.2*ifi, 1);
    t_startresp = resp_starttime;
    
    keyisdown = 0;
    while(~keyisdown)
        t_endresp = GetSecs;
        [keyisdown, secs, keyCode] = KbCheck(param.kbID);
        
        if t_endresp - t_startresp > param.max_resp_time
            resp_keycode = 999; % No response
            keyisdown = 1;
        elseif keyisdown ~= 0
            if (find(keyCode == 1) == param.key_left) || (find(keyCode == 1) == param.key_right)
                resp_keycode = find(keyCode == 1);
                keyisdown = 1;
            elseif (find(keyCode == 1) == param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            else
                keyisdown = 0;
            end
        end
    end
    
    resp_arr(i_prac_trial,:) = resp_keycode;
    
    % Feedback
    if resp_keycode == corr_resp_key && prac_dur == param.short_anchor
        fb_prac_text = 'Correct -- It was SHORT.';
        accuracy = 1;
    elseif resp_keycode == corr_resp_key && prac_dur == param.long_anchor
        fb_prac_text = 'Correct -- It was LONG.';
        accuracy = 1;
    elseif resp_keycode ~= corr_resp_key && prac_dur == param.short_anchor
        fb_prac_text = 'Incorrect -- It was SHORT.';
        accuracy = 0;
    elseif resp_keycode ~= corr_resp_key && prac_dur == param.long_anchor
        fb_prac_text = 'Incorrect -- It was LONG.';
        accuracy = 0;
    end
    
    if resp_keycode == 999 && accuracy == 0
        accuracy = 999;
    end
    
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, fb_prac_text, 'center', 'center', param.stim_col);
    [vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(param.fb_dur);
    
    accuracy_arr(i_prac_trial,:) = accuracy;
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % ITI
    Screen('FillRect', window, param.backgrd_col);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(prac_ITI);
    
    CheckForEscape(param.key_escape, param.kbID)
    
end

indx_accurate_resp = logical(accuracy_arr == 1);
prac_accuracy = sum(indx_accurate_resp);

accuracy_fb_text = sprintf('Accuracy for practice phase: %d/%d\n Redo practice? (y = yes, n = no)', prac_accuracy, param.nprac_trials*nmodality);
Screen('FillRect', window, param.backgrd_col);
DrawFormattedText(window, accuracy_fb_text, 'center', 'center', param.stim_col);
[vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);

keyisdown = 0;
while(~keyisdown)
    [keyisdown, secs, keyCode] = KbCheck(param.kbID);
    
    if keyisdown ~= 0
        if (find(keyCode == 1) == param.key_yes) || (find(keyCode == 1) == param.key_no)
            accuFB_keycode = find(keyCode == 1);
            keyisdown = 1;
        elseif (find(keyCode == 1) == param.key_escape)
            ListenChar(1)
            ShowCursor;
            sca
            error('Escape key detected. Program exited!!!')
        else
            keyisdown = 0;
        end
    end
end

    
training_res.accuFB_keycode = accuFB_keycode;
training_res.accuracy_arr{param.prac_count} = accuracy_arr;
training_res.prac_accuracy{param.prac_count} = prac_accuracy;
training_res.prac_resp_arr{param.prac_count} = resp_arr;

ListenChar(1)
ShowCursor;

