function [test_res] = DoAuditoryTest(window, pahandle, param, test_stim)

fps = param.fps;
ifi = param.ifi;

ListenChar(2)
HideCursor;

%% Start Actual Test Trials

vbl = Screen('Flip', window);

for i_trial = 1:param.ntrials
    
    test_dur = test_stim.test_dur_arr(i_trial);
    test_ITI = test_stim.test_ITI_arr(i_trial);
    test_fix_cross_dur = test_stim.test_fix_cross_arr(i_trial);
    
    % Fill buffer with audio file needed
    snd_indx = logical(param.dur_all == test_dur);
    PsychPortAudio('FillBuffer', pahandle, param.wav_array{snd_indx,1});
    
    % Correct response
    if param.resp_config == 1 && test_dur < param.mid_dur
        corr_resp_key = param.key_left;
    elseif param.resp_config == 1 && test_dur > param.mid_dur
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && test_dur < param.mid_dur
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && test_dur > param.mid_dur
        corr_resp_key = param.key_left;
    end
    
    %%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS: TO RUN JUST BEFORE FIRST TEST TRIAL %%%%%%%%%%%%%%%%%%
    if i_trial == 1
        
        % Wait for input from scanner to trigger trial
        Screen('TextSize', window, param.text_size);
        
        if param.resp_config == 1
            test_text = sprintf(['A range of durations in between the \ntwo learned durations will be presented.\n\n' ...
                'Judge if the presented duration is closer to \nthe SHORT or the LONG learned duration\n\n' ...
                'Press <z> to indicate that presented duration is closer to SHORT.\n' ...
                'Press <m> to indicate that presented duration is closer to LONG.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        elseif param.resp_config == 2
            test_text = sprintf(['A range of durations in between the \ntwo learned durations will be presented.\n\n' ...
                'Judge if the presented duration is closer to \nthe SHORT or the LONG learned duration\n\n' ...
                'Press <z> to indicate that presented duration is closer to LONG.\n' ...
                'Press <m> to indicate that presented duration is closer to SHORT.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        end
        DrawFormattedText(window, test_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi);
        while 1
            [keyIsDown, secs, keyCode, deltaSecs] = KbCheck(param.kbID);
            if keyCode(param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            elseif keyCode(param.key_space)
                break
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('\nTest Trial %d: Probe duration presented is %1.4f s.\n', i_trial, test_dur);
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % Fixation Cross
    Screen('FillRect', window, param.backgrd_col);
    Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(test_fix_cross_dur);
    
    % Timing Stimulus
    nframes_test = fps*test_dur;
    
    % Start sound playback
    snd_start = PsychPortAudio('Start', pahandle, param.repetitions, param.snd_startcue, param.snd_waitfordevice);
    
    % Fixation cross will be presented during sound playback
    for i_frame = 1:nframes_test
        Screen('FillRect', window, param.backgrd_col);
        Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
        vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    end
    
    % Stop sound playback
    [actualStartTime, endPositionSecs, xruns, estStopTime] = PsychPortAudio('Stop', pahandle, 1, 1);
    
    time_stim_onset(i_trial,:) = snd_start;
    time_stim_end(i_trial,:) = estStopTime;
    actual_stim_dur(i_trial,:) = endPositionSecs;
    
    % Capture Response
    Screen('TextSize', window, param.fb_resp_text_size);
    if param.resp_config == 1
        resp_text = sprintf('SHORT                      LONG');
    elseif param.resp_config == 2
        resp_text = sprintf('LONG                       SHORT');
    end
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, resp_text, 'center', 'center', param.stim_col);
    [vbl, time_resp_start] = Screen('Flip', window, vbl+0.2*ifi, 1);
    t_startresp = time_resp_start;
    
    keyisdown = 0;
    while(~keyisdown)
        t_endresp = GetSecs;
        [keyisdown, secs, keycode] = KbCheck(param.kbID);
        
        if t_endresp - t_startresp > param.max_resp_time
            resp_keycode = 999; % No response
            keyisdown = 1;
        elseif keyisdown ~= 0
            if (find(keycode == 1) == param.key_left) || (find(keycode == 1) == param.key_right)
                resp_keycode = find(keycode == 1);
                keyisdown = 1;
            elseif (find(keycode == 1) == param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            else
                keyisdown = 0;
            end
        end
    end
    
    time_resp_start_arr(i_trial,:) = t_startresp; % Start of response window
    corr_resp_arr(i_trial,:) = corr_resp_key; % Correct response key
    subj_resp_arr(i_trial,:) = resp_keycode;  % Subject's response
    time_response(i_trial,:) = secs;          % Time of response
    RT(i_trial,:) = secs - t_startresp;       % Time taken to respond
    
    % Accuracy coding
    if resp_keycode == 999
        accuracy = 999;
        fprintf('Response Keycode: %d, Missed input response for Trial No %d!!!\n', resp_keycode, i_trial)
    elseif resp_keycode == corr_resp_key
        accuracy = 1;
        fprintf('Response Keycode: %d, Response for Trial No %d is accurate!!!\n', resp_keycode, i_trial)
    elseif resp_keycode ~= corr_resp_key
        accuracy = 0;
        fprintf('Response Keycode: %d, Response for Trial No %d is inaccurate!!!\n', resp_keycode, i_trial)
    end
    
    test_accuracy_arr(i_trial,:) = accuracy;  % Subject's accuracy
    
    % Feedback (Only for SHORT and LONG anchor durations)
    if test_dur == param.short_anchor || test_dur == param.long_anchor
        if resp_keycode == corr_resp_key && test_dur == param.short_anchor
            fb_test_text = 'Correct! \n\nThat was the SHORT duration.';
        elseif resp_keycode == corr_resp_key && test_dur == param.long_anchor
            fb_test_text = 'Correct! \n\nThat was the LONG duration.';
        elseif resp_keycode ~= corr_resp_key && test_dur == param.short_anchor
            fb_test_text = 'Incorrect! \n\nThat was the SHORT duration.';
        elseif resp_keycode ~= corr_resp_key && test_dur == param.long_anchor
            fb_test_text = 'Incorrect! \n\nThat was the LONG duration.';
        end
        
        Screen('FillRect', window, param.backgrd_col);
        DrawFormattedText(window, fb_test_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);
        WaitSecs(param.fb_dur);
    end
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % ITI
    Screen('FillRect', window, param.backgrd_col);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(test_ITI);
    
    % Check for pauses and end of test phase
    if param.trials_to_break == 0
        
    elseif i_trial == param.ntrials % End of test phase
        
        end_of_blk_text = sprintf('End of experiment!');
        Screen('TextSize', window, param.fb_resp_text_size);
        Screen('FillRect', window, param.backgrd_col);
        DrawFormattedText(window, end_of_blk_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);
        WaitSecs(param.fb_dur);
        
    elseif i_trial/param.trials_to_break == floor(i_trial/param.trials_to_break) && i_trial ~= 1 && i_trial ~= param.ntrials % Break for participants
        
        pause_text = sprintf(['PAUSE!!!\n\n' ...
            'Press <SPACE> to continue.']);
        Screen('TextSize', window, param.fb_resp_text_size);
        Screen('FillRect', window, param.backgrd_col);
        DrawFormattedText(window, pause_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);
        while 1
            [keyIsDown, secs, keyCode, deltaSecs] = KbCheck(param.kbID);
            if keyCode(param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            elseif keyCode(param.key_space)
                break
            end
        end
        
    end
end

indx_accurate_resp = logical(test_accuracy_arr == 1);
test_accuracy = sum(indx_accurate_resp);

fprintf('\nAccuracy for test phase: %d/%d\n', test_accuracy, param.ntrials);

test_res.time_stim_onset = time_stim_onset;
test_res.time_stim_end = time_stim_end;
test_res.actual_stim_dur = actual_stim_dur;
test_res.time_resp_start = time_resp_start_arr;
test_res.time_response = time_response;
test_res.test_subj_RT = RT;
test_res.corr_resp = corr_resp_arr;
test_res.test_subj_resp = subj_resp_arr;
test_res.test_subj_accuracy = test_accuracy_arr;
test_res.test_overall_acc = test_accuracy;

ListenChar(1)
ShowCursor;
sca
