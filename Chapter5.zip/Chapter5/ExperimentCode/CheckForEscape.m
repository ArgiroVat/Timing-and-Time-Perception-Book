function CheckForEscape(keycode_esc, kbID)

[keyIsDown, secs, keyCode, deltaSecs] = KbCheck(kbID);
if keyCode(keycode_esc)
    ListenChar(1)
    ShowCursor;
    sca
    error('Escape key detected. Program exited!!!')
end

end