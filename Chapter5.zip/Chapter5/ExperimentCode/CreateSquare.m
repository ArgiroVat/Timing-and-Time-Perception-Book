function centered_sq = CreateSquare(param)

sq_size_pix = round(param.square_size*param.ppd);
square = [0 0 sq_size_pix sq_size_pix];
centered_sq = CenterRectOnPointd(square, param.center_x, param.center_y);