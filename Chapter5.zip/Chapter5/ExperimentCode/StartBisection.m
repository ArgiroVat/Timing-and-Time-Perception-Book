% Bisection experiment configuration script
% This script is used to set the parameters to start the bisection
% experiment. There are 3 options of bisection experiment to choose from.
%
% 1: Auditory Version
% 2. Visual Version
% 3. Auditory and Visual Version (Single)
% 4. Auditory and Visual Version (Simulatneous)
%
% Change Log:
% 07.12.2016   xq   Written
% 01.03.2017   xq   Insert escape key in code (Check for escape key during
%                   all KbCheck, before fixation cross and before ITI)
 

clear all
clc
sca
commandwindow

% To randomise seeds in MATLAB so that the starting seed is different each
% time we start up MATLAB
% RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock))); % Use for older MATLABs
rng('shuffle') % Use for newer MATLABs

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%          EXPERIMENT PARAMETERS TO BE CHANGED         %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

param.subj = input('Subject Number:');
param.exp_type = input('Experiment Type (1 = Auditory, 2 = Visual, 3 = Auditory & Visual Dual Bisection):');
param.resp_config = input('Response Configuration [1 = Short(Left), Long(Right), 2 = Short(Right), Long(Left)]:');

%% Durations to be used

param.short_anchor = 3;                       % Short anchor duration (in s)
param.long_anchor = 6;                        % Long anchor duration (in s)
param.probe_dur = [3.37 3.78 4.24 4.76 5.34];  % Probe durations excluding anchor (in s)

%% No of trials per duration for each phase
%
% NOTE: For bimodal experiment, the number of trials that you are defining will
% be for each modality and duration. Hence, the no of trials that you will
% end up with would be twice that of the single modality experiment.

param.nlearning_trials_per_anchor = 5;          % No of learning trials to be given for each anchor duration
param.nprac_trials_per_anchor = 5;              % No of practice trials to be given for each anchor duration, if 0, no practice trials will be presented.
param.ntrials_per_dur_cond = 15;                % No of trials for each duration condition in test trials
param.trials_to_break = 20;                     % No of trials before a break will be given in test trials

%% Set screen and viewing parameters

param.view_dist = 60;                           % Viewing distance (in cm)
param.display_size_x = 25.8;                    % Actual length of screen (in cm)
param.display_size_y = 16.2;                      % Actual width of screen (in cm)
param.screen_no = max(Screen('Screens'));       % Auto set to 
param.backgrd_col = [128 128 128];              % Screen background color

%% Set response parameters

param.left_resp_key = 'z';                      % Left response key
param.right_resp_key = 'm';                     % Right response key

%% Set Stimuli and Timing paramters (Amend accordingly depending on the mode of bisection task ran)

% Fixation Cross
param.cross_size = 0.50;                        % In visual angle
param.cross_thickness = 0.05;                   % Line thickness for fixation cross (in deg)
param.cross_col = 255;                          % Cross colour
param.cross_bg_col = 128;                       % Background colour that cross should be superimposed on

% Visual Timing Stimuli
param.square_size = 4;                          % In visual angle
param.stim_col = [0 0 0];                       % Stimuli colour

% Auditory Timing Stimuli
param.snd_freq = 600;                           % Frequency of auditory stimuli (in Hz)
param.samp_freq = 44100;                        % Sampling frequency for output (in Hz)
param.rise_fall_time = 0.01;                    % Rise and fall time (in s)

% Sound parameters for PsychportAudio
param.snd_nchannels = 2;                        % No of sound channels for sound playback
param.snd_basefreq = 44100;                     % Base frequency for sound playback
param.snd_startcue = 0;                         % Defines the starttime of device, 0 = start immediately, > 0, PTB will start device at requested time
param.snd_waitfordevice = 1;                    % 1 = wait until device has really started
param.snd_vol = 1.0;                            % Set sound playback volume, value of 1.0 will pass samples unmodified, 0.5 would reduce intensity by 50%
param.repetitions = 1;                          % Defines how often the sound playback should be repeated. 0 = infinite repeatitions, 1 = play exactly once and stop, 1.5 = 1.5 repetitions

% Set durations
param.fb_dur = 2;                               % Feedback duration (in s)
param.fix_cross_dur_range = [0.5 1];            % Interval range for fixation cross at start of each trial (in s)
param.max_resp_time = 2;                        % Maximum response time (in s)
param.ITIrange = [1 2];                         % Range of Inter-trial interval (in s)
param.async_onset_range = [0 1];                % Only for simulataneous trials, ISI between the auditory and visual stimuli within one trial

param.text_size = 30;                           % Font size for instructions
param.fb_resp_text_size = 50;                   % Font size for feedback

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%    CHANGE ANYTHING BEYOND THIS POINT WITH CAUTION    %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if param.exp_type == 1
    
    param.exp_name = 'Auditory';
    param.exp_code = {'A'};
    
elseif param.exp_type == 2
    
    param.exp_name = 'Visual';
    param.exp_code = {'V'};
    
elseif param.exp_type == 3
    
    param.exp_name = 'Single_Audio_Vis';
    param.exp_code = {'A', 'V'};
    
end

%% Set results directory

param.resultsDir = [cd filesep 'Behavioural_Results' filesep param.exp_name filesep num2str(param.subj, '%02d')]; % Directory to save experiment results
param.sndDir = [cd filesep 'Auditory_Stim' filesep num2str(param.snd_freq) '_Hz']; % Directory to save created audio files for sound playback

% Check for existence of subject folder
while exist(param.resultsDir, 'dir')
    
    fprintf('\n\n%s exist\n', param.resultsDir)
    param.ow_resultsDir = input('Overwrite results directory (y = yes, n = no)?', 's');
    
    if strcmp(param.ow_resultsDir, 'n')
        fprintf('\n\nResults directory for Subject %d will not be overwritten... \n\n', param.subj)
        param.subj = input('Re-enter Subject Number:');
        param.resultsDir = [cd filesep 'Behavioural_Results' filesep num2str(param.subj, '%02d')];
    elseif strcmp(param.ow_resultsDir, 'y')
        fprintf('\n\nResults directory for Subject %d will be overwritten... \n\n', param.subj)
        break
    end
end

%% Compute basic parameters from entered experiment parameters

param.ndur = length(param.probe_dur) + 2;
param.dur_all = [param.short_anchor param.long_anchor param.probe_dur]';
param.ntrials = param.ntrials_per_dur_cond*param.ndur;
param.nlearning_trials = param.nlearning_trials_per_anchor*2;
param.nprac_trials = param.nprac_trials_per_anchor*2;
param.mid_dur = mean([param.short_anchor param.long_anchor]);

%% Create duration arrays for learning trials

[training_stim.learning_modality_arr, training_stim.learning_dur_arr, ...
    training_stim.learning_ITI_arr, training_stim.learning_fix_cross_arr] = CreateDurationArrays(...
    [param.short_anchor; param.long_anchor], ...
    param.ITIrange, ...
    param.fix_cross_dur_range, ...
    param.nlearning_trials_per_anchor, ...
    param.nlearning_trials, ...
    param.exp_code);

%% Screen Initialization

KbName('UnifyKeyNames')

% Initialise screen
Screen('Preference', 'SkipSyncTests', 1) % 1 to skip, 0 to always do
[window, wRect] = Screen('OpenWindow', param.screen_no, param.backgrd_col);
Priority(MaxPriority(window));

param.x_res = wRect(3);
param.y_res = wRect(4);

fprintf('\nCurrent Screen Resolution is %d by %d. Please check if this resolution is correct. \n', param.x_res, param.y_res)

% Enable alpha blending with proper blend-function
Screen('BlendFunction', window, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
param.center_x = wRect(3)/2;
param.center_y = wRect(4)/2;
fps = Screen('FrameRate', window); % frames per second
ifi = Screen('GetFlipInterval', window);
if fps == 0
    fps = 1/ifi;
end

% Do initial flip to get vbl...
vbl = Screen('Flip', window);

% Store screen parameters
param.fps = fps;
param.ifi = ifi;
param.vbl = vbl;
param.screenres = wRect;

fprintf('\nPresentation screen parameters: FPS = %d, IFI = %d, VBL = %d \n\n', fps, ifi, vbl)

%% Calculate pixel density

ppd_horz = CalculateVisAng(param.display_size_x, param.x_res, param.view_dist); % pixels per degree
ppd_vert = CalculateVisAng(param.display_size_y, param.y_res, param.view_dist); % pixels per degree
ppd = mean([ppd_horz; ppd_vert]); % average ppd
param.ppd = ppd;

%% Create fixation cross

[param.fix_cross, param.fix_cross_timestim_bg, param.rect_cross] = CreateFixationCross(window, param);

%% Create timing stimuli

if param.exp_type == 1
    
    CreateAuditoryStim(param); % Auditory stimuli
    
elseif param.exp_type == 2
    
    param.centered_sq = CreateSquare(param); % Visual stimuli
    
elseif param.exp_type == 3
    
    CreateAuditoryStim(param); % Auditory stimuli
    param.centered_sq = CreateSquare(param); % Visual stimuli
    
end

%% Specify response device and get key codes

if ispc
    param.kbID = [];
elseif ismac
    param.kbID = GetKeyboardIndices('Apple Internal Keyboard / Trackpad'); % Comment this out for actual script
end

param.key_space = KbName('space');
param.key_left = KbName(param.left_resp_key);
param.key_right = KbName(param.right_resp_key);
param.key_escape = KbName('ESCAPE'); % Escape key

%% Start Training phase

if param.exp_type == 1 % Auditory version
    
    % Initialise sound driver and audio device
    InitializePsychSound;
    pahandle = PsychPortAudio('Open', [], [], 0, param.snd_basefreq, param.snd_nchannels);
    PsychPortAudio('Volume', pahandle, param.snd_vol);
    
    % Preload anchor audio files
    short_anc_audio_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(param.short_anchor*1000) 'ms.wav'];
    long_anc_audio_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(param.long_anchor*1000) 'ms.wav'];
    param.short_anc_wav = (audioread(short_anc_audio_path))';
    param.long_anc_wav = (audioread(long_anc_audio_path))';
    
    % Present learning trials
    DoAuditoryLearning(window, pahandle, param, training_stim);
    
    % Present practice trials if needed
    if param.nprac_trials ~= 0
        
        param.prac_count = 1;
        
        % Create duration arrays for practice trials
        [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
            training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
            [param.short_anchor; param.long_anchor], ...
            param.ITIrange, ...
            param.fix_cross_dur_range, ...
            param.nprac_trials_per_anchor, ...
            param.nprac_trials,...
            param.exp_code);
        
        % Start Practice
        [training_res] = DoAuditoryPractice(window, pahandle, param, training_stim, []);
        
        % Repeat Practice if necessary
        repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
        while strcmp(repeat_prac, 'y')
            
            param.prac_count = param.prac_count + 1;
            
            % Create duration arrays for practice trials
            [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
                training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
                [param.short_anchor; param.long_anchor], ...
                param.ITIrange, ...
                param.fix_cross_dur_range, ...
                param.nprac_trials_per_anchor, ...
                param.nprac_trials,...
                param.exp_code);
            
            [training_res] = DoAuditoryPractice(window, pahandle, param, training_stim, training_res);
            repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
            
        end
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    else
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    end
    
elseif param.exp_type == 2 % Visual version
    
    % Present learning trials
    DoVisualLearning(window, param, training_stim);
    
    % Present practice trials if needed
    if param.nprac_trials ~= 0
        
        param.prac_count = 1;
        
        % Create duration arrays for practice trials
        [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
            training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
            [param.short_anchor; param.long_anchor], ...
            param.ITIrange, ...
            param.fix_cross_dur_range, ...
            param.nprac_trials_per_anchor, ...
            param.nprac_trials,...
            param.exp_code);
        
        % Start Practice
        [training_res] = DoVisualPractice(window, param, training_stim, []);
        
        % Repeat Practice if necessary
        repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
        while strcmp(repeat_prac, 'y')
            
            param.prac_count = param.prac_count + 1;
            
            % Create duration arrays for practice trials
            [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
                training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
                [param.short_anchor; param.long_anchor], ...
                param.ITIrange, ...
                param.fix_cross_dur_range, ...
                param.nprac_trials_per_anchor, ...
                param.nprac_trials,...
                param.exp_code);
            
            [training_res] = DoVisualPractice(window, param, training_stim, training_res);
            repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
            
        end
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    else
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    end
    
elseif param.exp_type == 3 % Auditory and Visual Bimodal Single Version
    
    % Initialise sound driver and audio device
    InitializePsychSound;
    pahandle = PsychPortAudio('Open', [], [], 0, param.snd_basefreq, param.snd_nchannels);
    PsychPortAudio('Volume', pahandle, param.snd_vol);
    
    % Preload anchor audio files
    short_anc_audio_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(param.short_anchor*1000) 'ms.wav'];
    long_anc_audio_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(param.long_anchor*1000) 'ms.wav'];
    param.short_anc_wav = (audioread(short_anc_audio_path))';
    param.long_anc_wav = (audioread(long_anc_audio_path))';
    
    DoAVLearning(window, pahandle, param, training_stim);
    
    % Present practice trials if needed
    if param.nprac_trials ~= 0
        
        param.prac_count = 1;
        
        % Create duration arrays for practice trials
        [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
            training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
            [param.short_anchor; param.long_anchor], ...
            param.ITIrange, ...
            param.fix_cross_dur_range, ...
            param.nprac_trials_per_anchor, ...
            param.nprac_trials,...
            param.exp_code);
        
        % Start Practice
        [training_res] = DoAVPractice(window, pahandle, param, training_stim, []);
        
        % Repeat Practice if necessary
        repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
        while strcmp(repeat_prac, 'y')
            
            param.prac_count = param.prac_count + 1;
            
            % Create duration arrays for practice trials
            [training_stim.prac_modality_arr{param.prac_count}, training_stim.prac_dur_arr(:,param.prac_count), ...
                training_stim.prac_ITI_arr(:,param.prac_count), training_stim.prac_fix_cross_arr(:,param.prac_count)] = CreateDurationArrays(...
                [param.short_anchor; param.long_anchor], ...
                param.ITIrange, ...
                param.fix_cross_dur_range, ...
                param.nprac_trials_per_anchor, ...
                param.nprac_trials,...
                param.exp_code);
            
            [training_res] = DoAVPractice(window, pahandle, param, training_stim, training_res);
            repeat_prac = input('Repeat practice (y = yes, n = no)?' , 's');
            
        end
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    else
        
        fprintf('\nContinuing on to actual test trials... \n\n')
        
        % Clear framebuffer
        Screen('FillRect', window, param.backgrd_col);
        Screen('Flip', window, [], 0);
        
    end
    
end

%% Create duration arrays for test trials

[test_stim.test_modality_arr, test_stim.test_dur_arr, test_stim.test_ITI_arr, test_stim.test_fix_cross_arr] = CreateDurationArrays(...
    param.dur_all, ...
    param.ITIrange, ...
    param.fix_cross_dur_range, ...
    param.ntrials_per_dur_cond, ...
    param.ntrials, ...
    param.exp_code);

%% Start actual test trials

if param.exp_type == 1 % Auditory Version
    
    % Preload all audio files into an array
    for i_dur = 1:param.ndur
        
        curr_dur = param.dur_all(i_dur);
        audio_stim_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(curr_dur*1000) 'ms.wav'];
        temp_wav_array = (audioread(audio_stim_path))';
        param.wav_array{i_dur,1} = temp_wav_array;
        
    end
    
    [test_res] = DoAuditoryTest(window, pahandle, param, test_stim);
    
    % Close the audio device
    PsychPortAudio('Close', pahandle);
    
elseif param.exp_type == 2 % Visual Version
    
    [test_res] = DoVisualTest(window, param, test_stim);
    
elseif param.exp_type == 3 % Auditory and Visual Bimodal Version
    
    % Preload all audio files into an array
    for i_dur = 1:param.ndur
        
        curr_dur = param.dur_all(i_dur);
        audio_stim_path = [param.sndDir filesep 'freq_' num2str(param.snd_freq) 'Hz_Dur_' num2str(curr_dur*1000) 'ms.wav'];
        temp_wav_array = (audioread(audio_stim_path))';
        param.wav_array{i_dur,1} = temp_wav_array;
        
    end
    
    [test_res] = DoAVTest(window, pahandle, param, test_stim);
    
    % Close the audio device
    PsychPortAudio('Close', pahandle);
    
end


%% Prepare dataset for .csv file

test_res_ds = dataset({(1:param.ntrials*length(param.exp_code))', 'TrialNo'}, ...
    {test_stim.test_modality_arr, 'Modality'}, ...
    {test_stim.test_dur_arr, 'ProbeDur'}, ...
    {test_stim.test_fix_cross_arr, 'FixCrossDur'}, ...
    {test_stim.test_ITI_arr, 'ITI'}, ...
    {test_res.time_stim_onset, 'Stim_Onset'}, ...
    {test_res.time_stim_end, 'Stim_End'}, ...
    {test_res.actual_stim_dur, 'ActualStimDur'}, ...
    {test_res.time_resp_start, 'ResponseWinStart'}, ...
    {test_res.time_response, 'TimeOfResponse'}, ...
    {test_res.test_subj_RT, 'RT'}, ...
    {test_res.corr_resp, 'CorrectResponse'}, ...
    {test_res.test_subj_resp, 'SubjResponse'}, ...
    {test_res.test_subj_accuracy, 'TrialAccuracy'});

%% Save results

% Create results directory if does not exist
if (~exist(param.resultsDir, 'dir'))
    mkdir(param.resultsDir)
    fprintf ('\nCreating directory to store results...\nResults will be saved in %s.\n', param.resultsDir)
end

% Define filenames
param.res_fn = [char(param.exp_code)' 'BIS_S' num2str(param.subj, '%02d') '_Results.mat'];
param.param_fn = [char(param.exp_code)' 'BIS_S' num2str(param.subj, '%02d') '_Parameters.mat'];
param.res_csv_fn = [char(param.exp_code)' 'BIS_S' num2str(param.subj, '%02d') '_TestResults.csv'];

% Save behavioural results
if param.nprac_trials ~= 0
    
    save([param.resultsDir filesep param.res_fn], 'training_res', 'test_res', 'test_res_ds');
    save([param.resultsDir filesep param.param_fn], 'param', 'training_stim', 'test_stim');
    export(test_res_ds, 'File', [param.resultsDir filesep param.res_csv_fn], 'Delimiter', ',');
    
elseif param.nprac_trials == 0
    
    save([param.resultsDir filesep param.res_fn], 'test_res', 'test_res_ds');
    save([param.resultsDir filesep param.param_fn], 'param', 'training_stim', 'test_stim');
    export(test_res_ds, 'File', [param.resultsDir filesep param.res_csv_fn], 'Delimiter', ',');
    
end


