function [training_res] = DoVisualPractice(window, param, training_stim, training_res)

fps = param.fps;
ifi = param.ifi;

ListenChar(2)
HideCursor;

%% Start Practice Trials

vbl = Screen('Flip', window);

for i_prac_trial = 1:param.nprac_trials
    
    prac_dur = training_stim.prac_dur_arr(i_prac_trial,param.prac_count);
    prac_ITI = training_stim.prac_ITI_arr(i_prac_trial,param.prac_count);
    prac_fix_cross_dur = training_stim.prac_fix_cross_arr(i_prac_trial,param.prac_count);
    
    % Correct response
    if param.resp_config == 1 && prac_dur == param.short_anchor
        corr_resp_key = param.key_left;
    elseif param.resp_config == 1 && prac_dur == param.long_anchor
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && prac_dur == param.short_anchor
        corr_resp_key = param.key_right;
    elseif param.resp_config == 2 && prac_dur == param.long_anchor
        corr_resp_key = param.key_left;
    end
    
    %%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS: TO RUN JUST BEFORE FIRST PRACTICE TRIAL %%%%%%%%%%%%%%%%%%
    if i_prac_trial == 1
        
        % Wait for input from scanner to trigger trial
        Screen('TextSize', window, param.text_size);
        
        if param.resp_config == 1
            prac_text = sprintf(['Classify the presented durations as SHORT or LONG\nbased on previously learned durations.\n\n' ...
                'Press <z> to indicate that presented duration is SHORT.\n' ...
                'Press <m> to indicate that presented duration is LONG.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        elseif param.resp_config == 2
            prac_text = sprintf(['Classify the presented durations as SHORT or LONG\nbased on previously learned durations.\n\n' ...
                'Press <z> to indicate that presented duration is LONG.\n' ...
                'Press <m> to indicate that presented duration is SHORT.\n\n' ...
                'DO NOT silent count, tap or use any other ways \nto subdivide the duration.\n\n' ...
                'Press <SPACE> to continue.']);
        end
        DrawFormattedText(window, prac_text, 'center', 'center', param.stim_col);
        [vbl] = Screen('Flip', window, vbl+0.2*ifi);
        while 1
            [keyIsDown, secs, keycode, deltaSecs] = KbCheck(param.kbID);
            if keycode(param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            elseif keycode(param.key_space)
                break
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('\nPractice Trial %d: Anchor duration presented is %1.2f s.\n\n', i_prac_trial, prac_dur);
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % Fixation Cross
    Screen('FillRect', window, param.backgrd_col);
    Screen('DrawTexture', window, param.fix_cross, [], param.rect_cross);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(prac_fix_cross_dur);
    
    % Timing Stimulus
    nframes_prac = fps*prac_dur;
    
    for i_prac_frame = 1:nframes_prac
        Screen('FillRect', window, param.stim_col, param.centered_sq)
        Screen('DrawTexture', window, param.fix_cross_timestim_bg, [], param.rect_cross);
        vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    end
    
    % Capture Response
    Screen('TextSize', window, param.fb_resp_text_size);
    
    if param.resp_config == 1
        resp_text = sprintf('SHORT                      LONG');
    elseif param.resp_config == 2
        resp_text = sprintf('LONG                       SHORT');
    end
    
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, resp_text, 'center', 'center', param.stim_col);
    [vbl, resp_starttime] = Screen('Flip', window, vbl+0.2*ifi, 1);
    t_startresp = resp_starttime;
    
    keyisdown = 0;
    while(~keyisdown)
        t_endresp = GetSecs;
        [keyisdown, secs, keycode] = KbCheck(param.kbID);
        
        if t_endresp - t_startresp > param.max_resp_time
            resp_keycode = 999; % No response
            keyisdown = 1;
        elseif keyisdown ~= 0
            if (find(keycode == 1) == param.key_left) || (find(keycode == 1) == param.key_right)
                resp_keycode = find(keycode == 1);
                keyisdown = 1;
            elseif (find(keycode == 1) == param.key_escape)
                ListenChar(1)
                ShowCursor;
                sca
                error('Escape key detected. Program exited!!!')
            else
                keyisdown = 0;
            end
        end
    end
    
    resp_arr(i_prac_trial,:) = resp_keycode;
    
    % Feedback
    if resp_keycode == corr_resp_key && prac_dur == param.short_anchor
        fb_prac_text = 'Correct -- It was SHORT.';
        accuracy = 1;
    elseif resp_keycode == corr_resp_key && prac_dur == param.long_anchor
        fb_prac_text = 'Correct -- It was LONG.';
        accuracy = 1;
    elseif resp_keycode ~= corr_resp_key && prac_dur == param.short_anchor
        fb_prac_text = 'Incorrect -- It was SHORT.';
        accuracy = 0;
    elseif resp_keycode ~= corr_resp_key && prac_dur == param.long_anchor
        fb_prac_text = 'Incorrect -- It was LONG.';
        accuracy = 0;
    end
    
    if resp_keycode == 999 && accuracy == 0
        accuracy = 999;
    end
    
    Screen('FillRect', window, param.backgrd_col);
    DrawFormattedText(window, fb_prac_text, 'center', 'center', param.stim_col);
    [vbl] = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(param.fb_dur);
    
    accuracy_arr(i_prac_trial,:) = accuracy;
    
    CheckForEscape(param.key_escape, param.kbID)
    
    % ITI
    Screen('FillRect', window, param.backgrd_col);
    vbl = Screen('Flip', window, vbl+0.2*ifi, 1);
    WaitSecs(prac_ITI);
    
    CheckForEscape(param.key_escape, param.kbID)
    
end

indx_accurate_resp = logical(accuracy_arr == 1);
prac_accuracy = sum(indx_accurate_resp);

fprintf('\nAccuracy for training phase: %d/%d\n', prac_accuracy, param.nprac_trials);

training_res.accuracy_arr(:,param.prac_count) = accuracy_arr;
training_res.prac_accuracy(:,param.prac_count) = prac_accuracy;
training_res.prac_resp_arr(:,param.prac_count) = resp_arr;

ListenChar(1)
ShowCursor;

