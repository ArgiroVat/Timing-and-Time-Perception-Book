function [modality_arr_rand, dur_arr_rand, ITI_arr, fix_cross_arr] = CreateDurationArrays(used_dur, ITIrange, fix_cross_dur_range, ntrials_per_dur, ntrials, exp_code)

nmodality = length(exp_code);
modality_arr = {};
dur_arr = [];

% Create modality and duration array
for i_modal = 1:nmodality
    
    modality_arr_temp = repmat(exp_code(i_modal), ntrials, 1);
    modality_arr = [modality_arr; modality_arr_temp];
    
    dur_arr_temp = repmat(used_dur, ntrials_per_dur, 1);
    dur_arr  = [dur_arr; dur_arr_temp];

end

randindx = randperm(ntrials*nmodality);
modality_arr_rand = modality_arr(randindx,:);
dur_arr_rand = dur_arr(randindx,:);

% ITI
ITI_arr = (ITIrange(2) - ITIrange(1)).*rand(ntrials*nmodality,1) + ITIrange(1);

% Fixation Cross Duration
fix_cross_arr = (fix_cross_dur_range(2) - fix_cross_dur_range(1)).*rand(ntrials*nmodality,1) + fix_cross_dur_range(1);
