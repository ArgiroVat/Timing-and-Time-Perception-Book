function [fix_cross, fix_cross_timestim_bg, rect_cross] = CreateFixationCross(window, param)

% Cross size
cross_size_pix = round(param.ppd*param.cross_size);
if mod(cross_size_pix, 2) ~= 0
    cross_size_pix = cross_size_pix + 1;
end

% Cross thickness
cross_thick_pix = round(param.ppd*param.cross_thickness);
if mod(cross_thick_pix, 2) ~= 0
    cross_thick_pix = cross_thick_pix + 1;
end

fix_cross_temp = CreateCrossMat(cross_size_pix, cross_thick_pix, param.cross_col, param.cross_bg_col);
fix_cross_blackbg_temp = CreateCrossMat(cross_size_pix, cross_thick_pix, param.cross_col, param.stim_col(1));

% Define rectangle which we want the cross to be in
rect_cross = [param.center_x-floor(cross_size_pix/2) param.center_y-floor(cross_size_pix/2) param.center_x+floor(cross_size_pix/2) param.center_y+floor(cross_size_pix/2)];

% Make fixation cross (Two crosses made with different background colour)
fix_cross = Screen('MakeTexture', window, fix_cross_temp);
fix_cross_timestim_bg = Screen('MakeTexture', window, fix_cross_blackbg_temp);
