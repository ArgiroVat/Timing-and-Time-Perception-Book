function [ x ] = smoothma( y , su , horas )

n = size (y);

N = n(1);

ventana = (horas) * su;

ventana = int32(ventana);

convi = ones(ventana,1);

x = conv (y , convi , 'same');


end

