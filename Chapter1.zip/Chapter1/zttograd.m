function  radi  = zttograd( zt )
%ZTTOGRAD Summary of this function goes here
%   Detailed explanation goes here
ff = size(zt);
for i=1:ff(2)
    
    rad(i) = (((zt(i)*-1)+24)*15)+90;
    
    if rad(i) > 360
        rad(i) = rad(i)-360;
    end
end

radi = circ_ang2rad(rad');

end

