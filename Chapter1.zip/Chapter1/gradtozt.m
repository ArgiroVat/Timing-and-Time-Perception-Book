function  zt  = gradtozt( grad )

    
    zt = (((grad-90)/15)-24)/-1;
    
    if zt > 24
        zt = zt-24;
    end
    
   



end

