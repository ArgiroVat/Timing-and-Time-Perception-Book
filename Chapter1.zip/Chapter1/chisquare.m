function [ Qp , sig] = chisquare( signal, sample, step , start , stop , sigy)


%%%%%%%%%%%%%%%%%%%%%
% Chi-square periodogram (Sokolov-Bushel)
% signal = Data to analyze
% sample = sample size (time between each data point)
% step = step size, this will be difference between each period tested
% start = initial period to scan
% stop = last period to scan
% sigy = significance level of test
% example of:  [vec,p] = chisquare (data,5,5,1000,2000,0.05);
% We have data set, that have a 5 minutes sample size, a 5 minutes step size 
% we will scan from period 0f 1000 minutes to 2000 minutes
% The red line in the plot is the significance level with a p = 0.005
%%%%%%%%%%%%%%%%%%%%%%%
%References
%	1. Refinetti, Journal of Theoretical Biology 277, 571-581, 2004 
%		Qp=K*N*Sigma[h=1->P](Mh-M)^2 / Sigma[i=1->N](Xi-N)^2
%
%	2. Sokolve & Bushell, Journal of Theoretical Biology 72, 131-160, 1978


empiezo = round(start / sample);
termino = round(stop / sample);
paso = round(step/sample);

M = mean (signal);
dwn =0;

for i=1:length(signal)
    ac = (signal(i) - M)^2;
    dwn = ac + dwn;
end

rango = ((termino-empiezo)/paso);

termino = empiezo + (rango*paso);

for j=1:rango+1
    
    periodos = empiezo + ((j-1)*paso);
    k=1;
    clear vectores;
    
    for i=1:periodos:length(signal)-periodos
        vectores (k,:) = signal (i:i+periodos);
        k = k+1;

    end

    upp(j) =0;
    
    for i=1:size(vectores,2)
        Mh = mean (vectores(:,i));
        upp(j) = (Mh - M)^2 + upp(j);
    end
    
    upp(j) = upp(j)*k;
    
    [p] =  chi2inv(1-sigy,periodos);
    
    sig(j) = p;
end
    
    Qp =  ( length(signal) * upp) / dwn;
   

   
    
    j=1;
    for i=empiezo:paso:termino
        tiempo(j) = i;
        j=j+1;
    end
    
    
     
    tiempo = tiempo * sample;
    hold on
    plot(tiempo,Qp);
    plot(tiempo,sig,'r');
    hold off

end

