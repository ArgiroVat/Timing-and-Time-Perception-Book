function [periodo,sig] = lsssigx(x,t)

[fz,f,alpha] = fastlomb(x,t,0,0.1,30);

mas = size(f);
sup=1;
sap=1;
for i=1:mas(1)
    if f(i)<0.027
        sup = i;    
    end
    if f(i)<0.05
        sap = i;
    end
end

[C,I] = max (fz(sup:sap));
ff = max(fz);

f1 = 1./f;

 
M = 2/30;

z = -log(1-(1-0.05).^(1/M));
sii = size(f1);

for i=1:sii(1)
  alf(i) = z; %Volvio en forma de fichas!!!
end

figure;
hold on;
plot(f1,fz);
title('Lomb-Scargle normalized periodogram')
xlabel('Horas'); ylabel('P(f)')
plot(f1,alf,'r');
axis([18 28 0 ff+ff/8]);
hold off;

rap = f(sup+I-1);
periodo = 1/rap;
sig = alpha(sup+1-1);
end

