%Script with an example analysis of a locomotor activity series

Actogram(CH234,12,500,1,24);

%Compute Periodogram of whole set
[vec,p] = chisquare (CH234,5,5,1000,2000,0.05);
[per,sig] = lsssigx(CH234,t234/60);

%Select the first part of the data set
ch=CH234(1:2000);
time = t234(1:2000);
time=time/60;

%Compute the cosinor
cosinor(time,ch,2*pi/24,0.005);

%Select the second part of the data set
ch1=CH234(2000:4000);
time1=t234(2000:4000);
time1=time1/60;

%Compute Cosinor
cosinor(time1,ch1,2*pi/24,0.005);