%
%
%%Rayleigh Test
%Modified from CircStat20012a
%http://www.mathworks.com/matlabcentral/fileexchange/10676-circular-statistics-toolbox--directional-statistics-
%Phase in ZT

alpha_deg = [0 0.5 1 1.5 2 2.5 3] ;

alpha_rad = zttograd(alpha_deg);       % convert to radians

hold on
zzz = 0.44*exp(1i*linspace(0, 2*pi,100 ));
plot(real(zzz), imag(zzz),'--','Color',[0.3 0.3 0.3],'LineWidth',2);
zzz = exp(1i*linspace(0, 2*pi, 100));
plot(real(zzz), imag(zzz),'Color','k','LineWidth',2');
zzz = exp(1i*linspace(pi/2, (3/2)*pi, 100));
plot(real(zzz), imag(zzz),'Color','k','LineWidth',8');


 hold on
 circ_plot_1(alpha_rad,3,2);
 
 hold off

fprintf('\t\t\t\t\t\tALPHA\n')

alpha_bar = circ_mean(alpha_rad);
alpha_bar1 = circ_rad2ang(alpha_bar);
alpha_bar1 = gradtozt(alpha_bar1);

fprintf('Mean resultant vector:\t%.2f \t\n',alpha_bar1)

alpha_hat = circ_median(alpha_rad);
alpha_hat1 = circ_rad2ang(alpha_hat);
alpha_hat1 = gradtozt(alpha_hat1);

fprintf('Median:\t\t\t\t\t%.2f \t\n', alpha_hat1 )

R_alpha = circ_r(alpha_rad);

fprintf('R Length:\t\t\t\t%.2f \t\n',R_alpha )

S_alpha = circ_var(alpha_rad);

fprintf('Variance:\t\t\t\t%.2f \t\n',S_alpha )

[s_alpha s0_alpha] = circ_std(alpha_rad);

fprintf('Standard deviation:\t\t%.2f \t\n',s_alpha )
fprintf('Standard deviation 0:\t%.2f \t\n',s0_alpha)

b_alpha = circ_skewness(alpha_rad);

fprintf('Skewness:\t\t\t\t%.2f \t\n',b_alpha)

k_alpha = circ_kurtosis(alpha_rad);

fprintf('Kurtosis:\t\t\t\t%.2f \t\n',k_alpha)

fprintf('\n\n')

fprintf('Inferential Statistics\n\nTests for Uniformity\n')

% Rayleigh test
p_alphar = circ_rtest(alpha_rad);
fprintf('Rayleigh Test, \t\t P = %.2f \t\n',p_alphar)

% Omnibus test
p_alpha = circ_otest(alpha_rad);
fprintf('Omnibus Test, \t\t P = %.2f \t\n',p_alpha)

% Rao's spacing test
p_alpha = circ_raotest(alpha_rad);
fprintf('Rao Spacing Test, \t P = %.2f \t\n',p_alpha )

% V test
p_alpha = circ_vtest(alpha_rad,circ_ang2rad(0));
fprintf('V Test (r = 0), \t P = %.2f \t\n',p_alpha)


