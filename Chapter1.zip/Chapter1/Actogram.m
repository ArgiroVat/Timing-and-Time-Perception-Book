% function Actogram(x,NstepsPerHr,T,figurewindow,Tcycle)
%
% Makes a figure with the actogram of activity record x
% Written by T. Leise, Amherst College

function Actogram(x,NstepsPerHr,T,figurewindow,Tcycle)

%if strcmp(figurewindow,'new')
%    figure;
%end

x=[x;zeros(Tcycle*NstepsPerHr*4,1)];

days0=ceil(T/Tcycle+1);
daylength0=Tcycle*NstepsPerHr;
t0=(1:2*daylength0)'/NstepsPerHr;

for day=1:(days0-1)
    today=x((1+(day-1)*daylength0):((day+1)*daylength0));
    today=day-today/max(x);
    bar(t0,today,'k','BaseValue',day);hold on;
end

set(gca,'YDir','reverse','FontSize',12);
xlabel('Horas');
ylabel('Dias');
axis([0 2*Tcycle -1 days0]);