clc; clear
d = load('S01.txt');
SJ4data = d';
LamBounds = [1/90 1/4];
TauBounds = [-30 30];
Delta3Bounds = [0 150];
OuterBounds = [0 120];
LamT_Start = [1/10 1/30];
LamR_Start = [1/10 1/30];
Tau_Start = [-20 20];
Delta3_Start = [20 100];
Err_Start = [0.5];
Bias_Start = [0.5];
Model = 'best'; Criterion = 'BIC';
Disp = true; Plot = true;
report = fit_SJ4(SJ4data, LamBounds, TauBounds, Delta3Bounds, OuterBounds, ...
                 LamT_Start, LamR_Start, Tau_Start, Delta3_Start, Err_Start, Bias_Start, ...
                 Model, Criterion, Plot, Disp);
