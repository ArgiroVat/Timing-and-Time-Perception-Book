clc; clear
d = load('S01.txt');
SJ4data = d';
LamBounds = [1/90 1/4];
Delta1Bounds = [-150 20];
OuterBounds = [0 120];
Lam_Start = [1/10 1/30];
Delta1_Start = [-100 -20];
Err_Start = [0.5];
Bias_Start = [0.5];
Model = 'best'; Criterion = 'BIC';
Disp = true; Plot = true;
report = fit_SJ4_c(SJ4data, LamBounds, Delta1Bounds, OuterBounds, ...
                   Lam_Start, Delta1_Start, Err_Start, Bias_Start, ...
                   Model, Criterion, Plot, Disp);
