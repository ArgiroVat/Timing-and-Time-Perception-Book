% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a simple mean model of 
% ternary judgements. StartParams should be a
% vector with two values. Data should be a matrix, with column 1 as the
% tested values, column 2-4 as proportions judged first/same/later, and column five 
% as the number of
% presentations.

function [FinalParams, LogLikelihood, Deviance] = MeanProbTernaryWrapperForFmin(StartParams,Data)

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams)
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin (@wrapped, 2, StartParams, ...
        100, [0.5 0.5], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    Curves = MeanProbTernary(FinalParams,Data);
    [Deviance] = MultinomialDeviance(Curves, Data, 0.0000000001, 0.01);        
    
    %Plot best fit against data
    figure
    hold on
    plot(Data(:,1),Data(:,2),'bo','MarkerSize',6) 
    plot(Data(:,1),Data(:,3),'ro','MarkerSize',5) 
    plot(Data(:,1),Data(:,4),'go','MarkerSize',4) 
    
    plot(Data(:,1),Curves(:,1),'b',Data(:,1),Curves(:,2),'r',Data(:,1),Curves(:,3),'g')
    legend('first','simultaneous','second')
    hold off
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params(1) < 0 || Params(1) >1 || Params(2) < 0 || Params(2) > 1 || (Params(1) + Params(2)) > 1
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            SimulatedProportions = MeanProbTernary(Params,Data); %Returns vector of Simulated data for these params
            
            %This bit adjusts predictions slightly: Prevents values of 0 and 1 as
            %these will ruin an MLE fit to the data
            %Does so by assuming keying error on 1% of trials
            Guess = 0.01;
            SimulatedProportions =  (SimulatedProportions.*(1-(2*Guess)))+(ones(size(SimulatedProportions,1),size(SimulatedProportions,2)).*Guess);
                        
            %The this bit applies the appropriate "data model", in this
            %case based on the multinomial distribution
            DataB = Data;
            DataB(:,2) = round(Data(:,2).*Data(:,5)); %change from proportions to numbers
            DataB(:,3) = round(Data(:,3).*Data(:,5));
            DataB(:,4) = round(Data(:,4).*Data(:,5));
            
            LLperStimLevel = zeros(length(Data(:,1)),1);
            for i = 1:length(Data(:,1))
                LLperStimLevel(i) = MultinomialLikelihood(DataB(i,2:4),SimulatedProportions(i,:));
                
            end
                   
            MLE = sum(LLperStimLevel);                                              
            
            InverseLikelihood = MLE .* -1;
            
                        
            
        end
        
    end

end