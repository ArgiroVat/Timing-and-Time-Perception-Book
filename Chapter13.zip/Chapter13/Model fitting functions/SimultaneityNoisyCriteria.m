%Simulator for difference of two cumulative Gaussian model of 
% simultaneity judgements with four parameters: Mean of CG1, mean of CG2,
% low SD and high SD. See Yarrow et al 2011 for more details. First input 
% parameter (Params) has four values (the parameters for this fit)
%Data also needs to be supplied (three columns: test values in ms, proportion
%simultaneous, number of presentations, although only first column needed here)
%in order to return a vector of simulated
%values at each tested value

function SimulatedData = SimultaneityNoisyCriteria(Params,Data,varargin)

%varargin can be used to enable a more nuanced way to deal with situations
%where the slopes are very different, buggering up predictions based on
%equations. If not, the wrapper function deals with this by rejecting these
%kinds of fit during nelder mead search

if nargin == 3
    GoToSim = varargin{1};
else
    GoToSim = 0;
end

erfc_Input1 = (Data(:,1)-Params(1))./(sqrt(2).*Params(3));
erfc_Input2 = (Data(:,1)-Params(2))./(sqrt(2).*Params(4));
erfc_Output1 = erfc(erfc_Input1);
erfc_Output2 = erfc(erfc_Input2);

%Note: the root2 when estimating parameters 3 & 4 reflects the relationship
%between the erf and the cumulative gaussian: the parameter will be an
%estimate of the SD of the difference in arrival time distribution, not the
%arrival time of each separate signal

SimulatedData = (erfc_Output2-erfc_Output1)./2; %prob sim predicted by model

%The above can cause problems when the two component functions cross
%(because one is much more noisy than the other) leading to negative
%predictions for simultaneity. To deal with this, I am going to assume that
%the observer will never place the two criteria in an impossible order;
%instead, they will use the same criterion for both decision boundaries
%(i.e. not say simultaneous) and default to the boundary that is less
%noisy. I have to do this via simulation unfortunately, so will go to this
%option if there is a big obvious problem and hope that more subtle
%violations (which do happen sometimes, based on trying out a few
%combinations) don't happen too often!

if sum(SimulatedData < 0) > 0 && GoToSim > 0 %using negative sim predictions as the 
    %cue to switch to simulation
    SimulatedData = SimultaneityNoisyCriteria_Simulation(Params,Data,10000);
    if GoToSim > 1
        fprintf('Simulation Needed\r')
    end
    
end

end
