function cdf = ncf1(xvec,nu1,nu2,theta1,doplot,kvalue)
% cdf = ncf1(xvec,nu1,nu2,theta1,doplot=1,kvalue=0)
% evaluates the cdf of the (single) noncentral F distribution
% kvalue IS JUST FOR ANOTHER ROUTINE WHICH CALLS THIS. LEAVE IT SET TO ZERO.
% allows only vector x.
% Matlab's function stops summing too soon!
%
% Randall's example: x=10*(1-0.01)/0.01; nu1=1; nu2=12; theta1=12*193;

% global compcdf compj;
% compcdf=[]; compj=[];

if nargin < 5, doplot=0; end
if nargin < 6, kvalue=0; end

if kvalue==0, tol=1e-15; else tol=1e-22; end

cdf=[];
workout=1; % set to 0 to use the "standard" method, from j=0 until convergence.

if (theta1==0) & (kvalue==0)
  cdf=fcdf(xvec,nu1,nu2);
else
  atleast=20; % with workout=1 and atleast=0, fails for x=1, n1=1, n2=101, theta1=50
  xlen=length(xvec);
  for xloop=1:xlen
    x=xvec(xloop);
    compcdf=[]; compj=[];
    verteil=0;
    tmp=nu1*x / (nu2+nu1*x);
    done = 0; j = 0;
    if workout==1 % start from j=theta1/2, and work outwards, until convergence
      c=round(theta1/2);
      verteil= ppdf(c,theta1/2) * lbetai(tmp,c+nu1/2,kvalue+nu2/2);
      compcdf=[compcdf verteil]; compj=[compj c];
      while ~done
        j=j+1;
        oldv=verteil;
        k1=c+j; k2=c-j;
        nextv = ppdf(k1,theta1/2)*lbetai(tmp,k1+nu1/2,kvalue+nu2/2);
        verteil= verteil + nextv;
        compcdf=[compcdf nextv]; compj=[compj k1];
        if k2>=0
          nextv = ppdf(k2,theta1/2)*lbetai(tmp,k2+nu1/2,kvalue+nu2/2);
          verteil= verteil + nextv;
          compcdf=[compcdf nextv]; compj=[compj k2];
        end
        done=(verteil-oldv < tol) & (j>atleast);
        stop = isnan(verteil); stop = stop | isinf(verteil); 
        if stop, break, end
      end
      [compj,ii]=sort(compj); compcdf=compcdf(ii);
      if doplot
        plot(compj,compcdf); mj=find(compcdf==max(compcdf));
        title (['Max at j=', int2str(compj(mj)),'  with value ',num2str(compcdf(mj))])
        pause(0.01) % useful when called by ncf2.m
      end
    else
      nextv=-1; matlabj=-1;
      while ~done
        pp=ppdf(j,theta1/2);
        oldv=nextv;
  
        nextv  = pp*lbetai(tmp,j+nu1/2,kvalue+nu2/2);
        verteil= verteil + nextv;
        % compcdf=[compcdf nextv]; % by plotting this, you see where the "mass" is.
  
        % Matlab's Convergence test. I use it just to see where Matlab would have stopped.
        if matlabj<0, if nextv/(verteil+(eps^(1/4))) < sqrt(eps), matlabj=j; end, end
  
        % my improved tests
        smallenough=(  nextv/(verteil+(eps^(1/4))) < sqrt(eps)   );
        downhill=nextv<oldv;
        if smallenough & downhill & (j>=atleast), done = 1; end
  
        j = j + 1;
  
      end
    end
    cdf=[cdf verteil];
  end
  %matlabj
  %j
  
end

function y=ppdf(x,lambda);
  % try to speed things up a bit
  y = exp(-lambda + x .* log(lambda) - gammaln(x + 1));

function y=lbetai(x,a,b)
  bt = exp(gammaln(a+b)-gammaln(a)-gammaln(b) + a*log(x) + b*log(1-x));
  if x < (a+1) / (a+b+2)
     y = bt * betacore(x,a,b) / a;
  else
     y = 1 - bt*betacore(1-x,b,a) / b;
  end
