function f=SPncfpdf(xords,n1,n2,theta1,theta2,acclevel)
% f=SPncfpdf(xords,n1,n2,theta1,theta2,acclevel)
% Computes the saddlepoint pdf of the doubly noncentral F distribution
% of (vector) xords with n1 and n2 degrees of freedom and noncentrality params theta1,theta2 
% if acclevel=2 [default], then add the Daniels (1987) term
% Marc Paolella, 1999.


if nargin<6, acclevel=2; end
if nargin<5, theta2=0; end

xlen=length(xords);
f=zeros(xlen,1);
for xloop=1:xlen, 
  x=xords(xloop);
  if x<1e-30
    f(xloop)=0;
  else
    l1= n2/n1; l2=-x;
    if (theta2==0)
      x2=x^2; a=n1; a2=n1^2; a3=a*a2; b=n2; b2=n2^2; t=theta1; t2=t^2; % simpler
      y=x2 * a3 + 2*x2*a2*t + 2*a2*x*b + 4*x2*a*b*t + a*t2*x2 + 2*a*t*x*b + b2*a + 4*x*b2*t;
      num=x*a*(a+2*b+t) - a*b - sqrt(a*y); den=4*b*x*(a+b);
      s=num/den; roots=s;
    else
      x2=x^2; n12=n1^2; n22=n2^2; n13=n1^3; n23=n2^3; t1=theta1; t2=theta2;
      a=8*(n23*x2+n22*n1*x2);
      b=4*(-2*n22*n1*x2 + x*n23 + 2*x*n1*n22 + x*t2*n22 - n12*n2*x2 - n1*n2*t1*x2);
      c=2*(n22*n1 + n12*n2*x2) - 4*(x*n12*n2 + n1*n2*t1*x + x*t2*n1*n2 + x*n1*n22);
      d=-n12*n2 + x*n12*n2 + x*t2*n12 - n1*n2*t1;
      
      % use Abrahamowitz and Stegun notation
      a2=b/a; a1=c/a; a0=d/a;
      q=a1/3 -a2^2/9; r=(a1*a2-3*a0)/6 - a2^3/27;
      m=q^3 + r^2;
      if m >= 0, error ('this should not happen!'), end
      s1=(r+sqrt(m))^(1/3); s2=(r-sqrt(m))^(1/3);
      sps=s1+s2; sms=s1-s2;
      % z1=sps - a2/3;
      % z2=-sps/2 - a2/3 + sqrt(-3)*sms/2;
      z3=-sps/2 - a2/3 - sqrt(-3)*sms/2;
      roots=z3;
    end
    s=roots;
    v1 = 1/(1-2*s*l1); v2 = 1/(1-2*s*l2);
    K=0.5*(n1*log(v1) + n2*log(v2)) + s*(l1*theta1*v1 + l2*theta2*v2);
    kpp=2*(l1^2*v1^2*(n1+2*theta1*v1)  +  l2^2*v2^2*(n2+2*theta2*v2) );
    M=exp(K) * ( theta2/(1+2*s*x)^2 + n2/(1+2*s*x) );
    f(xloop)=M/sqrt(2*pi*kpp);
    if acclevel==2
      K3= 8*(l1^3*v1^3*(n1+3*theta1*v1)  +  l2^3*v2^3*(n2+3*theta2*v2) );
      K4=48*(l1^4*v1^4*(n1+4*theta1*v1)  +  l2^4*v2^4*(n2+4*theta2*v2) );
      kap3= K3/(kpp)^(3/2); kap4=K4/(kpp)^(4/2);
      O1= 1 + kap4/8 - 5*kap3^2/24;
    else
      O1=1; 
    end
    f(xloop)=f(xloop)*O1;
  end
end
f=f'; % now we can integrate nicely using quadl and quad in matlab-ver-6.1 
