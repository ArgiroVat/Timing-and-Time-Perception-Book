function F=spncfnumint(x,n1,n2,theta1,theta2)
% F=spncfnumint(x,n1,n2,theta1,theta2)
% cdf of the doubly noncentral F via numeric integration of the SPA pdf
% takes only scalar values of x

area=quadl(@SPncfpdf,0,x, 1e-8, 0 ,n1, n2, theta1, theta2);

up=2*x;
change=quadl(@SPncfpdf,x,up, 1e-8, 0 ,n1, n2, theta1, theta2);
new=area+change;
while change>1e-6
  lo=up;
  up=1.5*up;
  change=quadl(@SPncfpdf,lo,up, 1e-8, 0 ,n1, n2, theta1, theta2);
  new=new+change;
end
F=area/new;
