function pdf = ncfpdf(xvec,nu1,nu2,theta1,theta2)
% pdf = ncfpdf(xvec,nu1,nu2,theta1,theta2)
% Returns the pdf of the doubly noncentral F distribution

if nargin<5, theta2=0; end
xlen=length(xvec); pdf=zeros(xlen,1);
if (theta2==0)
  pdf = ncf1pdf(xvec,nu1,nu2,theta1); return
end
rndtheta2=round(theta2+1);
for xloop=1:xlen
  x=xvec(xloop);
  for k=0:rndtheta2
    poiswgt=exp(ppdfln(k,theta2/2)); single=ncf1pdf(x,nu1,nu2,theta1,k);
    val=poiswgt*single; pdf(xloop)=pdf(xloop)+val;
  end
  while val>1e-14
    k=k+1;
    poiswgt=exp(ppdfln(k,theta2/2)); single=ncf1pdf(x,nu1,nu2,theta1,k);
    val=poiswgt*single; pdf(xloop)=pdf(xloop)+val;
  end    
end

function pdf = ncf1pdf(xvec,nu1,nu2,theta1,k)
% evaluates the pdf of the (single) noncentral F distribution
% See ncf1pdf.m for the older program. This one is MUCH faster.

if nargin<5, k=0; end
if (theta1==0)
  pdf=fpdf(xvec,nu1,nu2); return
end
xlen=length(xvec); pdf=zeros(xlen,1); 
n12=nu1/2;  n22=nu2/2; n1n22=(nu1+nu2)/2; rndtheta=round(theta1+1);
for xloop=1:xlen
  x=xvec(xloop); tmp=nu1*x / nu2; tmp1=tmp+1;
  ltmp=log(tmp); ltmp1=log(tmp1);
  up=3*rndtheta; c=0:up; % This upper limit is often adequate....
  ppln=ppdfln(c,theta1/2); % log of the Poisson weights
  bbln=gammaln(n12+c)+gammaln(n22+k)-gammaln(n1n22+c+k); % log of the beta function
  dln =  ppln - bbln + (n12+c-1)*ltmp - (n1n22+c+k)*ltmp1; % add log of the remaining term
  pdf(xloop) = sum(exp(dln));
  if exp(dln(end))>1e-14  % ... but if it is NOT enough, use a very large value.
    c=(up+1):(10*rndtheta);
    ppln=ppdfln(c,theta1/2); bbln=gammaln(n12+c)+gammaln(n22)-gammaln(n12+c+n22);
    dln =  ppln - bbln + (n12+c-1)*ltmp - (n1n22+c)*ltmp1; 
    extra = sum(exp(dln)); pdf(xloop) = pdf(xloop) + extra;
  end  
end
pdf=pdf*nu1/nu2;

function y=ppdfln(x,lambda);
y = -lambda + x .* log(lambda) - gammaln(x + 1);
  
