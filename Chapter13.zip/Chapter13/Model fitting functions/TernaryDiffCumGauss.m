%Simulator for two cumulative Gaussian model of 
% ternary judgements with three parameters: Mean of CG1, mean of CG2,
% and SD. See Yarrow et al 2011 for more details (ish). First input 
% parameter (Params) has three values (the parameters for this fit)
%Data also needs to be supplied (three columns: test values in ms, proportion
%simultaneous, number of presentations, although only first column needed here)
%in order to return a matrix of simulated
%values at each tested value. This matrix is the proportions for categories
%1-3, e.g. in an audiovisual task with positive SOAs as light leading, it
%would be proportion light first, then simultaneous, then sound first.

function SimulatedData = TernaryDiffCumGauss(Params,Data,varargin)


erfc_Input1 = (Data(:,1)-Params(1))./(sqrt(2).*Params(3));
erfc_Input2 = (Data(:,1)-Params(2))./(sqrt(2).*Params(3));
erfc_Output1 = erfc(erfc_Input1);
erfc_Output2 = erfc(erfc_Input2);

%Note: the root2 when estimating parameters 3 & 4 reflects the relationship
%between the erf and the cumulative gaussian: the parameter will be an
%estimate of the SD of the difference in arrival time distribution, not the
%arrival time of each separate signal

SimulatedData(:,1) = (erfc_Output1./2); 
SimulatedData(:,2) = (erfc_Output2-erfc_Output1)./2; %prob sim predicted by model
SimulatedData(:,3) = 1 - (erfc_Output2./2);


    
end
