%Simulator for two cumulative Gaussian model of 
% ternary judgements with four parameters: Mean of CG1, mean of CG2,
% low SD and high SD. See Yarrow et al 2011 for more details (ish). First input 
% parameter (Params) has four values (the parameters for this fit)
%Data also needs to be supplied (five columns: test values in ms,
%proportions first
%simultaneous, second, number of presentations, although only first column needed here)
%in order to return a matrix of simulated
%values at each tested value. This matrix is the proportions for categories
%1-3, e.g. in an audiovisual task with positive SOAs as light leading, it
%would be proportion light first, then simultaneous, then sound first.

function SimulatedData = TernaryNoisyCriteria_Simulation(Parameters,InFile,Simulations)

Levels = size(InFile,1);
sound = InFile(:,1);

SensoryNoise = min(Parameters(3:4))./2^0.5;
CriterionNoise = abs(Parameters(3)^2-Parameters(4)^2)^0.5;
[~,NoisyCriterion] = max(Parameters(3:4));  %1 for low, 2 for high

sound = repmat(sound,1,Simulations);

sound = sound + (randn(Levels,Simulations).*SensoryNoise);

sight = (randn(Levels,Simulations).*SensoryNoise);

diff1 = sound - sight; 

PNoise = randn(Levels,Simulations).*CriterionNoise;
if NoisyCriterion == 1
    LowCriterion = Parameters(1) + PNoise; 
    HighCriterion = Parameters(2).*ones(Levels,Simulations);
else
    LowCriterion = Parameters(1).*ones(Levels,Simulations);
    HighCriterion = Parameters(2) + PNoise; 
end

negcrit = HighCriterion < LowCriterion;
%default to the less noisy criterion
if NoisyCriterion == 1
    LowCriterion(negcrit) = HighCriterion(negcrit);
else
    HighCriterion(negcrit) = LowCriterion(negcrit);
end

SimulatedData(:,1) = sum(diff1 < LowCriterion,2)./Simulations; % p sound came first
SimulatedData(:,2) = sum(diff1 >= LowCriterion & diff1 < HighCriterion,2)./Simulations; %p simultaneous
SimulatedData(:,3) = sum(diff1 >= HighCriterion,2)./Simulations; %p sound came second

end
