% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a detection theoretic model of 
% 2AFC simultaneity judgements. StartParams should be a
% vector with 3 values. Data should be a matrix, with column 1 as the
% SOAs tested against a zero SOA target IN POSITION/INTERVAL 2, column 2 as proportions judged less simultaneous, and column three 
% as the number of presentations. Optional arguments after the first
% which lets you turn off Hessian and covariance calculations) should be passed in
% triplets, with the first being a target value for a supplementary data set
% (e.g. trials with various comparisons against an SOA of -20). The second
% parameter should be a Data matrix set against these values, while the
% third should be a zero for target in interval 2, a 1 for target in
% position 1.


function [FinalParams, LogLikelihood, Deviance, Hess, Covar] = TwoAFCSimultaneity_3PEq_WrapperForFmin(StartParams,Data,varargin)

    Model = 5; %Note: This needs to agree with the model selected in the other TwoAFCSimultaneity_3P_Equation functions!!!

    if Model < 5
        Multip = Model;
    else
        Multip = 4;
    end
    
    ploton = 0;
        
    Hess = [];
    Covar = [];
    
    if nargin >= 3 && ~isempty(varargin{1})
        FullDiagnostics = varargin{1};
    else
        FullDiagnostics = 1; %Defaults to returning Hessian Matrix and Covariance, but pass a 0 as final parameter to turn this off (e.g. during bootstraps)
    end

    Target(1) = 0;
    Interval(1) = 0;

    if nargin > 3 %extra data passed
        if mod(nargin,3) == 0 %extra triplets passed
            DataSets =  1 + ((nargin-3)./3);
            for i = 2:DataSets
                Target(i) = varargin{(i.*3)-4}; 
                Interval(i) = varargin{(i.*3)-2};
            end
        else
            YouArseYouDidntPassTriplets = 1
            DataSets = 1;
        end
    else
        DataSets = 1;
    end
            

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams);
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin(@wrapped, 3, StartParams, ...
        100, [50 50 1.*(ceil(Multip./2).^5)], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    Deviance = 0;
    
    if FullDiagnostics    
        
        if FullDiagnostics == 1
            [Hess,~] = hessian(@wrapped,FinalParams);
        else
            Hess = lnLhessian( @wrapped,FinalParams,FullDiagnostics );
            
        end
        warning('off','MATLAB:illConditionedMatrix')
        warning('off','MATLAB:singularMatrix')
        Covar = inv(Hess);
        warning('on','MATLAB:illConditionedMatrix')
        warning('on','MATLAB:singularMatrix')
        
        for i = 1:DataSets                

            if i > 1
                ThisData = varargin{(i.*3)-3};                
            else
                ThisData = Data;
            end
            
            Params = FinalParams;
            
            if Interval(i) ~= 0
                if Model > 2
                    Params(3) = -1.*Params(3); %interval bias is in form int1 - int2 > bias
                else
                    Params(3) = 1./Params(3); %interval bias is in form int1 > int2 * bias
                end
            end

            if ~isempty(ThisData)

                Curve = TwoAFCSimultaneity_3P_Equation(Params,ThisData,Target(i));
                Deviance = Deviance + BinomialDeviance(Curve, ThisData, 0.0000000001, 0.01);

                if ploton

                    %Plot best fit against data
                    figure
                    hold on
                    plot(ThisData(:,1),ThisData(:,2),'o')
                    t = (min(ThisData(:,1)):max(ThisData(:,1)))';
                    Curve = TwoAFCSimultaneity_3P_Equation(FinalParams,t,Target(i)); %Expanded Curve to plot points every ms
                    plot(t,Curve)
                    xlabel('SOA')
                    ylabel(strcat('Proportion judged less simultaneous than ',int2str(Target(i))))
                    hold off

                end

            end

        end
        
    end
       
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params(2) <= 0 || (Params(3) <= 0 && Model < 3)
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            
            MLE = 0;
            InverseLikelihood = 1000;
            
            for i = 1:DataSets                
        
                if i > 1                    
                    ThisData = varargin{(i.*3)-3};
                else
                    ThisData = Data;
                end
                
                P = Params;
                
                if Interval(i) ~= 0
                    if Model > 2
                        P(3) = -1.*P(3); %interval bias is in form int1 - int2 > bias
                    else
                        P(3) = 1./P(3); %interval bias is in form int1 > int2 * bias
                    end
                end
                    
                if ~isempty(ThisData) %hopefully ignore empty data sets...
            
                    SimulatedProportions = TwoAFCSimultaneity_3P_Equation(P,ThisData,Target(i)); %Returns vector of Simulated data for these params
                    
                    if sum(SimulatedProportions == -1) > 0 %saddle point approximation got an input it couldn't deal with
                        InverseLikelihood = realmax;
                        return
                    end

                    %This bit adjusts predictions slightly: Prevents values of 0 and 1 as
                    %these will ruin an MLE fit to the data
                    %Does so by assuming keying error on 1% of trials
                    Guess = 0.01;
                    SimulatedProportions =  (SimulatedProportions.*(1-(2*Guess)))+(ones(size(SimulatedProportions,1),size(SimulatedProportions,2)).*Guess);                                    
                                        

                    %The this bit applies the appropriate "data model", in this
                    %case based on the binomial distributions as this is forced
                    %choice data
                    DataB = ThisData;
                    DataB(:,2) = round(ThisData(:,2).*ThisData(:,3)); %change from proportions to numbers

%                     for j = 1:length(ThisData(:,1))
%                        MLEperStimLevel(j) = BinomialLikelihood(DataB(j,2),DataB(j,3),SimulatedProportions(j));
%                     end
% 
%                     MLE = MLE + sum(log(MLEperStimLevel));


                    %Vectorised approach with kernal LL; much quicker, but less clear what is
                    %going on. Seems better; less prone to rounding errors?
                    %I think I got this from Wichmann & Hill. It uses a kernel
                    %log likelihood function, so don't mix and match with the
                    %approach above! (kernel = missing terms that only add
                    %constants)
                    MLEperStimLevel = (DataB(:,2).*log(SimulatedProportions))...
                        + ((DataB(:,3)-DataB(:,2)).*log(1-SimulatedProportions));

                    MLE = MLE + sum(MLEperStimLevel); 
 

                    InverseLikelihood = MLE .* -1;
                    
                end
            
            end
                        
        end
        
    end

end





