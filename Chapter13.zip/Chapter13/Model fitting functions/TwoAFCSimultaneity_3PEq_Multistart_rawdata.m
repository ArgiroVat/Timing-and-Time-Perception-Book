function [FinalParams, LogLikelihood, Deviance, ThisData, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameter] = TwoAFCSimultaneity_3PEq_Multistart_rawdata(StartParams,StepParams, EndParams, Data,varargin)
% Launching function to make TwoAFCSimultaneity_3PEq_WapperForFmin
% start Simplex searches for a best fit from multiple points.
%
% Basically, this function fits an appropriate model to data from an experiment
% that demands a 2IFC between two pairs of events (e.g. two sets of a flash and a beep). 
% The model assumes that individual signals are prone to Gaussian latency noise,
% affecting when they arrive at a decision center. The observer is assumed
% to base their discrimination on which pair arrives with the smallest
% absolute aysnchrony. Note that stim levels are defined in ms.
%
% Model predictions depend on the model specified at the start of this function and of the corresponding
% Wrapper and model functions (make sure they match!)
% One variant follows the CDF of a doubly non-central F distribution (thanks to
% Josh Solomon for pointing this out). However, that is the slowest
% function in the whole wide world to evaluate, so the functions called
% here should generally use a saddle-point approximation to this CDF based on:
% 
% Statistics and Computing (2002). Calculating the density and distribution 
% function for the singly and doubly noncentral F. Volume 12, Issue 1, pp 9-16.  
% Ronald W. Butler, Marc S. Paolella
%
% (see also Intermediate Probability: A Computational Approach by Marc,
% published by Wiley in 2007, where he expands on some of this stuff and
% provides some code snippets in chapter 10. Thanks to Marc for sending me the functions
% I use!)
%
% This first variant models an observer with a ratio interval bias.
%
% The alternative method is based on integrating the difference of two
% folded Gaussians, and follows derivations provided in 
% M.A. Garcia Perez, E. Peli (2014) The bisection point across variants of the task. 
% Attention, Perception & Psychophysics, 76:1671�1697. It models an
% observer with a consant interval bias.
%
% This is fairly quick, but includes a numerical integration so it's still
% pretty slow for bootstrapping etc. Hence the default method is based on a
% different derivation of this model supplied by Matthew Patten, Colin Clifford, 
% Kai Schreiber and Josh Solomon.
%
% To get it going, you need a command like this: 
%
% [FinalParams, LogLikelihood] = TwoAFCSimultaneity_3PEq_Multistart_rawdata([-200 10 1],[200 150 1], [200 310 1], Data)
%
% The model has three parameters (PSE, average latency SD of signals, interval bias).
%
% NOTE: The SD parameter returned here is not directly comparable to the SD
% parameter returned when fitting a cumulative Gaussian to a set of TOJ
% data. To make this comparison, the SD returned here should be multiplied
% by 2^0.5.
%
% When searching for best-fitting parameters, it's possible to get trapped 
% at a "local maximum" best fit which is not always the global maximum. 
% Hence the function will initiate a Nelder-Mead search to find the best-fitting 
% model from multiple starting points. The first three arguments that are
% passed to the function specify the starting points to iterate through, in
% the format start:step:end for each of three parameters (e.g. for parameter 1
% the example above will test starting positions of -200, 0 and 200, because
% it starts at -200, moves up in steps of 200, and ends at 200). Hence this
% example actually sets in motion 3 x 3 x 1 = 9 fits. Finally, you get the best fit
% plotted from any of the starting positions. If you find with your data that
% you are not getting good fits, you may need to adjust these values to make
% sure one of the iterations starts reasonably close to where you believe the
% best fit actually lies. Note that the range of the third parameter is
% model specific. Constant interval biases take positive or negative values
% on a ms scale. Ration ones are likely to be in the range 0.1 - 10 or so.
%
% The fourth argument is the data you are fitting. This needs to be a matrix
% Containing your RAW TRIAL BY TRIAL DATA. This will get chopped up inside
% this function to create sets of data to fit, one for each standard within 
% your experiment (so only one if you just test simultaneous against
% various other values, but several if you have e.g. -20 vs +60 etc.) Each
% subset will then have three columns and as many rows as you have test values. The first column
% is the test value, the second column is the proportion of times they said it was
% more asynchronous than the standard, the third column is the number of trials presented
% at that test value. For example, your experiment might have trial by trial data
% looking like this:
%
% 1     0       50      2
% 2     -50     0       1
% 3     100     0       1
%
% etc. (where the columns are trial number, SOA in interval 1, SOA in
% interval 2, and decision about which is MOST SYNCHRONOUS). Note that you
% need the last three of these four columns, and you need to code them this way,
% but you don't need them in this order (see later). If your data includes
% trials that were bad or cancelled, you should place a zero in the
% decision column (or just remove these trials yourself).
%
% This function will then create at least one (perhaps more) subsets of
% data, one per standard you included. For the data above (which only seem
% to include a single standard: zero) it would create something like the
% following (assuming there were actually 10 tests presented at each of 9
% test values in a set of 90 trials): 
%
% -200  1       10
% -150  0.8     10
% -100  0.7     10
% -50   0.7     10
% 0     0.5     10
% 50    0.6     10
% 100   0.8     10
% 150   0.9     10
% 200   1       10
%
% Basically, it's been coverted to show the proportion of times each test
% was judged more asynchronous than the standard (which is equivalent to
% proportion correct for a zero standard, but not for other standards). In
% one extra level of complication, there will actually be two data sets
% like this created for each standard value, because it matters to the
% model whether the standard was in the first or second interval (as the
% model estimates and fits an interval bias).
%
% To make this conversion work, this function assumes that your data has
% stimuli in paticular step sizes (e.g. 50 ms in the example above). It
% also needs to know what columns in your raw data refer to interval 1 SOA,
% interval 2 SOA and decision (1 or 2 is more synchronous). The defaults
% are based on my data at the time I wrote this, are are:
%
% interval 1 column = 3
% interval 2 column = 4
% decision column = 5
% SOA step size = 20 ms
% Consider standards up to +/- 200 ms
%
% (That last sentence implies that the function will create up to 21
% (standards) x 2 (orders)
% subsets, with standard from -200 to +200 ms in steps of 20 ms, but won't
% consider data beyond that, e.g. if it found a trial with SOAs of -260 ms
% and +300 ms, this wouldn't get included in the fit).
%
% All of those things are adjustable via optional arguments. use [] if you
% want to change some but not all of them.
%
% Optional argument #1 is a vector containing the columns where the
% important stuff (interval 1 SOA, interval 2 SOA, decision) can be found
% in your raw data. Default is [3 4 5].
%
% Optional argument #2 is the step size, and optional argument #3 is the
% max absolute value of standards to consider. Note that if the combination
% of step size and max standard value means that there are more than 25
% standards, the function will break, so if it looks that way for you,
% you'll just have to round your data. Take a similar approach if you have
% very high resolution data rather than discrete steps.
%
% The function can also accept additional input arguments and return more
% stuff, e.g.:
%
% [FinalParams, LogLikelihood, Deviance, ThisData, Hess, Covar, CIFinalParams, GuessLogLikelihood, GuessParameter] = TwoAFCSimultaneity_3PEq_Multistart_rawdata([-75 25 1],[75 50 1], [75 125 1], Data, [], [], [], 2, 1999, 1)
%
% Set these optional arguments to zero or use [] to keep default behaviour.
%
% The Hessian matrix, if requested, tells you interesting things about the curvature of
% the likelihood surface at the point of best fit, and allows an estimate
% of variances/covariances of the parameters.
%
% Set optional argument #4 to either a step size (such as 0.001) or
% 1 for Hessian based confidence intervals or 2
% for Bca bootstrap intervals (which will take ages of course, but are
% likely to have better coverage). For the hessian option, using 1 will call code
% which attempts to figure out the right step size to use when applying
% numerical differentiation on the likelihood surface. Alternatively, use some
% simpler code, which requires that you specify the step size
% (but I've found that a bit ropey here: Maybe try 0.1).
%
% Optional argument #5 lets you override the default (1999) number of bootstraps 
% if you've requested bootstrap confidence intervals.
%
% Optional argument #6 can be set to 1 if you would also like to fit a
% guessing model (in this case the proportion of times O guesses interval 2, which has one
% parameter). You can return assess it by comparing the difference in -2 x
% loglikelihood between guessing and full models against chi-squared[df =
% 2]

    Model = 5; %Note, this MUST agree with the model/method selected at the start of the 
    %two other TwoAFCSimultaneity_3P functions!

    Step = 20;
    MaxStims = 200;
    Columns = [3 4 5];

    if nargin >= 5 && ~isempty(varargin{1})%optional arg 1 passed
        Columns = varargin{1};
    end
    
    if nargin >= 6 && ~isempty(varargin{2})
        Step = varargin{2};
    end

    if nargin >= 7 && ~isempty(varargin{3})
        MaxStims = varargin{3};
    end
    
    if nargin >= 8 && ~isempty(varargin{4})
        ConfidenceIntervals = varargin{4};
        Bootstraps = 1999;
        LowCI = 0.025;
        HighCI = 0.975;
    else
        ConfidenceIntervals = 0;
    end 
        
    if nargin >= 9 && ~isempty(varargin{5})
        
        Bootstraps = varargin{5};
            
    end 
    
    if nargin >= 10 && ~isempty(varargin{6})
        
        TestGuessingModel = varargin{6};
        
    else
        TestGuessingModel = 0;
        
    end 
        
    GuessLogLikelihood = [];
    GuessParameter = [];
    FinalParams = [0 0];
    CIFinalParams = [0 0; 0 0]; 
    LogLikelihood = -1.*realmax;
    Deviance = realmax;
    
    %Split raw data into summaries for each possible standard
    
     RemainingData = Data;
     counter = 0;
     Standard = zeros(26,1);
       
       for j = 0:Step:MaxStims 
           for k = 1:-2:-1
               counter = counter + 1;
               Standard(counter) = j * k; %note that second time through will be same as first, generating empty data
               
               for order = 1:2 
                   
                   LittleLetter = 0;
                   if order == 1
                       LittleLetter = 32;
                   end
               
                   subset = (RemainingData(:,Columns(order)) == Standard(counter)) ...
                       &  (RemainingData(:,Columns(3)) > 0);
                   exclude = ~subset;
                   subset = RemainingData(subset,:);
                   RemainingData = RemainingData(exclude,:);

                   if ~isempty(subset)

                       subsubsetcounter = 0;

                       for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                           
                            subsubset = (subset(:,Columns(3-order)) == l);
                            subsubset = subset(subsubset,:);
                            if ~isempty(subsubset)
                                subsubsetcounter = subsubsetcounter + 1;
                                Simultaneous = order; %1 or 2 for interval that is correct
                                ThisData.(char(counter+64+LittleLetter))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))==Simultaneous)./size(subsubset,1)) size(subsubset,1)];
                                
                            end
                           
                       end
                   else
                       ThisData.(char(counter+64+LittleLetter)) = [];                       
                   end
                   
                   
               end
           end
       end
       
       if counter < 26
           for i = counter:26
               ThisData.(char(i+64)) = [];
               ThisData.(char(i+96)) = [];               
           end
       end
       
       
       ThisData.Leftovers = RemainingData;
       
       %Second run to split data without dividing by interval order
       
       RemainingData = Data;
       counter = 0;
     
       for j = 0:Step:MaxStims 
           for k = 1:-2:-1
               counter = counter + 1;
               
               subset = ((RemainingData(:,Columns(1)) == Standard(counter) | RemainingData(:,Columns(2)) == Standard(counter)) ...
                   & RemainingData(:,Columns(1)) ~= RemainingData(:,Columns(2)) & RemainingData(:,Columns(3)) > 0);
               exclude = ~subset;
               subset = RemainingData(subset,:);
               RemainingData = RemainingData(exclude,:);
               
               if ~isempty(subset)
               
                   subsubsetcounter = 0;

                   for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                       if l ~= Standard(counter)
                            subsubset = (subset(:,Columns(1)) == l | subset(:,Columns(2)) == l);
                            subsubset = subset(subsubset,:);
                            if ~isempty(subsubset)
                                subsubsetcounter = subsubsetcounter + 1;
                                NotSimultaneous = (subsubset(:,Columns(2))==l)+1; %1 or two for interval that is not sim
                                ThisData.(char([counter+64 counter+96]))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))~=NotSimultaneous)./size(subsubset,1)) size(subsubset,1)];
                                
                            end
                       end
                   end
               else
                   ThisData.(char([counter+64 counter+96])) = [];
                   
               end
           end
       end
       
       if counter < 26
           for i = counter:26
               ThisData.(char([i+64 i+96])) = [];                             
           end
       end
       
    if TestGuessingModel
        fprintf('One parameter Guess model tested first\r')
        [GuessParameter, GuessLogLikelihood, ~] = TwoAFCSimultaneity_1PIntBias_WrapperForFmin(0.5,ThisData.A,Standard(3),ThisData.C...
           ,0,Standard(4),ThisData.D,0,Standard(5),ThisData.E,0,Standard(6),ThisData.F...
           ,0,Standard(7),ThisData.G,0,Standard(8),ThisData.H,0,Standard(9),ThisData.I...
           ,0,Standard(10),ThisData.J,0,Standard(11),ThisData.K,0,Standard(12),ThisData.L...
           ,0,Standard(13),ThisData.M,0,Standard(14),ThisData.N,0,Standard(15),ThisData.O...
           ,0,Standard(16),ThisData.P,0,Standard(17),ThisData.Q,0,Standard(18),ThisData.R...
           ,0,Standard(19),ThisData.S,0,Standard(20),ThisData.T,0,Standard(21),ThisData.U...
           ,0,Standard(22),ThisData.V,0,Standard(23),ThisData.W,0,Standard(24),ThisData.X...
           ,0,Standard(25),ThisData.Y,0,Standard(26),ThisData.Z...
           ,0,Standard(1),ThisData.a,1,Standard(3),ThisData.c...
           ,1,Standard(4),ThisData.d,1,Standard(5),ThisData.e,1,Standard(6),ThisData.f...
           ,1,Standard(7),ThisData.g,1,Standard(8),ThisData.h,1,Standard(9),ThisData.i...
           ,1,Standard(10),ThisData.j,1,Standard(11),ThisData.k,1,Standard(12),ThisData.l...
           ,1,Standard(13),ThisData.m,1,Standard(14),ThisData.n,1,Standard(15),ThisData.o...
           ,1,Standard(16),ThisData.p,1,Standard(17),ThisData.q,1,Standard(18),ThisData.r...
           ,1,Standard(19),ThisData.s,1,Standard(20),ThisData.t,1,Standard(21),ThisData.u...
           ,1,Standard(22),ThisData.v,1,Standard(23),ThisData.w,1,Standard(24),ThisData.x...
           ,1,Standard(25),ThisData.y,1,Standard(26),ThisData.z,1);
       
        for order = 1:2
            
            LittleLetter = 0;
            GuessingParameter = GuessParameter;
           if order == 1
               LittleLetter = 32;
               GuessingParameter = 1-GuessingParameter; %flip bias for interval 2
           else
               
           end
       
            figure
            hold on
            whiteout = MaxStims + 20;
            bigwidth = 5;
            PointSize = 1;

            for i = 1:26

                if i ~= 2 && ~isempty(ThisData.(char(i+64+LittleLetter)))

                    ThisTarget = repmat(Standard(i),size(ThisData.(char(i+64+LittleLetter)),1),1);  
                    for j = 1:size(ThisData.(char(i+64+LittleLetter)),1)
                        plot3(ThisData.(char(i+64+LittleLetter))(j,1),ThisData.(char(i+64+LittleLetter))(j,2),ThisTarget,'o','color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],...
                            'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth,'MarkerSize',ThisData.(char(i+64+LittleLetter))(j,3)*PointSize)
                    end

                    Curve = MeanProb(GuessingParameter,ThisData.(char(i+64+LittleLetter))); %data Curve 
                    plot3(ThisData.(char(i+64+LittleLetter))(:,1),Curve,ThisTarget,'color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth)
                end
            end

            title('Best fit')
            %legend('Data','Fit')
            xlabel('SOA (ms)')
            ylabel('Proportion judged less simultaneous than target pair')
            zlabel('Target pair')
            view(30,60)
            grid on


            hold off
            pause(1);
            
        end
                  
    end 

    counteri = 0;
    for i = StartParams(1):StepParams(1):EndParams(1)
        counteri = counteri + 1;

       counterj = 0;
       for j = StartParams(2):StepParams(2):EndParams(2)
           counterj = counterj + 1;
           
           counterk = 0;
           for k = StartParams(3):StepParams(3):EndParams(3)
               counterk = counterk + 1;

           
               Parameters = [i j k];

               tic

               [TempParams, This_MLE, TempD, TempHess, TempCovar] = TwoAFCSimultaneity_3PEq_WrapperForFmin(Parameters,ThisData.A,ConfidenceIntervals,Standard(3),ThisData.C...
               ,0,Standard(4),ThisData.D,0,Standard(5),ThisData.E,0,Standard(6),ThisData.F...
               ,0,Standard(7),ThisData.G,0,Standard(8),ThisData.H,0,Standard(9),ThisData.I...
               ,0,Standard(10),ThisData.J,0,Standard(11),ThisData.K,0,Standard(12),ThisData.L...
               ,0,Standard(13),ThisData.M,0,Standard(14),ThisData.N,0,Standard(15),ThisData.O...
               ,0,Standard(16),ThisData.P,0,Standard(17),ThisData.Q,0,Standard(18),ThisData.R...
               ,0,Standard(19),ThisData.S,0,Standard(20),ThisData.T,0,Standard(21),ThisData.U...
               ,0,Standard(22),ThisData.V,0,Standard(23),ThisData.W,0,Standard(24),ThisData.X...
               ,0,Standard(25),ThisData.Y,0,Standard(26),ThisData.Z...
               ,0,Standard(1),ThisData.a,1,Standard(3),ThisData.c...
               ,1,Standard(4),ThisData.d,1,Standard(5),ThisData.e,1,Standard(6),ThisData.f...
               ,1,Standard(7),ThisData.g,1,Standard(8),ThisData.h,1,Standard(9),ThisData.i...
               ,1,Standard(10),ThisData.j,1,Standard(11),ThisData.k,1,Standard(12),ThisData.l...
               ,1,Standard(13),ThisData.m,1,Standard(14),ThisData.n,1,Standard(15),ThisData.o...
               ,1,Standard(16),ThisData.p,1,Standard(17),ThisData.q,1,Standard(18),ThisData.r...
               ,1,Standard(19),ThisData.s,1,Standard(20),ThisData.t,1,Standard(21),ThisData.u...
               ,1,Standard(22),ThisData.v,1,Standard(23),ThisData.w,1,Standard(24),ThisData.x...
               ,1,Standard(25),ThisData.y,1,Standard(26),ThisData.z,1);                      
           
               if counteri == 1 && counterj == 1 && counterk == 1
                   TimePerFunctionCall = toc
               end

               %ZPlot(counteri,counterj) = This_MLE;

               if This_MLE > LogLikelihood
                   LogLikelihood = This_MLE;
                   Deviance = TempD;
                   FinalParams = TempParams;
                   Hess = TempHess; 
                   Covar = TempCovar; 
               end
           
           end
           
       end

    end
    
    %last check starting from current best fit
    
    [TempParams, This_MLE, TempD, TempHess, TempCovar] = TwoAFCSimultaneity_3PEq_WrapperForFmin(FinalParams,ThisData.A,ConfidenceIntervals,Standard(3),ThisData.C...
           ,0,Standard(4),ThisData.D,0,Standard(5),ThisData.E,0,Standard(6),ThisData.F...
           ,0,Standard(7),ThisData.G,0,Standard(8),ThisData.H,0,Standard(9),ThisData.I...
           ,0,Standard(10),ThisData.J,0,Standard(11),ThisData.K,0,Standard(12),ThisData.L...
           ,0,Standard(13),ThisData.M,0,Standard(14),ThisData.N,0,Standard(15),ThisData.O...
           ,0,Standard(16),ThisData.P,0,Standard(17),ThisData.Q,0,Standard(18),ThisData.R...
           ,0,Standard(19),ThisData.S,0,Standard(20),ThisData.T,0,Standard(21),ThisData.U...
           ,0,Standard(22),ThisData.V,0,Standard(23),ThisData.W,0,Standard(24),ThisData.X...
           ,0,Standard(25),ThisData.Y,0,Standard(26),ThisData.Z...
           ,0,Standard(1),ThisData.a,1,Standard(3),ThisData.c...
           ,1,Standard(4),ThisData.d,1,Standard(5),ThisData.e,1,Standard(6),ThisData.f...
           ,1,Standard(7),ThisData.g,1,Standard(8),ThisData.h,1,Standard(9),ThisData.i...
           ,1,Standard(10),ThisData.j,1,Standard(11),ThisData.k,1,Standard(12),ThisData.l...
           ,1,Standard(13),ThisData.m,1,Standard(14),ThisData.n,1,Standard(15),ThisData.o...
           ,1,Standard(16),ThisData.p,1,Standard(17),ThisData.q,1,Standard(18),ThisData.r...
           ,1,Standard(19),ThisData.s,1,Standard(20),ThisData.t,1,Standard(21),ThisData.u...
           ,1,Standard(22),ThisData.v,1,Standard(23),ThisData.w,1,Standard(24),ThisData.x...
           ,1,Standard(25),ThisData.y,1,Standard(26),ThisData.z,1);       

   if This_MLE > LogLikelihood
       LogLikelihood = This_MLE;
       Deviance = TempD;
       FinalParams = TempParams;
       Hess = TempHess; 
       Covar = TempCovar; 
   end
   
    %create lookup for normal cumulative distribution function
    x = [-5:0.001:5];
    NCD = 0.5 + (erf(x./(sqrt(2)))./2);  
    
    if ConfidenceIntervals %use Hessian matrix estimates
        for i = 1:length(FinalParams)
            CIFinalParams(i,1) = FinalParams(i)-((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
            CIFinalParams(i,2) = FinalParams(i)+((Covar(i,i).^0.5).*x(find(NCD<=HighCI, 1, 'last' )));
        end
    end
    if ConfidenceIntervals == 2 %bootstrap
        
        AllTrials = Data(Data(:,Columns(3)) > 0,:); %Data minus cancelled trials
        BootstrapParams = zeros(Bootstraps,length(FinalParams));
    
        for i = 1:Bootstraps

           tic
           
           %sample with replacement
           Positions = randi(length(AllTrials),length(AllTrials),1);
           %Positions = ceil(rand(length(AllTrials),1).*length(AllTrials));
           ThisBootstrap = AllTrials(Positions,:);

           %Sort down to a Data set           
           
           RData = ThisBootstrap;
            counter = 0;
            S = zeros(26,1);
       
           for j = 0:Step:MaxStims 
               for k = 1:-2:-1
                   counter = counter + 1;
                   S(counter) = j * k; %note that second time through will be same as first, generating empty data
                   
                   for order = 1:2 
                   
                       LittleLetter = 0;
                       if order == 1
                           LittleLetter = 32;
                       end

                       subset = (RData(:,Columns(order)) == S(counter)) ...
                       &  (RData(:,Columns(3)) > 0);
                       exclude = ~subset;
                       subset = RData(subset,:);
                       RData = RData(exclude,:);
                       

                       if ~isempty(subset)

                           subsubsetcounter = 0;
                           
                           for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                           
                                subsubset = (subset(:,Columns(3-order)) == l);
                                subsubset = subset(subsubset,:);
                                if ~isempty(subsubset)
                                    subsubsetcounter = subsubsetcounter + 1;
                                    Simultaneous = order; %1 or 2 for interval that is correct
                                    TData.(char(counter+64+LittleLetter))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))==Simultaneous)./size(subsubset,1)) size(subsubset,1)];

                                end

                           end
                           
                       else
                           TData.(char(counter+64+LittleLetter)) = [];                       
                       end
                   end
               end
           end
           
           if counter < 26
               for c = counter:26
                   TData.(char(c+64)) = []; 
                   TData.(char(c+96)) = [];
               end
           end
       
           [BootstrapParams(i,:), ~, ~, ~, ~] = TwoAFCSimultaneity_3PEq_WrapperForFmin(FinalParams,TData.A,0,Standard(3),TData.C...
           ,0,Standard(4),TData.D,0,Standard(5),TData.E,0,Standard(6),TData.F...
           ,0,Standard(7),TData.G,0,Standard(8),TData.H,0,Standard(9),TData.I...
           ,0,Standard(10),TData.J,0,Standard(11),TData.K,0,Standard(12),TData.L...
           ,0,Standard(13),TData.M,0,Standard(14),TData.N,0,Standard(15),TData.O...
           ,0,Standard(16),TData.P,0,Standard(17),TData.Q,0,Standard(18),TData.R...
           ,0,Standard(19),TData.S,0,Standard(20),TData.T,0,Standard(21),TData.U...
           ,0,Standard(22),TData.V,0,Standard(23),TData.W,0,Standard(24),TData.X...
           ,0,Standard(25),TData.Y,0,Standard(26),TData.Z...
           ,0,Standard(1),TData.a,1,Standard(3),TData.c...
           ,1,Standard(4),TData.d,1,Standard(5),TData.e,1,Standard(6),TData.f...
           ,1,Standard(7),TData.g,1,Standard(8),TData.h,1,Standard(9),TData.i...
           ,1,Standard(10),TData.j,1,Standard(11),TData.k,1,Standard(12),TData.l...
           ,1,Standard(13),TData.m,1,Standard(14),TData.n,1,Standard(15),TData.o...
           ,1,Standard(16),TData.p,1,Standard(17),TData.q,1,Standard(18),TData.r...
           ,1,Standard(19),TData.s,1,Standard(20),TData.t,1,Standard(21),TData.u...
           ,1,Standard(22),TData.v,1,Standard(23),TData.w,1,Standard(24),TData.x...
           ,1,Standard(25),TData.y,1,Standard(26),TData.z,1);
       
           clear TData

           if i == 1
               Bootstraps
               TimePerBootstrap = toc
           end

        end
        
        BootstrapMeanParams = mean(BootstrapParams);    
        
        %For BCa intervals, we need some extra stuff. 
        %First, a jackknife on the data
        
        JackknifeParams = zeros(length(AllTrials),length(FinalParams));
        
        for i = 1:length(AllTrials)
            
            tic
            
            %remove one trial
           include = [1:length(AllTrials)];
           include = include(include ~= i);
           ThisJackknife = AllTrials(include,:);
           
           RData = ThisJackknife;
            counter = 0;
            S = zeros(26,1);
    
            for j = 0:Step:MaxStims 
               for k = 1:-2:-1
                   counter = counter + 1;
                   S(counter) = j * k; %note that second time through will be same as first, generating empty data
                   
                   for order = 1:2 
                   
                       LittleLetter = 0;
                       if order == 1
                           LittleLetter = 32;
                       end

                       subset = (RData(:,Columns(order)) == S(counter)) ...
                       &  (RData(:,Columns(3)) > 0);
                       exclude = ~subset;
                       subset = RData(subset,:);
                       RData = RData(exclude,:);
                       

                       if ~isempty(subset)

                           subsubsetcounter = 0;
                           
                           for l = min(min(subset(:,[Columns(1) Columns(2)]))):max(max(subset(:,[Columns(1) Columns(2)])))
                           
                                subsubset = (subset(:,Columns(3-order)) == l);
                                subsubset = subset(subsubset,:);
                                if ~isempty(subsubset)
                                    subsubsetcounter = subsubsetcounter + 1;
                                    Simultaneous = order; %1 or 2 for interval that is correct
                                    TData.(char(counter+64+LittleLetter))(subsubsetcounter,:) = [l  (sum(subsubset(:,Columns(3))==Simultaneous)./size(subsubset,1)) size(subsubset,1)];

                                end

                           end
                           
                       else
                           TData.(char(counter+64+LittleLetter)) = [];                       
                       end
                   end
               end
           end
           
           if counter < 26
               for c = counter:26
                   TData.(char(c+64)) = []; 
                   TData.(char(c+96)) = [];
               end
           end
       
           [JackknifeParams(i,:), ~, ~, ~, ~] = TwoAFCSimultaneity_3PEq_WrapperForFmin(FinalParams,TData.A,0,Standard(3),TData.C...
           ,0,Standard(4),TData.D,0,Standard(5),TData.E,0,Standard(6),TData.F...
           ,0,Standard(7),TData.G,0,Standard(8),TData.H,0,Standard(9),TData.I...
           ,0,Standard(10),TData.J,0,Standard(11),TData.K,0,Standard(12),TData.L...
           ,0,Standard(13),TData.M,0,Standard(14),TData.N,0,Standard(15),TData.O...
           ,0,Standard(16),TData.P,0,Standard(17),TData.Q,0,Standard(18),TData.R...
           ,0,Standard(19),TData.S,0,Standard(20),TData.T,0,Standard(21),TData.U...
           ,0,Standard(22),TData.V,0,Standard(23),TData.W,0,Standard(24),TData.X...
           ,0,Standard(25),TData.Y,0,Standard(26),TData.Z...
           ,0,Standard(1),TData.a,1,Standard(3),TData.c...
           ,1,Standard(4),TData.d,1,Standard(5),TData.e,1,Standard(6),TData.f...
           ,1,Standard(7),TData.g,1,Standard(8),TData.h,1,Standard(9),TData.i...
           ,1,Standard(10),TData.j,1,Standard(11),TData.k,1,Standard(12),TData.l...
           ,1,Standard(13),TData.m,1,Standard(14),TData.n,1,Standard(15),TData.o...
           ,1,Standard(16),TData.p,1,Standard(17),TData.q,1,Standard(18),TData.r...
           ,1,Standard(19),TData.s,1,Standard(20),TData.t,1,Standard(21),TData.u...
           ,1,Standard(22),TData.v,1,Standard(23),TData.w,1,Standard(24),TData.x...
           ,1,Standard(25),TData.y,1,Standard(26),TData.z,1);

           if i == 1
               NumberJackknifes = length(AllTrials)
               TimePerJackknife = toc
           end

        end
        
        JackknifeMeanParams = repmat(mean(JackknifeParams),NumberJackknifes,1);
        %find means and scale up for vectorised operations
        
        %bits for acceleration formula
        topeq = sum((JackknifeMeanParams-JackknifeParams).^3);
        bottomeq = 6.*(sum((JackknifeMeanParams-JackknifeParams).^2)).^(3/2);        
        
        %bits for bias formula
        scaleup = repmat(FinalParams,Bootstraps,1);
        biascount = (BootstrapParams < scaleup);
        bias = sum(biascount)./Bootstraps;
        
        %LowCI = 0.025;
        %HighCI = 0.975;
        
                
        for i = 1:length(FinalParams)

            ThisDist = sort(BootstrapParams(:,i));
            
            %Percentile
            %CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCI));
            %CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCI));
            
            %Reverse limits as suggested by Howell            
            %CIFinalParams(i,1) = FinalParams(i) - (ThisDist(round((Bootstraps+1).*HighCI))-FinalParams(i));
            %CIFinalParams(i,2) = FinalParams(i) + (FinalParams(i)-ThisDist(round((Bootstraps+1).*LowCI)));
            
            %BCa
            if topeq(i) == 0
                Acceleration = 0;
            else
                Acceleration = topeq(i)./bottomeq(i);
            end
            Thisbias = x(find(NCD<=bias(i), 1, 'last' ));
            if isempty(Thisbias)
                Thisbias = x(1);
                fprintf('Warning: Possible bootstrap issue \n')
            end
            
            LowCut = Thisbias + ( (Thisbias + x(find(NCD<=LowCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=LowCI, 1, 'last'))))) );
            LowCut = NCD(find(x<=LowCut, 1, 'last' ));
            if isempty(LowCut)
                LowCut = 0;
            end
            HighCut = Thisbias + ( (Thisbias + x(find(NCD<=HighCI, 1, 'last'))) ./ (1-(Acceleration.*(Thisbias + x(find(NCD<=HighCI, 1, 'last'))))) );
            HighCut = NCD(find(x<=HighCut, 1, 'last' ));
            if isempty(HighCut)
                HighCut = 0;
            end
            
            if round((Bootstraps+1).*LowCut) < 1 
                CIFinalParams(i,1) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*LowCut) >= length(ThisDist)
                CIFinalParams(i,1) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,1) = ThisDist(round((Bootstraps+1).*LowCut));
            end
            
            if round((Bootstraps+1).*HighCut) < 1
                CIFinalParams(i,2) = ThisDist(1);
                fprintf('Warning: Possible bootstrap issue \n')
            elseif round((Bootstraps+1).*HighCut) >= length(ThisDist)
                CIFinalParams(i,2) = ThisDist(length(ThisDist));
                fprintf('Warning: Possible bootstrap issue \n')
            else
                CIFinalParams(i,2) = ThisDist(round((Bootstraps+1).*HighCut));
            end
            
        end
    
    end
    
    close all
    %RePlot best fit against data
    %Plot best fit against data
    
    PresentationBias = [0 0];
    
    for order = 1:2
            
        PlotParams = FinalParams;
        LittleLetter = 0;
        if order == 1
           LittleLetter = 32;
           if Model > 2
                PlotParams(3) = PlotParams(3).*-1;
           else
                PlotParams(3) = 1./PlotParams(3);
           end
        end
    
        for i = 1:26
                        
            if i ~= 2 && ~isempty(ThisData.(char(i+64+LittleLetter)))
                
                PresentationBias(order) = PresentationBias(order) + sum(ThisData.(char(i+64+LittleLetter))((ThisData.(char(i+64+LittleLetter))(:,1)~=Standard(i)),3),1);
                
                figure
                hold on

                %implement Wilson Score confidence interval for proportion data
    
               T1 = 1./(1 + ((1./ThisData.(char(i+64+LittleLetter))(:,3)).*(1.96^2)));
               T2 = ThisData.(char(i+64+LittleLetter))(:,2)  + (1./(2.*ThisData.(char(i+64+LittleLetter))(:,3))).*(1.96.^2) +  (1.96.*((((1./ThisData.(char(i+64+LittleLetter))(:,3)).*ThisData.(char(i+64+LittleLetter))(:,2).*(1-ThisData.(char(i+64+LittleLetter))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char(i+64+LittleLetter))(:,3).^2))))).^0.5));
               T3 = ThisData.(char(i+64+LittleLetter))(:,2)  + (1./(2.*ThisData.(char(i+64+LittleLetter))(:,3))).*(1.96.^2) -  (1.96.*((((1./ThisData.(char(i+64+LittleLetter))(:,3)).*ThisData.(char(i+64+LittleLetter))(:,2).*(1-ThisData.(char(i+64+LittleLetter))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char(i+64+LittleLetter))(:,3).^2))))).^0.5));
               
               Upper = T1.*T2;
               Lower = T1.*T3;

               %OR
                
                %implement Agresti-Coull corrected version of Wald error bars
                %for proportion data

%                 nHat = ThisData.(char(i+64+LittleLetter))(:,3)+4;
%                 pHat = ((ThisData.(char(i+64+LittleLetter))(:,2).*ThisData.(char(i+64+LittleLetter))(:,3))+2)./nHat;
%                 Upper = pHat + (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
%                 Lower = pHat - (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);

                errorbar(ThisData.(char(i+64+LittleLetter))(:,1),ThisData.(char(i+64+LittleLetter))(:,2),ThisData.(char(i+64+LittleLetter))(:,2)-Lower, Upper - ThisData.(char(i+64+LittleLetter))(:,2),'ko')

                t = (min(ThisData.(char(i+64+LittleLetter))(:,1)):max(ThisData.(char(i+64+LittleLetter))(:,1)))';
                Curve = TwoAFCSimultaneity_3P_Equation(PlotParams,t,Standard(i)); %Expanded Curve to plot points every ms
                plot(t,Curve,'k-')

                title(['Best fit for target pair ',num2str(Standard(i))])
                legend('Data','Fit')
                xlabel('SOA (ms)')
                ylabel('Proportion judged less simultaneous than target pair')

                hold off

            end
        end
    
    
       
        figure
        hold on
        whiteout = MaxStims + 20;
        bigwidth = 5;
        PointSize = 1;

        for i = 1:26

            if i ~= 2 && ~isempty(ThisData.(char(i+64+LittleLetter)))

                ThisTarget = repmat(Standard(i),size(ThisData.(char(i+64+LittleLetter)),1),1);  
                for j = 1:size(ThisData.(char(i+64+LittleLetter)),1)
                    plot3(ThisData.(char(i+64+LittleLetter))(j,1),ThisData.(char(i+64+LittleLetter))(j,2),ThisTarget,'o','color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],...
                        'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth,'MarkerSize',ThisData.(char(i+64+LittleLetter))(j,3)*PointSize)
                end
                t = (min(ThisData.(char(i+64+LittleLetter))(:,1)):max(ThisData.(char(i+64+LittleLetter))(:,1)))';
                ThisTarget = repmat(Standard(i),size(t,1),1);
                Curve = TwoAFCSimultaneity_3P_Equation(PlotParams,t,Standard(i)); %Expanded Curve to plot points every ms
                plot3(t,Curve,ThisTarget,'color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth)
            end
        end

        title('Best fit')
        %legend('Data','Fit')
        xlabel('SOA (ms)')
        ylabel('Proportion judged less simultaneous than target pair')
        zlabel('Target pair')
        view(30,60)
        grid on


        hold off
        
    end
    
    PlotParams = FinalParams;
    if Model < 3
        PlotParams(3) = 1./FinalParams(3);
    else
        PlotParams(3) = -1.*FinalParams(3);
    end
    
    for i = 1:26
        
        if i ~= 2 && ~isempty(ThisData.(char([i+64 i+96])))
        
            figure
            hold on
            
            %implement Wilson Score confidence interval for proportion data
    
           T1 = 1./(1 + ((1./ThisData.(char([i+64 i+96]))(:,3)).*(1.96^2)));
           T2 = ThisData.(char([i+64 i+96]))(:,2)  + (1./(2.*ThisData.(char([i+64 i+96]))(:,3))).*(1.96.^2) +  (1.96.*((((1./ThisData.(char([i+64 i+96]))(:,3)).*ThisData.(char([i+64 i+96]))(:,2).*(1-ThisData.(char([i+64 i+96]))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char([i+64 i+96]))(:,3).^2))))).^0.5));
           T3 = ThisData.(char([i+64 i+96]))(:,2)  + (1./(2.*ThisData.(char([i+64 i+96]))(:,3))).*(1.96.^2) -  (1.96.*((((1./ThisData.(char([i+64 i+96]))(:,3)).*ThisData.(char([i+64 i+96]))(:,2).*(1-ThisData.(char([i+64 i+96]))(:,2))) + ((1.96^2).*(1./(4.*(ThisData.(char([i+64 i+96]))(:,3).^2))))).^0.5));

           Upper = T1.*T2;
           Lower = T1.*T3;

           %OR
            
            %implement Agresti-Coull corrected version of Wald error bars
            %for proportion data
            
%             nHat = ThisData.(char([i+64 i+96]))(:,3)+4;
%             pHat = ((ThisData.(char([i+64 i+96]))(:,2).*ThisData.(char([i+64 i+96]))(:,3))+2)./nHat;
%             Upper = pHat + (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
%             Lower = pHat - (1.96.* ((pHat.*(1-pHat))./nHat).^0.5);
                        
            errorbar(ThisData.(char([i+64 i+96]))(:,1),ThisData.(char([i+64 i+96]))(:,2),ThisData.(char([i+64 i+96]))(:,2)-Lower, Upper - ThisData.(char([i+64 i+96]))(:,2),'ko')
            
            t = (min(ThisData.(char([i+64 i+96]))(:,1)):max(ThisData.(char([i+64 i+96]))(:,1)))';
            Curve = TwoAFCSimultaneity_3P_Equation(FinalParams,t,Standard(i)); %Expanded Curve to plot points every ms
            Curve2 = TwoAFCSimultaneity_3P_Equation(PlotParams,t,Standard(i)); %Expanded Curve to plot points every ms
            Curve = ((Curve*PresentationBias(2))+(Curve2*PresentationBias(1)))./sum(PresentationBias);
            plot(t,Curve,'k-')
            
            title(['Best fit for target pair ',num2str(Standard(i))])
            legend('Data','Fit')
            xlabel('SOA (ms)')
            ylabel('Proportion judged less simultaneous than target pair')
    
            hold off
                        
        end
    end
       
    figure
    hold on
    whiteout = MaxStims + 20;
    bigwidth = 5;
    PointSize = 1;
    
    for i = 1:26
        
        if i ~= 2 && ~isempty(ThisData.(char([i+64 i+96])))
        
            ThisTarget = repmat(Standard(i),size(ThisData.(char([i+64 i+96])),1),1);  
            for j = 1:size(ThisData.(char([i+64 i+96])),1)
                plot3(ThisData.(char([i+64 i+96]))(j,1),ThisData.(char([i+64 i+96]))(j,2),ThisTarget,'o','color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],...
                    'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth,'MarkerSize',ThisData.(char([i+64 i+96]))(j,3)*PointSize)
            end
            t = (min(ThisData.(char([i+64 i+96]))(:,1)):max(ThisData.(char([i+64 i+96]))(:,1)))';
            ThisTarget = repmat(Standard(i),size(t,1),1);
            Curve = TwoAFCSimultaneity_3P_Equation(FinalParams,t,Standard(i)); %Expanded Curve to plot points every ms
            Curve2 = TwoAFCSimultaneity_3P_Equation(PlotParams,t,Standard(i)); %Expanded Curve to plot points every ms
            Curve = ((Curve*PresentationBias(2))+(Curve2*PresentationBias(1)))./sum(PresentationBias);
            plot3(t,Curve,ThisTarget,'color',[abs(Standard(i)./whiteout),abs(Standard(i)./whiteout),abs(Standard(i)./whiteout)],'linewidth',(1-(abs(Standard(i)./whiteout))).*bigwidth)
        end
    end
    
    title('Best fit')
    %legend('Data','Fit')
    xlabel('SOA (ms)')
    ylabel('Proportion judged less simultaneous than target pair')
    zlabel('Target pair')
    view(30,60)
    grid on
    
    
    hold off

    PresentationBias
end

