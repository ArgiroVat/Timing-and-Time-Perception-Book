% Returns a single deviance score, based on a binomial data model (according to 
% papers by Wichmann & Hill). Requires
% the data, in three columns (test values, proportion, Number of trials)
% and also the model predictions (curve). Two further argments (Adjuster &
% Guess) are used to deal with log 0 issues; consider setting guess to 0.01
% implying a 1% lapse rate, and adjuster to 0.0000000001

function [Deviance] = BinomialDeviance(Curve, Data, Adjuster, Guess)

Naughty = find(Data(:,2) < Adjuster);
Data(Naughty,2) = Adjuster;
Naughty = find(Data(:,2) > 1-Adjuster);
Data(Naughty,2) = 1-Adjuster;
    
DataB = Data;
DataB(:,2) = round(Data(:,2).*Data(:,3)); %change from proportions to numbers 

%This bit adjusts predictions slightly: Prevents values of 0 and 1 as
%these will ruin an MLE fit to the data
%Does so by assuming keying error on 1% of trials
Curve =  (Curve.*(1-(2*Guess)))+(ones(size(Curve,1),size(Curve,2)).*Guess);
                            

DevianceperStimLevel = (DataB(:,2).*log(Data(:,2)./Curve))...
    + ((DataB(:,3)-DataB(:,2)).*log((1-Data(:,2))./(1-Curve)));

Deviance = 2.*sum(DevianceperStimLevel);

%Alternatives based on comparison with saturated model; seem to give same
%answer when adjuster is tiny!

% for i = 1:length(Data(:,1))
%    SaturatedMLEperStimLevel(i) = BinomialLikelihood(DataB(i,2),DataB(i,3),Data(i,2));
%    MLEperStimLevel(i) = BinomialLikelihood(DataB(i,2),DataB(i,3),Curve(i));
% end
% 
% SaturatedModel = sum(log(SaturatedMLEperStimLevel));
% MLE = sum(log(MLEperStimLevel));
% 
% 
% Deviance = -2.*(MLE-SaturatedModel);

%or

% SaturatedMLEperStimLevel = (DataB(:,2).*log(Data(:,2)))...
%                         + ((DataB(:,3)-DataB(:,2)).*log(1-Data(:,2)));
% MLEperStimLevel = (DataB(:,2).*log(Curve))...
%                         + ((DataB(:,3)-DataB(:,2)).*log(1-Curve));
% SaturatedModel = sum(SaturatedMLEperStimLevel);
% MLE = sum(MLEperStimLevel);
% 
% Deviance = -2.*(MLE-SaturatedModel);