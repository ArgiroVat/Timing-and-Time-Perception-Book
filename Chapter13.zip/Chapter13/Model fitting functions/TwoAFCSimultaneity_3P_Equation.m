%Predictor function for a dual-presentation SJ task. The model assumes
% Gaussian noise for each stimulus. Input comes from a data file
%with three columns (usually in the form Difference, proportion, total) tailored for a 
%model comparing absolute differences in two intervals.
%The function has two required input variables: Params and Data.
%Params should be a three-value vector in the form Bias, SD, Interval Bias. 
%If a two-value vector is passed, the final parameter is set to represent no 
%interval bias. In the default state, the first column of the data input is
%a set of SOAs which are assumed to be being compared to a true
%simultaneous (SOA = 0) "standard"/"target" stimulus pair that is 
%presented second (with proportion as the proportion of
%times this simultaneous pair is judged more simultaneous). However, the
%model can also make predictions about non simultaneous standards/targets vs. other
%SOAs. To do this, an optional third input argument is passed indicating the SOA of the
%target pair. Proportion is now the proportion of times this pair is judged
%more simultaneous than the pair in the other interval. Note that if
%interval bias is being modelled explicitly, this function should be called
%separately for trials where the standard/target is in interval 1 vs.
%interval 2. If it is in interval 1, the bias parameter needs to be
%reversed (by taking the inverse for methods 1 and 2, where unbiased = 1,
%or by flipping the sign for methods 3,4 and 5, where unbiased = 0).

%The default method is method 5.

%Change methods in the code, not as an input. You MUST ALSO do this in the 
%Wrapper  and multistart function!

%Methods 1 and 2 are based on  the CDF of a doubly 
%noncentral F distribution (Thanks to Josh Solomon for supplying this
%equation). Of the two, method 1 uses an approximation so is much quicker. A key
% thing about this derivation is that the observer's interval bias is assumed to be 
%in the form of a multiplicative bias, i.e. interval 1 > bias x interval 2.

%Method 3 is based on simulation. In that case, optional input
%argument #4 can change the default 10,000 simulations per data point. The
%simulations assume a constant interval bias.

%Method 4 is based on the derivations in Garc�a-P�rez & Peli 2014
%for integrating from a difference of two folded Gaussians. The key thing about this
%derivation is that the observer's interval bias is assumed to be in the form of a constant bias
%e.g. interval 1 - interval 2 > bias. 
% Here, an optional %input argument (#4) can change the default low-res estimate (0) to a
%higher res estimate (1).

%Method 5 is similar to method 4, but is much quicker. The original derivation is by
%Matthew Patten, Colin Clifford, and Kai Schreiber, with their derivation
%expanded by Josh Solomon to incorporate a (constant format) interval bias

function SimulatedData = TwoAFCSimultaneity_3P_Equation(Params,Data,varargin)

Method = 5; %1 for Josh method saddle point
            %2 for Josh method full evaluation
            %3 for simulation
            %4 for Miguel A. Garc�a-P�rez & Eli Peli 2014
            %equation A6. 
            %5 for a sped-up derivation that should be the same as
            %number 4, supplied by Matthew Patten, Colin Clifford, and Kai Schreiber.
            
if length(Params) == 2 %Fit without modelling bias
    Params(3) = 2 - ceil(Method/2); %1 for f-distribution methods, 0 or less for other methods
    if Params(3) < 0
        Params(3) = 0;
    end
end

if nargin >= 3  && ~isempty(varargin{1})%optional arg passed
    Target = varargin{1};
else
    Target = 0;
end

if Method < 3

    Params(2) = 4 .* Params(2).^2; %conversion between Josh's variance parameter
    %and the one I have tended to use (the average SD of each signal's latency
    %noise).

    %Noncentrality parameters. I have modified from Josh's doc because the
    %stimulus is absolute (not relative to the standard) and we are seeking
    %the chance of S<T (in his terminology). Also corrected some signs.
    NP2 = 2.*((Data(:,1) - Params(1)).^2)./Params(2);
    NP1 = 2.*((Params(1) - Target).^2)./Params(2);
    NP1 = repmat(NP1,size(Data,1),1);

    SimulatedData = zeros(size(Data,1),1);

    for i = 1:size(Data,1)

        if Method == 1
            %saddle point approximation to cdf, supplied by Marc S. Paolella
            SimulatedData(i)=spncf(Params(3),1,1,NP1(i),NP2(i),2);   
        else
            %exact (at least more so) but takes a million years
            SimulatedData(i) = ncf(Params(3),1,1,NP1(i),NP2(i));
        end
    end
    
else
    
    if Method == 3

        %Simulation-based version
        if nargin == 4 %optional second arg passed
            Power = varargin{2};
        else
            Power = 10000; %number of simulations per data point
        end
        

        Levels = size(Data,1);

        sound(:,1) = Data(:,1);
        sound = repmat(sound,1,Power);

        sound = sound + (randn(Levels,Power).*Params(2));          
        sight = (randn(Levels,Power).*Params(2))+Params(1);

        diff1 = sight - sound;

        sight2 = (randn(Levels,Power).*Params(2))+Params(1);       
        sound2 = (randn(Levels,Power).*Params(2))+Target;

        diff2 = sight2 - sound2;

        choosediff = (abs(diff2) - abs(diff1)) < Params(3);
        
        Same = (abs(diff2) - abs(diff1)) == Params(3);
        
        SimulatedData = (sum(choosediff,2)+(sum(Same,2)./2))./(Power);
       
    elseif Method == 4
        
        %Garc�a-P�rez & Peli 2014, Equation A6 (and 5a and A5)
        
        if nargin == 4 %optional second arg passed
            Resolution = varargin{2};
        else
            Resolution = 0; %0 for low res, 1 for high res. High res also uses trapezoid (rather than sum) integration.
        end
                
        if Resolution == 0
            stepsize = 0.05;
            startSDs = 5.5;
        else
            stepsize = 0.01;
            startSDs = 5.5;
        end
                
        SDDiff = ((2.*(Params(2).^2)).^0.5);
        
        Extreme = abs(Target-Params(1))-max(abs(Data(:,1)-Params(1)));
        LowStim = (Extreme./SDDiff)-startSDs; %Start of intergral, several SDs before most extreme mean difference
        
        %HighStim = (abs(Target-Params(1))./SDDiff)+5;
        HighStim = (Params(3)./SDDiff);   %End of integral, at interval bias criterion
        
        if HighStim-LowStim < stepsize
            %fprintf('Warning: Integration range impossible \n')
            SimulatedData = zeros(size(Data,1),1);
        else
        
            WarningCut = 0.001;       

            ThisData = [LowStim:stepsize:HighStim]';
            ThisData = repmat(ThisData,1,4);
            i = [-1 -1 1 1];
            i = repmat(i,size(ThisData,1),1);
            j = [-1 1 -1 1];
            j = repmat(j,size(ThisData,1),1);

            %Alternative vectorised solution, turned out to be slower than loop
            %ThisData = [LowStim:stepsize:HighStim];
            %ThisData = repmat(ThisData,size(Data,1),1,4);
            %i(1,1,:) = [-1 -1 1 1];
            %i = repmat(i,size(Data,1),size(ThisData,2),1);
            %j(1,1,:) = [-1 1 -1 1];
            %j = repmat(j,size(Data,1),size(ThisData,2),1);

            SimulatedData = zeros(size(Data,1),1);

            for k = 1:size(Data,1)

                NonTarget = Data(k,1);
                %NonTarget = repmat(Data,1,size(ThisData,2),4); %Vectorised alternative

                f = sum((1/(2*(pi^0.5))).*exp((-1/4).*((ThisData+(i.*((Target-Params(1))./SDDiff))+(j.*((NonTarget-Params(1))./SDDiff))   ).^2))...
                .*normcdf((1/(2^0.5)).*((-1.*abs(ThisData))-(i.*((Target-Params(1))./SDDiff))+(j.*((NonTarget-Params(1))./SDDiff)))),2);

    %             %Plot difference distribution at each stim level to check
    %             %it's working okay
    %             figure
    %             plot(ThisData(:,1),f)

                if f(1) > WarningCut
                %if sum(f(:,1)>WarningCut)>0 %Vectorised alternative

                    fprintf('Warning: Negative infinity integration began with values >%4.3f \n',WarningCut)

                end

                if Resolution == 0
                    SimulatedData(k) = sum(f).*stepsize;
                else
                    SimulatedData(k) = trapz(f).*stepsize;                
                end            
                %SimulatedData = trapz(f,2).*stepsize; %Vectorised alternative
            end

        end
     
    else
        %method 5, an equation that should be the same as above but without
        %requiring any integration
        
        SDDiff = ((2.*(Params(2).^2)).^0.5);
        PSS = Params(1).*-1;
        Bias = Params(3);
        
        if Bias <= 0
            
            t1 = erf((Target - Data(:,1) + Bias)./(2.*SDDiff));
            t2 = erf(((2.*PSS) + Data(:,1) + Target - Bias)./(2.*SDDiff)) - 1;
            t3 = t2 + 1;
            t4 = erf(((2.*PSS) + Data(:,1) + Target + Bias)./(2.*SDDiff));
            t5 = erf((Data(:,1) - Target + Bias)./(2.*SDDiff));
            t6 = t4 + 1;
                
            SimulatedData = 0.25 .* (2 - (t1.*t2) - t3 + t4 + (t5.*t6));
        
        else
            
            t1 = 1 - erf((Data(:,1) - Target + Bias)./(2.*SDDiff));
            t2 = (1 - erf(((2.*PSS) + Data(:,1) + Target - Bias)./(2.*SDDiff))) - 2;
            t3 = 1 - erf((Target - Data(:,1) + Bias)./(2.*SDDiff));
            t4 = 1 - erf(((2.*PSS) + Data(:,1) + Target + Bias)./(2.*SDDiff));
            
            SimulatedData = 0.25 .* (4 + (t1.*t2) - (t3.*t4));
            
        end
        
    end
    
        
end

end


