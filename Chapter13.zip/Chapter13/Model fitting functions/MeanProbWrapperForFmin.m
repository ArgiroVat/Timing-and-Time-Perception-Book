% Wrapper function for Nelder-Mead search fitting a set of probability data
% to the predictions of a simple mean model of 
% order judgements. StartParams should be a
% vector with one value. Data should be a matrix, with column 1 as the
% tested values, column 2 as proportions judged longer/bigger/later, and column three 
% as the number of
% presentations.

function [FinalParams, LogLikelihood, Deviance] = MeanProbWrapperForFmin(StartParams,Data)

    %DefaultOptions = optimset('fminsearch')
    %options = optimset(DefaultOptions, etc...). %In this case, add Options
    %to fminsearch arguments (after StartParams, may also need to pass data afterwards)
    
    ActualMean = sum(Data(:,2).*Data(:,3))./sum(Data(:,3))
    ActualCurve = ones(length(Data),1).*ActualMean;
    
    %key function to implement Nelder-Mead search
    %[FinalParams InverseLikelihood Exitflag Output] = fminsearch(@wrapped,StartParams)
    [FinalParams, InverseLikelihood, icount, numres, ifault ] = nelmin (@wrapped, 1, StartParams, ...
        100, [0.5], 10, 400 );

    LogLikelihood = -1.*InverseLikelihood;      
    
    %Curve = MeanProb(FinalParams,Data);
    %[Deviance] = BinomialDeviance(Curve, Data, 0.0000000001, 0.01);
    [Deviance] = BinomialDeviance(ActualCurve, Data, 0.0000000001, 0.01);
        
    %Plot best fit against data
    figure
    hold on
    plot(Data(:,1),Data(:,2),'o')
    %t = (min(Data(:,1)):max(Data(:,1)))';
    %Curve = MeanProb(FinalParams,t); %Expanded Curve to plot points every ms
    %plot(t,Curve)
    plot(Data(:,1),ActualCurve)
    hold off
    
    %Actual wrapped function
    function InverseLikelihood = wrapped(Params) %Uses inverse likelihood as function will look for minimum
                        
        if Params < 0 || Params >1
            InverseLikelihood = realmax; %Makes sure that impossible parameter values don't get evaluated
        else
            SimulatedProportions = MeanProb(Params,Data); %Returns vector of Simulated data for these params
                                          
                        
            %The this bit applies the appropriate "data model", in this
            %case based on the binomial distributions as this is forced
            %choice data
            DataB = Data;
            DataB(:,2) = round(Data(:,2).*Data(:,3)); %change from proportions to numbers
            
            %for i = 1:length(Data(:,1))
            %    MLEperStimLevel(i) = BinomialLikelihood(DataB(i,2),DataB(i,3),SimulatedProportions(i));
            %end
                   
            %MLE = sum(log(MLEperStimLevel));
            
            %Vectorised approach with kernal LL; much quicker, but less clear what is
            %going on.
            %I think I got this from Wichmann & Hill. It uses a kernel
            %log likelihood function, so don't mix and match with the
            %approach above! (kernel = missing terms that only add
            %constants)
            MLEperStimLevel = (DataB(:,2).*log(SimulatedProportions))...
                + ((DataB(:,3)-DataB(:,2)).*log(1-SimulatedProportions));
            
            MLE = sum(MLEperStimLevel);                       
            
            InverseLikelihood = MLE .* -1;
                        
            
        end
        
    end

end