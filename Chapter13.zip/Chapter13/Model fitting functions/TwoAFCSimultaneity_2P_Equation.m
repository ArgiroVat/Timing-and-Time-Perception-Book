%Predictor (estimated at each stimulus level based on  the CDF of a doubly 
%noncentral F distribution (Thanks to Josh Solomon for supplying this equation), 
%from a data file
%with three columns in the form Difference, proportion, total) for a 2afc
%simultaneity model (comparing absolute differences in two intervals)
%The function has two required input variables: Params and Data.
%Params should be a three value vector in the form Bias, SD, Interval Bias. In the default state, data is
%a set of SOAs which are assumed to be being compared to a true
%simultaneous (SOA = 0) stimulus pair (with proportion as the proportion of
%times this simultaneous pair is judged more simultaneous). However, the
%model can also make predictions about non simultaneous targets vs. other
%SOAs. To do this, an optional argument is passed indicating the SOA of the
%target pair. Proportion is now the proportion of times this pair is judged
%more simultaneous than the pair in the other interval. 

function SimulatedData = TwoAFCSimultaneity_3P_Equation(Params,Data,varargin)

if nargin == 3 %optional arg passed
    Target = varargin{1};
else
    Target = 0;
end

Params(2) = 4 .* Params(2).^2; %conversion between Josh's variance parameter
%and the one I have tended to use (the average SD of each signal's latency
%noise).

%Noncentrality parameters. I have modified from Josh's doc because the
%stimulus is absolute (not relative to the standard) and we are seeking
%the chance of S<T (in his terminology). Also corrected some signs.
NP2 = 2.*((Data(:,1) - Params(1)).^2)./Params(2);
NP1 = 2.*((Params(1) - Target).^2)./Params(2);
NP1 = repmat(NP1,size(Data,1),1);

SimulatedData = zeros(size(Data,1),1);

for i = 1:size(Data,1)

    %saddle point approximation to cdf, supplied by Marc S. Paolella
    SimulatedData(i)=spncf(1,1,1,NP1(i),NP2(i),2);     
    
    %exact (at least more so) but takes a million years
    %SimulatedData(i) = ncf(1,1,1,NP1(i),NP2(i));
        
end

 

% Levels = size(Data,1);
% 
% sound(:,1) = Data(:,1);
% 
% sound = repmat(sound,1,Power);
% 
% %for i = 1:1:Power
% %    sound = [sound sound sound sound sound sound sound sound sound sound];
% %end
% 
% sound = sound + (randn(Levels,Power).*Params(2));          
% sight = (randn(Levels,Power).*Params(2))+Params(1);
% 
% diff1 = sight - sound;
% 
% sight2 = (randn(Levels,Power).*Params(2))+Params(1);       
% sound2 = (randn(Levels,Power).*Params(2))+Target;
% 
% diff2 = sight2 - sound2;
% 
% choosediff = abs(diff1) > abs(diff2);
% Same = abs(diff1) == abs(diff2);
% %choosediff = (diff1) > (diff2);
% %Same = (diff1) == (diff2);
% 
% SimulatedData = (sum(choosediff,2)+(sum(Same,2)./2))./(Power);


