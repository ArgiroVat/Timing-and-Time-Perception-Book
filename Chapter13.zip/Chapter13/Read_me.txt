Unzip, put all the folders/files on your Matlab path and then type one of the following:

�help SimultaneityNoisyCriteriaMultistart� (to fit SJ data to a four-parameter model)
"help TernaryNoisyCriteriaMultistart" (the same model applied to ternary data)

�help SimultaneityDiffCumGaussMultistart� (for a simpler three-parameter model of SJs generating a symmetric psychometric function).
"help TernaryDiffCumGaussMultistart" (the same model applied to ternary data)

"help CumulativeGaussianMultistart" (for a two-parameter TOJ model)

"help TwoAFCSimultaneity_3PEq_Multistart_rawdata" (fits a 3P model to a task where O must decide which of two intervals is most simultaneous)
"help TwoAFCSimultaneity_2PEq_Multistart_rawdata" (as above, except that data are not broken down to fit an interval bias so only two parameters)

Note that the files in the Derivest suite and F programs folders where written by other people and obtained from Matlab Central.