Eprime.2 - production and verbal estimation.zip: This file contains time reproduction tasks with three methods of reproduction.

Eprime.2 - reproduction methods.zip: This file contains time production and verbal estimation tasks. The method for producing the intervals is the “keep pressing” method.